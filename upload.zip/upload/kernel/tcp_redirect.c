/**
@file
@brief    redirect tcp packets to proxy.
@details  Copyright (c) 2020 Acronis
@author   Bruce Wang (Bruce.Wang@acronis.com)
*/

#include "tcp_redirect_common.h"
#include "tcp_redirect.h"
#include "tcp_redirect_hashtable.h"
#include "tcp_redirect_compat.h"
#include "tcp_redirect_debug.h"

#include <linux/ip.h>
#include <linux/netfilter_ipv4.h>
#include <linux/tcp.h>
#include <linux/udp.h>
#include <linux/version.h>
#include <net/tcp.h>

#define REDIRECT_SOCK_MARK 20130508  //user kernel must be same
#define REDIRECT_SOCK_MARK2 20130509 //user kernel must be same
#define MAX_PORT_NUM 65535
#define CHECKSUM_HW 1

uint32_t ProxyIp = 0;
unsigned short ProxyPort = 0;
int ProxyPid = 0;
unsigned char moduleState = MODULE_STATE_STOP;

unsigned short *monitorPorts = NULL;
unsigned short monitorPortsCount = 0;
unsigned short monitorPortsSize = 0;
PortRange *monitorPortRanges = NULL;
unsigned short monitorPortRangesCount = 0;
unsigned short monitorPortRangesSize = 0;

#if LINUX_VERSION_CODE <= KERNEL_VERSION(4, 0, 0)
static int ip_tcp_checksum(struct iphdr *iph, struct tcphdr *tcph, struct sk_buff *skb)
#else
static int ip_tcp_checksum(struct iphdr *iph, struct tcphdr *tcph, struct sk_buff *skb, const struct nf_hook_state *state)
#endif
{
  int err;
  unsigned int tcplen;
  iph->check = 0;
  iph->check = ip_fast_csum((unsigned char *)iph, iph->ihl);
  tcplen = ntohs(iph->tot_len) - iph->ihl * 4;
  tcph->check = 0;

#if LINUX_VERSION_CODE >= KERNEL_VERSION(3, 10, 0)
  if (skb->ip_summed == CHECKSUM_HW)
#endif
  {
    tcph->check = tcp_v4_check(tcplen, iph->saddr, iph->daddr, csum_partial((char *)tcph, tcplen, 0));
    skb->csum = offsetof(struct tcphdr, check);
  }

#if LINUX_VERSION_CODE >= KERNEL_VERSION(5, 8, 0)
  err = ip_route_me_harder(state->net, skb->sk, skb, RTN_UNSPEC);
#elif LINUX_VERSION_CODE >= KERNEL_VERSION(4, 4, 0)
  err = ip_route_me_harder(state->net, skb, RTN_UNSPEC);
#else
  err = ip_route_me_harder(skb, RTN_UNSPEC);
#endif
  if (err < 0)
  {
    EPRINTF("erro ip_route_me_harder error");
    return -1;
  }
  return 1;
}

static const uint16_t default_port = 80;

#if LINUX_VERSION_CODE <= KERNEL_VERSION(4, 0, 0)
static void modify_tcp_packets(struct sk_buff *skb)
#else
static void modify_tcp_packets(struct sk_buff *skb, const struct nf_hook_state *state)
#endif
{
  struct iphdr *iph;
  struct tcphdr *tcph;
  int err;
  uint16_t destPort;

  if (ProxyPid == 0 || ProxyPort == 0 || ProxyIp == 0)
  {
    return;
  }
  if (monitorPortRangesCount != monitorPortRangesSize || monitorPortsCount != monitorPortsSize)
  {
    return;
  }
  if (moduleState == MODULE_STATE_STOP)
  {
    return;
  }
  if (ntohs(skb->protocol) != ETH_P_IP)
  {
#if LINUX_VERSION_CODE < KERNEL_VERSION(3, 10, 0)
    if (ntohs(skb->protocol) != 0)
    {
      return;
    }
#else
    return;
#endif
  }
  iph = ip_hdr(skb);
  if (iph == NULL)
  {
    return;
  }
  if (iph->protocol != IPPROTO_TCP)
  {
    return;
  }
  tcph = tcp_hdr(skb);
  if (tcph == NULL)
  {
    return;
  }
  if (skb->sk == NULL)
  {
    return;
  }

  //let the packets with mark pass
  if (skb->sk->sk_mark == REDIRECT_SOCK_MARK || skb->sk->sk_mark == REDIRECT_SOCK_MARK2)
  {
    return;
  }
  //for the packets sent from proxy to clients, we need to find it's nat source addr and reply to client with that addr.
  if (iph->saddr == ProxyIp && ntohs(tcph->source) == ProxyPort)
  {
    struct nat_address *nat_addr = NULL;
    nat_addr = nat_hash_find(ntohs(tcph->dest), iph->daddr);
    if (nat_addr == NULL)
    {
      EPRINTF("error client_ori_dest not exist");
      return;
    }
    iph->saddr = nat_addr->dip;
    tcph->source = htons(nat_addr->dport);
#if LINUX_VERSION_CODE <= KERNEL_VERSION(4, 0, 0)
    err = ip_tcp_checksum(iph, tcph, skb);
#else
    err = ip_tcp_checksum(iph, tcph, skb, state);
#endif
    if (err < 0)
    {
      EPRINTF("error ip_tcp_checksum error");
    }
    return;
  }

  //check if the destination port is in the port/port range list
  destPort = ntohs(tcph->dest);
  if ((monitorPorts == NULL || monitorPortsCount == 0 || monitorPortsSize == 0) &&
      (monitorPortRanges == NULL || monitorPortRangesCount == 0 || monitorPortRangesSize == 0))
  {
    //port/port range are not set, default port is 80
    if (destPort != default_port)
    {
      return;
    }
  }
  else
  {
    //check port/port range list
    unsigned char allow = 0;
    if (monitorPorts != NULL)
    {
      int i;
      for (i = 0; i < monitorPortsCount; i++)
      {
        if (monitorPorts[i] == destPort)
        {
          allow = 1;
          break;
        }
      }
    }
    if (allow == 0 && monitorPortRanges != NULL)
    {
      int i;
      for (i = 0; i < monitorPortRangesCount; i++)
      {
        if ((monitorPortRanges[i].start <= destPort) && (destPort <= monitorPortRanges[i].end))
        {
          allow = 1;
          break;
        }
      }
    }
    if (allow == 0)
    {
      return;
    }
  }

  //if this connection hasn't been monitored and it's a tcp syn from client, we start to monitor it, otherwise we ignore.
  if (nat_hash_find(ntohs(tcph->source), iph->saddr) == NULL)
  {
    if (tcph->syn == 1 && tcph->ack == 0)
    {
      if (nat_hash_add(ntohs(tcph->source), iph->saddr, ntohs(tcph->dest), iph->daddr) < 0)
      {
        return;
      }
    }
    else
    {
      return;
    }
  }
  //for the connection we monitor, modify it's dest to proxy's address
  iph->daddr = ProxyIp;
  tcph->dest = htons((unsigned short)ProxyPort);
#if LINUX_VERSION_CODE <= KERNEL_VERSION(4, 0, 0)
  err = ip_tcp_checksum(iph, tcph, skb);
#else
  err = ip_tcp_checksum(iph, tcph, skb, state);
#endif
  if (err < 0)
  {
    EPRINTF("error ip_tcp_checksum error");
  }
  return;
}

static struct nf_hook_ops netfops_out;
#if LINUX_VERSION_CODE <= KERNEL_VERSION(4, 0, 0)
static unsigned int main_hook_out(unsigned int hooknum,
                                  struct sk_buff *skb,
                                  const struct net_device *in,
                                  const struct net_device *out,
                                  int (*okfn)(struct sk_buff *))
{
  modify_tcp_packets(skb);
  return NF_ACCEPT;
}
#elif LINUX_VERSION_CODE > KERNEL_VERSION(4, 0, 0) && LINUX_VERSION_CODE <= KERNEL_VERSION(4, 3, 0)
static unsigned int main_hook_out(const struct nf_hook_ops *ops,
                                  struct sk_buff *skb,
                                  const struct nf_hook_state *state)
{
  modify_tcp_packets(skb, state);
  return NF_ACCEPT;
}
#else
static unsigned int main_hook_out(void *priv,
                                  struct sk_buff *skb,
                                  const struct nf_hook_state *state)
{
  modify_tcp_packets(skb, state);
  return NF_ACCEPT;
}
#endif

int redirect_filter_init(void)
{
  int err = 0;
  netfops_out.hook = (nf_hookfn *)&main_hook_out;
  netfops_out.pf = NFPROTO_IPV4;
  netfops_out.hooknum = NF_INET_LOCAL_OUT;
  netfops_out.priority = NF_IP_PRI_FIRST;
  err = nf_register_hook_compat(&init_net, &netfops_out);
  if (err < 0)
  {
    EPRINTF("redirect filter register is failed");
    goto err;
  }
  else
  {
    IPRINTF("redirect filter register is successful");
  }

err:
  return err;
}

void redirect_filter_exit(void)
{
  nf_unregister_hook_compat(&init_net, &netfops_out);
  IPRINTF("redirect filter unregistered");
}
