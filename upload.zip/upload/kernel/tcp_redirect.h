/**
@file
@brief    redirect tcp packets to proxy.
@details  Copyright (c) 2020 Acronis
@author   Bruce Wang (Bruce.Wang@acronis.com)
*/

#ifndef REDIRECT_H
#define REDIRECT_H

#include <linux/types.h>

#define MODULE_STATE_START 1
#define MODULE_STATE_STOP  0

int redirect_filter_init(void);
void redirect_filter_exit(void);

typedef struct _PortRange
{
  unsigned short start;
  unsigned short end;
} PortRange;

#endif
