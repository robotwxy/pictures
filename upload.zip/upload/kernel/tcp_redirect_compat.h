/**
@file
@brief    Compatibility supports.
@details  Copyright (c) 2020 Acronis
@author   Bruce Wang (Bruce.Wang@acronis.com)
*/

#ifndef REDIRECT_COMPAT_H
#define REDIRECT_COMPAT_H

#include <linux/version.h>
#include <linux/timer.h>
#include <linux/list.h>
#include <linux/hashtable.h>

#if LINUX_VERSION_CODE < KERNEL_VERSION(4, 15, 0)

#define DEFINE_TIMER_COMPAT(_name, _function) \
  DEFINE_TIMER(_name, _function, 0, 0)

#else

#define DEFINE_TIMER_COMPAT(_name, _function) \
  DEFINE_TIMER(_name, _function)

#endif

#if LINUX_VERSION_CODE < KERNEL_VERSION(4, 3, 0)

#define nf_register_hook_compat(_net, _ops) \
  nf_register_hook(_ops)

#define nf_unregister_hook_compat(_net, _ops) \
  nf_unregister_hook(_ops)

#else

#define nf_register_hook_compat(_net, _ops) \
  nf_register_net_hook(_net, _ops)

#define nf_unregister_hook_compat(_net, _ops) \
  nf_unregister_net_hook(_net, _ops)

#endif

#if LINUX_VERSION_CODE < KERNEL_VERSION(3, 9, 0)

#define hlist_for_each_entry_compat(pos, head, member, n) \
  hlist_for_each_entry(pos, n, head, member)

#define hash_for_each_possible_comapt(name, obj, member, key, n) \
  hlist_for_each_entry_compat(obj, &name[hash_min(key, HASH_BITS(name))], member, n)

#define hlist_entry_safe(ptr, type, member)              \
  ({                                                     \
    typeof(ptr) ____ptr = (ptr);                         \
    ____ptr ? hlist_entry(____ptr, type, member) : NULL; \
  })

#else

#define hlist_for_each_entry_compat(pos, head, member, n) \
  hlist_for_each_entry(pos, head, member)

#define hash_for_each_possible_comapt(name, obj, member, key, n) \
  hash_for_each_possible(name, obj, member, key)

#endif

#endif
