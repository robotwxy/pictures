/**
@file
@brief    Hashtable supports for NAT addresses.
@details  Copyright (c) 2020 Acronis
@author   Bruce Wang (Bruce.Wang@acronis.com)
*/

#include <linux/version.h>
#include <linux/hashtable.h>
#include <linux/slab.h>

#include "tcp_redirect_common.h"
#include "tcp_redirect_hashtable.h"
#include "tcp_redirect_compat.h"
#include "tcp_redirect_debug.h"

#if LINUX_VERSION_CODE <= KERNEL_VERSION(3, 10, 0)
#include <linux/hrtimer.h>
#endif

#define TIMER_EXPIRE_TIME 180
#define CONNECTION_MAX_ALIVE_TIME 360
#define HASHTABLE_POW 16
#define HASHTABLE_SIZE 1 << HASHTABLE_POW

#if LINUX_VERSION_CODE <= KERNEL_VERSION(4, 14, 0)
static void nat_hashtable_check_timeout(unsigned long unused);
#else
static void nat_hashtable_check_timeout(struct timer_list *unused);
#endif

struct hlist_head nat_addr_list = HLIST_HEAD_INIT;
DEFINE_HASHTABLE(nat_addr_htable, HASHTABLE_POW);
DEFINE_TIMER_COMPAT(nat_hashtable_timer, nat_hashtable_check_timeout);
DEFINE_MUTEX(nat_addr_htable_mutex);

static unsigned long long timer_counter = 0;
static unsigned int nat_address_num = 0;
static unsigned char initFlag = 0;

int nat_hashtable_init(void)
{
  int ret = 0;
  ret = mod_timer(&nat_hashtable_timer, jiffies + TIMER_EXPIRE_TIME * HZ);
  if (ret >= 0)
  {
    IPRINTF("check nat address timer initial is successful: %d", ret);
    initFlag = 1;
  }
  else
  {
    EPRINTF("check nat address timer initial is failed: %d", ret);
  }
  return ret;
}

#if LINUX_VERSION_CODE <= KERNEL_VERSION(4, 14, 0)
static void nat_hashtable_check_timeout(unsigned long unused)
#else
static void nat_hashtable_check_timeout(struct timer_list *unused)
#endif
{
  struct nat_address *obj;
  struct nat_address *next;
  ktime_t now, diff_ktime;
  int i;

#if LINUX_VERSION_CODE >= KERNEL_VERSION(5, 8, 0)
  long long diff;
#else
  struct timeval diff;
#endif

  DPRINTF("nat_hashtable_check_timeout %llu", ++timer_counter);
  now = ktime_get();
  //clean expired nat address in hashtable
  obj = hlist_entry_safe(nat_addr_list.first, typeof(*(obj)), lnode);
  while (obj != NULL)
  {
    next = hlist_entry_safe((obj)->lnode.next, typeof(*(obj)), lnode);
    // DPRINTF("obj: %p next: %p", obj, next);
    diff_ktime = ktime_sub(now, obj->update_time);
#if LINUX_VERSION_CODE >= KERNEL_VERSION(5, 8, 0)
    diff = ktime_to_ms(diff_ktime) / 1000;
    if (diff > CONNECTION_MAX_ALIVE_TIME)
#else
    diff = ktime_to_timeval(diff_ktime);
    if (diff.tv_sec > CONNECTION_MAX_ALIVE_TIME)
#endif
    {
      // DPRINTF("delete: %p ", obj);
      nat_hash_del(obj);
    }
    obj = next;
  }

  //for debug
  for (i = 0; i < HASHTABLE_SIZE; i++)
  {
    struct nat_address *addr = NULL;
    struct hlist_node *n;
    n = NULL;
    hash_for_each_possible_comapt(nat_addr_htable, addr, node, i, n)
    {
#if LINUX_VERSION_CODE >= KERNEL_VERSION(5, 8, 0)
      ktime_t diff_ktime = ktime_sub(now, addr->update_time);
      long long diff = ktime_to_ms(diff_ktime) / 1000;
      DPRINTF("hashtable[%d] addr alive time:%llu, %pI4:%u->%pI4:%u", i, diff, &(addr->sip), addr->sport, &(addr->dip), addr->dport);
#else
      ktime_t diff_ktime = ktime_sub(now, addr->update_time);
      struct timeval diff = ktime_to_timeval(diff_ktime);
      DPRINTF("hashtable[%d] addr alive time:%lu, %pI4:%u->%pI4:%u", i, diff.tv_sec, &(addr->sip), addr->sport, &(addr->dip), addr->dport);
#endif
    }
  }

  mod_timer(&nat_hashtable_timer, jiffies + TIMER_EXPIRE_TIME * HZ);
}
int nat_hash_add(unsigned short sport, uint32_t sip, unsigned short dport, uint32_t dip)
{
  struct nat_address *nat_addr = NULL;
  int ret;
  if (nat_addr_htable == NULL || initFlag == 0)
  {
    EPRINTF("nat_addr_htable is null");
    ret = -1;
    goto end;
  }
  nat_addr = kmalloc(sizeof(struct nat_address), GFP_KERNEL);
  if (nat_addr == NULL)
  {
    EPRINTF("can't kmalloc");
    ret = -1;
    goto end;
  }
  memset(nat_addr, 0, sizeof(struct nat_address));
  nat_addr->sip = sip;
  nat_addr->dip = dip;
  nat_addr->sport = sport;
  nat_addr->dport = dport;
  nat_addr->update_time = ktime_get();

  mutex_lock(&nat_addr_htable_mutex);
  hash_add(nat_addr_htable, &(nat_addr->node), sport);
  hlist_add_head(&(nat_addr->lnode), &nat_addr_list);
  nat_address_num++;
  mutex_unlock(&nat_addr_htable_mutex);

  DPRINTF("nat_addr add %u %u %pI4 dip:%pI4 dport:%u", nat_address_num, nat_addr->sport, &(nat_addr->sip), &(nat_addr->dip), nat_addr->dport);
  ret = 0;
end:
  return ret;
}

int nat_hash_del(struct nat_address *nat_addr)
{
  int ret;
  if (nat_addr_htable == NULL || nat_addr == NULL)
  {
    EPRINTF("error null");
    ret = -1;
    goto end;
  }

  mutex_lock(&nat_addr_htable_mutex);
  hash_del(&(nat_addr->node));
  __hlist_del(&(nat_addr->lnode));
  nat_address_num--;
  mutex_unlock(&nat_addr_htable_mutex);

  DPRINTF("nat_addr del %u %u %pI4 dip:%pI4 dport:%u", nat_address_num, nat_addr->sport, &(nat_addr->sip), &(nat_addr->dip), nat_addr->dport);
  kfree(nat_addr);
  ret = 0;
end:
  return ret;
}

struct nat_address *nat_hash_find(unsigned short sport, uint32_t sip)
{
  struct nat_address *addr = NULL;
  struct hlist_node *n;
  n = NULL;
  if (nat_addr_htable == NULL)
  {
    EPRINTF("error null");
    return NULL;
  }
  hash_for_each_possible_comapt(nat_addr_htable, addr, node, sport, n)
  {
    if (addr->sip == sip && addr->sport == sport)
    {
      return addr;
    }
  }
  return NULL;
}

int nat_hash_clean(void)
{
  struct nat_address *obj;
  struct nat_address *next;
  //clean all nat address in hashtable
  obj = hlist_entry_safe(nat_addr_list.first, typeof(*(obj)), lnode);
  while (obj != NULL)
  {
    next = hlist_entry_safe((obj)->lnode.next, typeof(*(obj)), lnode);
    // DPRINTF("obj: %p next: %p", obj, next);
    nat_hash_del(obj);
    obj = next;
  }
  IPRINTF("clean all nat address in hashtable");
  return 0;
}

int nat_hashtable_exit(void)
{
  int ret = 0;
  ret = del_timer(&nat_hashtable_timer);
  nat_hash_clean();
  IPRINTF("check nat address timer uninitialized: %d", ret);
  return ret;
}
