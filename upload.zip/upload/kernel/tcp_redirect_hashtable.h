/**
@file
@brief    Hashtable supports for NAT addresses.
@details  Copyright (c) 2020 Acronis
@author   Bruce Wang (Bruce.Wang@acronis.com)
*/

#ifndef REDIRECT_HASHTABLE_H
#define REDIRECT_HASHTABLE_H

#include <linux/types.h>
#include <linux/ktime.h>
#include <linux/hashtable.h>

#include "tcp_redirect.h"

struct nat_address
{
  unsigned short sport; //source port
  uint32_t sip;         //source ip
  unsigned short dport; //dest port
  uint32_t dip;         //dest ip
  ktime_t update_time;
  struct hlist_node node;  //linked list in hashtable
  struct hlist_node lnode; // linked list for all node.
};

int nat_hash_add(unsigned short sport, uint32_t sip, unsigned short dport, uint32_t dip);
int nat_hash_del(struct nat_address *nat_addr);
struct nat_address *nat_hash_find(unsigned short sport, uint32_t sip);
int nat_hashtable_init(void);
int nat_hashtable_exit(void);

#endif
