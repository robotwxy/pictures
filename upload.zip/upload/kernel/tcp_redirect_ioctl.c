/**
@file
@brief    ioctl supports for communication with userspace.
@details  Copyright (c) 2020 Acronis
@author   Bruce Wang (Bruce.Wang@acronis.com)
*/

#include <linux/version.h>
#include <linux/uaccess.h>
#include <linux/slab.h>
#include <linux/fs.h>
#include <linux/cdev.h>
#include <linux/timer.h>

#include "tcp_redirect_common.h"
#include "tcp_redirect_ioctl.h"
#include "tcp_redirect.h"
#include "tcp_redirect_hashtable.h"
#include "tcp_redirect_compat.h"
#include "tcp_redirect_debug.h"

#if LINUX_VERSION_CODE <= KERNEL_VERSION(3, 10, 0)
#include <linux/module.h>
#include <linux/hrtimer.h>
#include <linux/device.h>
#endif

#define GET_NAT_ADDR _IOWR('r', 1, struct ioctl_data *)
#define CLEAN_NAT_ADDR _IOWR('r', 2, struct ioctl_data *)
#define REGISTER_USER _IOWR('r', 3, struct ioctl_data_proxy_info *)
#define UNREGISTER_USER _IOWR('r', 4, struct ioctl_data_proxy_info *)
#define KEEP_ALIVE_USER _IOWR('r', 5, struct ioctl_data_proxy_info *)
#define START_REDIRECTION _IOWR('r', 6, struct ioctl_data_proxy_info *)
#define STOP_REDIRECTION _IOWR('r', 7, struct ioctl_data_proxy_info *)
#define SET_PORTS _IOWR('r', 8, struct ioctl_monitor_port_info *)

#define KEEP_ALIVE_TIMER_EXPIRE_TIME 10

#if LINUX_VERSION_CODE <= KERNEL_VERSION(4, 14, 0)
static void keep_alive_timedout(unsigned long unused);
#else
static void keep_alive_timedout(struct timer_list *unused);
#endif

DEFINE_TIMER_COMPAT(keep_alive_timer, keep_alive_timedout);

extern uint32_t ProxyIp;
extern unsigned short ProxyPort;
extern int ProxyPid;
extern unsigned char moduleState;

extern unsigned short *monitorPorts;
extern unsigned short monitorPortsCount;
extern unsigned short monitorPortsSize;
extern PortRange *monitorPortRanges;
extern unsigned short monitorPortRangesCount;
extern unsigned short monitorPortRangesSize;

static ktime_t proxy_info_update_time = {0};

static dev_t dev = 0;
static struct class *dev_class;
static struct cdev redirect_cdev;

static int redirect_ioctl_open(struct inode *inode, struct file *file);
static int redirect_ioctl_release(struct inode *inode, struct file *file);
static ssize_t redirect_ioctl_read(struct file *filp, char __user *buf, size_t len, loff_t *off);
static ssize_t redirect_ioctl_write(struct file *filp, const char *buf, size_t len, loff_t *off);
static long redirect_ioctl_ioctl(struct file *file, unsigned int cmd, unsigned long arg);

static struct file_operations fops =
    {
        .owner = THIS_MODULE,
        .read = redirect_ioctl_read,
        .write = redirect_ioctl_write,
        .open = redirect_ioctl_open,
        .unlocked_ioctl = redirect_ioctl_ioctl,
        .release = redirect_ioctl_release,
};

static int redirect_ioctl_open(struct inode *inode, struct file *file)
{
  return 0;
}

static int redirect_ioctl_release(struct inode *inode, struct file *file)
{
  return 0;
}

static ssize_t redirect_ioctl_read(struct file *filp, char __user *buf, size_t len, loff_t *off)
{
  DPRINTF("redirect Read Function");
  return 0;
}
static ssize_t redirect_ioctl_write(struct file *filp, const char __user *buf, size_t len, loff_t *off)
{
  DPRINTF("redirect Write function");
  return 0;
}

static long redirect_ioctl_ioctl(struct file *file, unsigned int cmd, unsigned long arg)
{
  struct ioctl_data recv_data;
  struct ioctl_data send_data;
  struct ioctl_data_proxy_info proxy_info;
  struct ioctl_monitor_port_info port_info;
  unsigned long ret;
  int res = 0;
  struct nat_address *nat_addr = NULL;
  switch (cmd)
  {
  case GET_NAT_ADDR:
    ret = copy_from_user(&recv_data, (struct ioctl_data *)arg, sizeof(struct ioctl_data));
    if (ret != 0)
    {
      EPRINTF("error copy_from_user");
      return -EINVAL;
    }
    nat_addr = nat_hash_find(recv_data.sport, recv_data.sip);
    if (nat_addr == NULL)
    {
      EPRINTF("error nat_hash_find");
      return -EFAULT;
    }

    nat_addr->update_time = ktime_get();

    send_data.dport = nat_addr->dport;
    send_data.dip = nat_addr->dip;
    ret = copy_to_user((struct ioctl_data *)arg, &send_data, sizeof(struct ioctl_data));
    if (ret != 0)
    {
      EPRINTF("error copy_to_user");
      return -EINVAL;
    }
    break;

  case CLEAN_NAT_ADDR:
    ret = copy_from_user(&recv_data, (struct ioctl_data *)arg, sizeof(struct ioctl_data));
    if (ret != 0)
    {
      EPRINTF("error copy_from_user");
      return -EINVAL;
    }
    nat_addr = nat_hash_find(recv_data.sport, recv_data.sip);
    if (nat_addr == NULL)
    {
      EPRINTF("error nat_hash_find");
      return -EFAULT;
    }
    if (nat_hash_del(nat_addr) < 0)
    {
      EPRINTF("error nat_hash_del");
      return -EINVAL;
    }
    break;

  case REGISTER_USER:
    ret = copy_from_user(&proxy_info, (struct ioctl_data_proxy_info *)arg, sizeof(struct ioctl_data_proxy_info));
    if (ret != 0)
    {
      EPRINTF("error copy_from_user");
      return -EINVAL;
    }
    if (ProxyPid != proxy_info.pid)
    {
      //init proxy pid
      if (ProxyPid == 0)
      {
        IPRINTF("proxy register pid:%d, ip:%pI4, port:%u", proxy_info.pid, &(proxy_info.ip), proxy_info.port);
      }
      else
      {
        IPRINTF("proxy info changed: pid:%d, ip:%pI4, port:%u", proxy_info.pid, &(proxy_info.ip), proxy_info.port);
      }
      proxy_info_update_time = ktime_get(); //use ktime_get instead of ktime_get_coarse for compat

      if (proxy_info.monitorPortsCount != 0)
      {
        if (monitorPorts != NULL)
        {
          kfree(monitorPorts);
          monitorPorts = NULL;
        }
        monitorPorts = kmalloc(sizeof(unsigned short) * proxy_info.monitorPortsCount, GFP_KERNEL);
        if (monitorPorts == NULL)
        {
          EPRINTF("error can't kmalloc");
          return -ENOMEM;
        }
      }
      monitorPortsSize = proxy_info.monitorPortsCount;

      if (proxy_info.monitorPortRangesCount != 0)
      {
        if (monitorPortRanges != NULL)
        {
          kfree(monitorPortRanges);
          monitorPortRanges = NULL;
        }
        monitorPortRanges = kmalloc(sizeof(PortRange) * proxy_info.monitorPortRangesCount, GFP_KERNEL);
        if (monitorPortRanges == NULL)
        {
          EPRINTF("error can't kmalloc");
          return -ENOMEM;
        }
      }
      monitorPortRangesSize = proxy_info.monitorPortRangesCount;

      monitorPortsCount = 0;
      monitorPortRangesCount = 0;
      IPRINTF("ports: %u, ranges: %u", monitorPortsSize, monitorPortRangesSize);

      ProxyPid = proxy_info.pid;
      ProxyIp = proxy_info.ip;
      ProxyPort = proxy_info.port;
    }
    break;

  case UNREGISTER_USER:
    ret = copy_from_user(&proxy_info, (struct ioctl_data_proxy_info *)arg, sizeof(struct ioctl_data_proxy_info));
    if (ret != 0)
    {
      EPRINTF("error copy_from_user");
      return -EINVAL;
    }
    if (ProxyPid != proxy_info.pid)
    {
      EPRINTF("error: UNREGISTER_USER proxy id doesn't match");
      return -EINVAL;
    }
    ProxyPid = 0;
    ProxyIp = 0;
    ProxyPort = 0;

    if (monitorPortRanges != NULL)
    {
      kfree(monitorPortRanges);
      monitorPortRanges = NULL;
    }
    if (monitorPorts != NULL)
    {
      kfree(monitorPorts);
      monitorPorts = NULL;
    }

    IPRINTF("proxy unregister");
    break;

  case KEEP_ALIVE_USER:
    ret = copy_from_user(&proxy_info, (struct ioctl_data_proxy_info *)arg, sizeof(struct ioctl_data_proxy_info));
    if (ret != 0)
    {
      EPRINTF("error copy_from_user");
      return -EINVAL;
    }
    if (ProxyPid != proxy_info.pid)
    {
      EPRINTF("error: KEEP_ALIVE_USER proxy id doesn't match");
      return -EINVAL;
    }
    proxy_info_update_time = ktime_get();
    break;

  case START_REDIRECTION:
    ret = copy_from_user(&proxy_info, (struct ioctl_data_proxy_info *)arg, sizeof(struct ioctl_data_proxy_info));
    if (ret != 0)
    {
      EPRINTF("error copy_from_user");
      return -EINVAL;
    }
    if (ProxyPid != proxy_info.pid)
    {
      EPRINTF("error: START_REDIRECTION proxy id doesn't match");
      return -EINVAL;
    }
    moduleState = MODULE_STATE_START;
    IPRINTF("redirection start");
    break;

  case STOP_REDIRECTION:
    ret = copy_from_user(&proxy_info, (struct ioctl_data_proxy_info *)arg, sizeof(struct ioctl_data_proxy_info));
    if (ret != 0)
    {
      EPRINTF("error copy_from_user");
      return -EINVAL;
    }
    if (ProxyPid != proxy_info.pid)
    {
      EPRINTF("error: STOP_REDIRECTION proxy id doesn't match");
      return -EINVAL;
    }
    moduleState = MODULE_STATE_STOP;
    IPRINTF("redirection stop");
    break;

  case SET_PORTS:
    ret = copy_from_user(&port_info, (struct ioctl_monitor_port_info *)arg, sizeof(struct ioctl_monitor_port_info));
    if (ret != 0)
    {
      EPRINTF("error copy_from_user");
      return -EINVAL;
    }
    DPRINTF("SET_PORTS type: %d, port: %d, range start: %d, end: %d",
            port_info.type, port_info.port, port_info.portRange.start, port_info.portRange.end);
    switch (port_info.type)
    {
    case TYPE_PORT:
      if (monitorPortsCount >= monitorPortsSize)
      {
        EPRINTF("error array lenght exceeds size");
        return -E2BIG;
      }
      if (monitorPorts == NULL)
      {
        EPRINTF("error array pointer is null");
        return -EADDRNOTAVAIL;
      }
      monitorPorts[monitorPortsCount] = port_info.port;
      monitorPortsCount++;
      res = monitorPortsCount;
      break;

    case TYPE_PORT_RANGE:
      if (monitorPortRangesCount >= monitorPortRangesSize)
      {
        EPRINTF("error array lenght exceeds size");
        return -E2BIG;
      }
      if (monitorPortRanges == NULL)
      {
        EPRINTF("error array pointer is null");
        return -EADDRNOTAVAIL;
      }
      monitorPortRanges[monitorPortRangesCount].start = port_info.portRange.start;
      monitorPortRanges[monitorPortRangesCount].end = port_info.portRange.end;
      monitorPortRangesCount++;
      res = monitorPortRangesCount;
      break;

    default:
      return -EINVAL;
      break;
    }

    if (monitorPortRangesCount == monitorPortRangesSize && monitorPortsCount == monitorPortsSize)
    {
      IPRINTF("user set ports successfully");
    }
    return res;
    break;

  default:
    break;
  }
  return 0;
}

#define REDIRECT_IOCTL_CHARDEV_NAME "redirect_ioctl_dev"
#define REDIRECT_IOCTL_CLASS_NAME "redirect_ioctl_class"
#define REDIRECT_IOCTL_DEVICE_NAME "redirect_ioctl_device"
int redirect_ioctl_init(void)
{
  if ((alloc_chrdev_region(&dev, 0, 1, REDIRECT_IOCTL_CHARDEV_NAME)) < 0)
  {
    EPRINTF("rediect ioctl cannot allocate major number");
    return -1;
  }
  IPRINTF("rediect ioctl Major = %d Minor = %d ", MAJOR(dev), MINOR(dev));
  cdev_init(&redirect_cdev, &fops);

  if ((cdev_add(&redirect_cdev, dev, 1)) < 0)
  {
    EPRINTF("rediect ioctl cannot add the device to the system");
    goto r_class;
  }

  if ((dev_class = class_create(THIS_MODULE, REDIRECT_IOCTL_CLASS_NAME)) == NULL)
  {
    EPRINTF("rediect ioctl cannot create the struct class");
    goto r_class;
  }

  if ((device_create(dev_class, NULL, dev, NULL, REDIRECT_IOCTL_DEVICE_NAME)) == NULL)
  {
    EPRINTF("rediect ioctl cannot create the Device");
    goto r_device;
  }
  IPRINTF("reidrect ioctl initial is successful, ioctl device name: %s", REDIRECT_IOCTL_DEVICE_NAME);
  return 0;

r_device:
  class_destroy(dev_class);
r_class:
  unregister_chrdev_region(dev, 1);
  EPRINTF("reidrect ioctl initial is failed");
  return -1;
}

void redirect_ioctl_exit(void)
{
  ProxyPid = 0;
  ProxyIp = 0;
  ProxyPort = 0;
  if (monitorPortRanges != NULL)
  {
    kfree(monitorPortRanges);
    monitorPortRanges = NULL;
  }
  if (monitorPorts != NULL)
  {
    kfree(monitorPorts);
    monitorPorts = NULL;
  }
  
  device_destroy(dev_class, dev);
  class_destroy(dev_class);
  cdev_del(&redirect_cdev);
  unregister_chrdev_region(dev, 1);

  IPRINTF("reidrect ioctl uninitialized");
}

int keep_alive_timer_init(void)
{
  int ret = 0;
  ret = mod_timer(&keep_alive_timer, jiffies + KEEP_ALIVE_TIMER_EXPIRE_TIME * HZ);
  if (ret >= 0)
  {
    IPRINTF("reidrect keep alive timer initial is successful: %d", ret);
  }
  else
  {
    EPRINTF("reidrect keep alive timer initial is failed: %d", ret);
  }
  return ret;
}

void keep_alive_timer_exit(void)
{
  int ret = 0;
  ret = del_timer(&keep_alive_timer);

  IPRINTF("reidrect keep alive timer uninitialized: %d", ret);
}

#if LINUX_VERSION_CODE <= KERNEL_VERSION(4, 14, 0)
static void keep_alive_timedout(unsigned long unused)
#else
static void keep_alive_timedout(struct timer_list *unused)
#endif
{
  ktime_t now, diff_ktime;
#if LINUX_VERSION_CODE >= KERNEL_VERSION(5, 8, 0)
  long long diff;
#else
  struct timeval diff;
#endif
  if (ProxyPid == 0)
  {
    goto restart;
  }
  now = ktime_get();
  diff_ktime = ktime_sub(now, proxy_info_update_time);
#if LINUX_VERSION_CODE >= KERNEL_VERSION(5, 8, 0)
  diff = ktime_to_ms(diff_ktime) / 1000;
  if (diff > KEEP_ALIVE_TIMER_EXPIRE_TIME)
#else
  diff = ktime_to_timeval(diff_ktime);
  if (diff.tv_sec > KEEP_ALIVE_TIMER_EXPIRE_TIME)
#endif
  {
    IPRINTF("keep_alive_timedout, reset proxy info");
    ProxyPid = 0;
    ProxyIp = 0;
    ProxyPort = 0;
    if (monitorPortRanges != NULL)
    {
      kfree(monitorPortRanges);
      monitorPortRanges = NULL;
    }
    if (monitorPorts != NULL)
    {
      kfree(monitorPorts);
      monitorPorts = NULL;
    }
  }
restart:
  mod_timer(&keep_alive_timer, jiffies + KEEP_ALIVE_TIMER_EXPIRE_TIME * HZ);
}
