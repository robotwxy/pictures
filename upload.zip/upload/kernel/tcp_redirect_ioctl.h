/**
@file
@brief    ioctl supports for communication with userspace.
@details  Copyright (c) 2020 Acronis
@author   Bruce Wang (Bruce.Wang@acronis.com)
*/

#ifndef REDIRECT_IOCTL_H
#define REDIRECT_IOCTL_H

#include "tcp_redirect.h"
struct ioctl_data
{
  unsigned short sport; //source port
  uint32_t sip;         //source ip
  unsigned short dport; //dest port
  uint32_t dip;         //dest ip
};

struct ioctl_data_proxy_info
{
  int pid;
  uint32_t ip;
  unsigned short port;
  unsigned short monitorPortsCount;
  unsigned short monitorPortRangesCount;
};

#define TYPE_PORT 1
#define TYPE_PORT_RANGE 2
struct ioctl_monitor_port_info
{
  unsigned char type;
  unsigned short port;
  PortRange portRange;
};

int redirect_ioctl_init(void);
void redirect_ioctl_exit(void);
int keep_alive_timer_init(void);
void keep_alive_timer_exit(void);

#endif
