/**
@file
@brief    TCP packets redirection module.
@details  Copyright (c) 2020 Acronis
@author   Bruce Wang (Bruce.Wang@acronis.com)
*/

#include "tcp_redirect_common.h"
#include "tcp_redirect.h"
#include "tcp_redirect_ioctl.h"
#include "tcp_redirect_hashtable.h"
#include "tcp_redirect_debug.h"
#include <linux/module.h>

int __init redirect_module_init(void)
{
  int err = 0;
  err = redirect_filter_init();
  if (err < 0)
  {
    goto ERROR;
  }
  err = nat_hashtable_init();
  if (err < 0)
  {
    goto ERROR;
  }
  err = redirect_ioctl_init();
  if (err < 0)
  {
    goto ERROR;
  }
  err = keep_alive_timer_init();
  if (err < 0)
  {
    goto ERROR;
  }
  IPRINTF("rediect module initial is successful");
  return 0;
ERROR:
  EPRINTF("rediect module initial is failed");
  return err;
}

void redirect_module_exit(void)
{
  redirect_filter_exit();
  nat_hashtable_exit();
  redirect_ioctl_exit();
  keep_alive_timer_exit();
  IPRINTF("rediect module uninitialized");
}

module_init(redirect_module_init);
module_exit(redirect_module_exit);
MODULE_LICENSE("GPL");