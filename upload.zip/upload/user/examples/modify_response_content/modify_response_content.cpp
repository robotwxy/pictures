#include "interface.h"

#include <string.h>
#include <signal.h>
#include <pthread.h>
#include <stdio.h>
#include <arpa/inet.h>

static char newContent[] = "<h1> content is modified !</h1>";

int PostScan(HttpHandle *message, ConnectionFunctions *connection, const RequestFunctions *request, ResponseFunctions *response, void *connContext)
{
  printf("original body[%s]\n", response->Content(message));
  printf("content is modified\n");
  response->ReplaceContent(message, (const unsigned char *)newContent, strlen(newContent), NULL);
  return 0;
}

unsigned short ports[] = {80, 3000};
int main()
{
  int ret;
  HttpCbks cbks = {0};
  HttpInitParams params = {0};
  params.logEnable = 1;
  params.listenPort = 8005;
  params.listenIpAddr = inet_addr("127.0.0.1");
  params.remoteHttpPorts = ports;
  params.remoteHttpPortsCount = sizeof(ports) / sizeof(unsigned short);
  ret = Http_Initialize(&params);
  printf("Http_Initialize result:%d\n", ret);
  cbks.PostScan = PostScan;
  ret = Http_SetCallbacks(&cbks);
  printf("Http_SetCallbacks result:%d\n", ret);
  ret = Http_Start();
  printf("Http_Start result:%d\n", ret);
  printf("waiting for input to exit\n");
  getchar();
  ret = Http_Stop();
  printf("Http_Stop result:%d\n", ret);
  ret = Http_Uninitialize();
  printf("Http_Uninitialize result:%d\n", ret);
  return 0;
}
