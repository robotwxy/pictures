#include "interface.h"

#include <string.h>
#include <signal.h>
#include <pthread.h>
#include <stdio.h>
#include <arpa/inet.h>

int RequestHeaders(HttpHandle *message, ConnectionFunctions *connection, RequestFunctions *request, void *connContext)
{
  if (strstr(request->Url(message), "google.com") == 0)
  {
    printf("You can only visit google.com !\n");
    const char *html = "<h1> You can only visit google.com !</h1>";
    ResponseFunctions *response = connection->MakeResponse(message);
    connection->BlockPage(message,
                          request,
                          response,
                          (const unsigned char *)html,
                          strlen(html));
    connection->FreeResponse(message, response);
    connection->Disconnect(message);
  }
  return 0;
}
unsigned short ports[] = {80, 3000, 8000};
int main()
{
  int ret;
  HttpCbks cbks = {0};
  HttpInitParams params = {0};
  params.logEnable = 1;
  params.listenPort = 8005;
  params.listenIpAddr = inet_addr("127.0.0.1");
  params.remoteHttpPorts = ports;
  params.remoteHttpPortsCount = sizeof(ports) / sizeof(unsigned short);
  ret = Http_Initialize(&params);
  printf("Http_Initialize result:%d\n", ret);
  cbks.RequestComplete = RequestHeaders;
  ret = Http_SetCallbacks(&cbks);
  printf("Http_SetCallbacks result:%d\n", ret);
  ret = Http_Start();
  printf("Http_Start result:%d\n", ret);
  printf("waiting for input to exit\n");
  getchar();
  ret = Http_Stop();
  printf("Http_Stop result:%d\n", ret);
  ret = Http_Uninitialize();
  printf("Http_Uninitialize result:%d\n", ret);
  return 0;
}
