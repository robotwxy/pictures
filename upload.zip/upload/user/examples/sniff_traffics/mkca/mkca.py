import os
import glob
import shutil
mkcaName = "mkca cert"
rootCA = "rootCA.crt"
rootCAKey = "rootCA.key"
rootCACsr = "rootCA.csr"
x509Ext = """[ca]
keyUsage = critical, keyCertSign
basicConstraints = critical, CA:TRUE, pathlen:0
subjectKeyIdentifier = hash"""
CAConfig = """[req]
distinguished_name = dn
prompt             = no
[dn]
O=mkca
OU=mkca
CN=mkca test CA
"""
CAconfigTmpFile = "tmp_caconfig.cnf"
CAextTmpFile = "tmp_ca.ext"
createCAKeyCsrCmd = "openssl req -new -sha256 -nodes -newkey rsa:4096 -keyout " + \
    rootCAKey + " -out " + rootCACsr + " -config " + CAconfigTmpFile
createCACmd = ("openssl x509 -req -sha256 -extfile " + CAextTmpFile + " -extensions ca -in " + rootCACsr
               + " -signkey " + rootCAKey + " -days 1095 -out " + rootCA)

f = open(CAconfigTmpFile, "w")
f.write(CAConfig)
f.close()
if not os.path.isfile(CAconfigTmpFile):
    print("create", CAconfigTmpFile, "failed")
    exit(1)

if os.system(createCAKeyCsrCmd) != 0:
    print("run", createCAKeyCsrCmd, "failed")
    exit(1)
os.remove(CAconfigTmpFile)

f = open(CAextTmpFile, "w")
f.write(x509Ext)
f.close()
if not os.path.isfile(CAextTmpFile):
    print("create", CAextTmpFile, "failed")
    exit(1)

if os.system(createCACmd) != 0:
    print("run", createCACmd, "failed")
    exit(1)
os.remove(CAextTmpFile)

systemCATrustDir = "/usr/local/share/ca-certificates"
systemCATrustCmd = "update-ca-certificates"
home = os.path.expanduser("~")

fireFoxProfiles = glob.glob(home + "/.mozilla/firefox/*")
nssDBsProfiles = (
    [home + "/.pki/nssdb",
     home + "/snap/chromium/current/.pki/nssdb",
     home + "/etc/pki/nssdb"])
nssDBsProfiles.extend(fireFoxProfiles)

nssDBs = list()
for nss in nssDBsProfiles:
    if os.path.exists(os.path.join(nss, "cert9.db")):
        nssDBs.append("sql:"+nss)
print(nssDBs)

if shutil.which("certutil") is None:
    print("can't find certutil, please install it")
    exit(1)

for nssDB in nssDBs:
    ret = os.system("sudo certutil -A -d " + nssDB + " -t \"C,,\" " + "-n \"" +
              mkcaName+"\" -i " + os.path.join(os.getcwd(), rootCA))
    if ret == 0:
        print("mkca cert is installed in " + nssDB)
        os.system("sudo certutil -L -d " + nssDB)

serverKey = "server.key"
serverCert = "server.crt"
    
