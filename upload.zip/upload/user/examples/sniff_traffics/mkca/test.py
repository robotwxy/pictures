import socket
print(socket.gethostname())
import os

home = os.path.expanduser("~")
print(home)

import glob
print(glob.glob(home+"/*"))
print(os.getcwd())