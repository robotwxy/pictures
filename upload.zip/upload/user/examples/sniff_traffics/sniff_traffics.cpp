#include "interface.h"

#include <string.h>
#include <signal.h>
#include <pthread.h>
#include <stdio.h>
#include <arpa/inet.h>
#include <wchar.h>
#include <iostream>
#include <stdarg.h>

void print_ip(unsigned int ip)
{
  unsigned char bytes[4];
  bytes[0] = ip & 0xFF;
  bytes[1] = (ip >> 8) & 0xFF;
  bytes[2] = (ip >> 16) & 0xFF;
  bytes[3] = (ip >> 24) & 0xFF;
  printf("%d.%d.%d.%d", bytes[0], bytes[1], bytes[2], bytes[3]);
}
int NewConnection(HttpHandle *message, ConnectionFunctions *connection, void **connContext)
{
  printf("NewConnection:");
  unsigned localIp = *(int *)connection->GetInfo(message)->localAddress->ipaddr;
  print_ip(localIp);
  printf(":%u -> ", connection->GetInfo(message)->localAddress->port);
  unsigned remoteIp = *(int *)connection->GetInfo(message)->remoteAddress->ipaddr;
  print_ip(remoteIp);
  printf(":%u, ", connection->GetInfo(message)->remoteAddress->port);
  std::cout << "pid " << connection->GetInfo(message)->processId << ", ";
  std::cout << "path:" << wcslen(connection->GetInfo(message)->processPath) << ", ";
  std::wcout << L"[" << connection->GetInfo(message)->processPath << L"]" << std::endl;

  std::cout << "Http_IsPathInExclustions: " << Http_IsPathInExclustions(connection->GetInfo(message)->processPath) << std::endl;
  return 0;
}

int ConnectionDestroyed(HttpHandle *message, ConnectionFunctions *connection, void *connContext)
{
  printf("ConnectionDestroyed:");
  unsigned localIp = *(int *)connection->GetInfo(message)->localAddress->ipaddr;
  print_ip(localIp);
  printf(":%u -> ", connection->GetInfo(message)->localAddress->port);
  unsigned remoteIp = *(int *)connection->GetInfo(message)->remoteAddress->ipaddr;
  print_ip(remoteIp);
  printf(":%u\n", connection->GetInfo(message)->remoteAddress->port);
  return 0;
}

int RequestHeaders(HttpHandle *message, ConnectionFunctions *connection, RequestFunctions *request, void *connContext)
{
  printf("HTTP request headers[\n");
  char **headers;
  unsigned long size;
  request->GetHeadersList(message, &(headers), &size);
  unsigned int i;
  for (i = 0; i < size; i++)
  {
    printf("%s\n", headers[i]);
  }
  printf("]\n");
  request->FreeHeadersList(message, headers, size);
  return 0;
}

int RequestComplete(HttpHandle *message, ConnectionFunctions *connection, RequestFunctions *request, void *connContext)
{
  printf("HTTP request body[%u][%s]\n", request->BodySize(message), request->Body(message));
  return 0;
}

int ResponseHeaders(HttpHandle *message, ConnectionFunctions *connection, const RequestFunctions *request, ResponseFunctions *response, void *connContext)
{
  printf("HTTP response headers[\n");
  char **headers;
  unsigned long size;
  response->GetHeadersList(message, &(headers), &size);
  unsigned int i;
  for (i = 0; i < size; i++)
  {
    printf("%s\n", headers[i]);
  }
  printf("]\n");
  response->FreeHeadersList(message, headers, size);
  return 0;
}

int Message(HttpHandle *message, const ConnectionFunctions *connection, const RequestFunctions *request, const ResponseFunctions *response, void *connContext)
{
  printf("HTTP response body[%u][%s]\n", response->ContentSize(message), response->Content(message));
  return 0;
}

int SSLDomain(HttpHandle *message, ConnectionFunctions *connection, const char *domain, void *connContext)
{
  printf("SSL Doamin[%s]\n", domain);
  return 0;
}

int OnRawData(HttpHandle *message, ConnectionFunctions *connection, RawDataFunctions *rawDataFcts, RawData *rawData, void *connContext)
{
  printf("raw data[%d][%u][%s]\n", rawData->direction, rawData->dataSize, (char *)rawData->data);
  return 0;
}

int ConnectionUnfiltered(HttpHandle *message, const ConnectionInfo *connectionInfo, UnfilterDetails *unfilterDetails)
{
  printf("ConnectionUnfiltered:");
  unsigned localIp = *(int *)connectionInfo->localAddress->ipaddr;
  print_ip(localIp);
  printf(":%u -> ", connectionInfo->localAddress->port);
  unsigned remoteIp = *(int *)connectionInfo->remoteAddress->ipaddr;
  print_ip(remoteIp);
  printf(":%u, ", connectionInfo->remoteAddress->port);
  std::cout << "pid " << connectionInfo->processId << ", ";
  std::cout << "path:" << wcslen(connectionInfo->processPath) << ", ";
  std::wcout << L"[" << connectionInfo->processPath << L"]" << std::endl;
  std::wcout << "unfiltered reason " << unfilterDetails->reason << std::endl;
  std::cout << "Http_IsPathInExclustions: " << Http_IsPathInExclustions(connectionInfo->processPath) << std::endl;
  return 0;
}

static const char *level_names[] = {
    "TRACE", "DEBUG", "INFO", "WARN", "ERROR", "FATAL"};
static const char *level_colors[] = {
    "\x1b[94m", "\x1b[36m", "\x1b[32m", "\x1b[33m", "\x1b[31m", "\x1b[35m"};
void my_log(int level, const char *file, int line, const char *fmt, va_list args)
{
  /* Get current time */
  time_t t = time(NULL);
  struct tm *lt = localtime(&t);

  /* Log to stderr */

  char buf[16];
  buf[strftime(buf, sizeof(buf), "%H:%M:%S", lt)] = '\0';
  fprintf(
      stdout, "%s %s%-5s\x1b[0m \x1b[90m%s:%d:\x1b[0m ",
      buf, level_colors[level], level_names[level], file, line);
  vfprintf(stdout, fmt, args);
  fprintf(stdout, "\n");
  fflush(stdout);
}

unsigned short ports[] = {22, 80, 443, 3000};
int main()
{
  int ret;
  HttpCbks cbks = {0};
  // Create and zero the structure
  HttpInitParams params = {0};
  // Enable log std output
  params.logEnable = 1;
  params.logCb = my_log;
  // Make the SDK to monitor all port numbers from 1 to 65535
  PortRange range;
  range.start = 443;
  range.end = 443;
  params.remotePortRanges = &range;
  params.remotePortRangesCount = 1;
  // Enable cloud scan for URL
  params.cloudScanEnable = 1;
  // Enable cloud scan for SSL domain
  params.cloudScanForSSLEnable = 1;
  // Now we can initialize the SDK
  ret = Http_Initialize(&params);

  // Http_AddFolderExclusion(L"/opt/google/chrome");
  Http_AddFolderExclusion(L"/usr/bin");

  printf("Http_Initialize result:%d\n", ret);
  // cbks.NewConnection = NewConnection;
  // cbks.ConnectionDestroyed = ConnectionDestroyed;
  // cbks.RequestHeaders = RequestHeaders;
  // cbks.RequestComplete = RequestComplete;
  // cbks.ResponseHeaders = ResponseHeaders;
  // cbks.Message = Message;
  cbks.SSLDomain = SSLDomain;
  cbks.OnRawData = OnRawData;
  cbks.ConnectionUnfiltered = ConnectionUnfiltered;
  ret = Http_SetCallbacks(&cbks);
  printf("Http_SetCallbacks result:%d\n", ret);
  ret = Http_Start();
  printf("Http_Start result:%d\n", ret);
  printf("waiting for input to exit\n");
  getchar();
  ret = Http_Stop();
  printf("Http_Stop result:%d\n", ret);
  ret = Http_Uninitialize();
  printf("Http_Uninitialize result:%d\n", ret);
  return 0;
}
