#include "URLCache.h"
#include <pthread.h>
#include "log.h"

/* URL cache collection*/
urlTireTree URLs = {0};

static pthread_mutex_t urlCacheMutex = PTHREAD_MUTEX_INITIALIZER;

static unsigned char urlCacheInitFlag = 0;

/**
* @returns error: -1, not exist: 0, exist: 1
*/
int isUrlExist(const char *url, size_t urlLen, urlTireNode **node)
{
  urlTireNode *current = &(URLs.root);
  if (strlen(url) != urlLen)
  {
    COMMON_ERROR_PRINT("url len doesn't match");
    return -1;
  }
  if (urlCacheInitFlag == 0)
  {
    return -1;
  }
  for (unsigned int i = 0; i < urlLen; i++)
  {
    unsigned char character = (unsigned char)url[i];
    if (character < 0 || character >= URL_CHARACTER_SIZE)
    {
      COMMON_ERROR_PRINT("url character error");
      return -1;
    }
    urlTireNode *node = current->nodes[character];
    if (node == NULL)
    {
      return 0;
    }
    current = node;
  }
  if (current != NULL && current->end == 1)
  {
    if (node != NULL)
    {
      *node = current;
    }
    return 1;
  }
  return 0;
}

/**
* @returns error: -1, success: 0, already exist: 1
*/
int addUrlCache(const char *url, size_t urlLen, CloudResponse *cloudResp)
{
  urlTireNode *current = &(URLs.root);
  int ret = 0;
  if (strlen(url) != urlLen || cloudResp == NULL)
  {
    COMMON_ERROR_PRINT("url len doesn't match");
    return -1;
  }
  pthread_mutex_lock(&urlCacheMutex);
  if (isUrlExist(url, urlLen, NULL) != 0)
  {
    ret = 1;
    goto end;
  }
  if (urlCacheInitFlag == 0)
  {
    ret = -1;
    goto end;
  }
  for (unsigned int i = 0; i < urlLen; i++)
  {
    unsigned char character = (unsigned char)url[i];
    if (character < 0 || character >= URL_CHARACTER_SIZE)
    {
      COMMON_ERROR_PRINT("url character error");
      ret = -1;
      goto end;
    }
    if (current->nodes[character] == NULL)
    {
      urlTireNode *newNode = NULL;
      newNode = (urlTireNode *)calloc(1, sizeof(urlTireNode));
      if (newNode == NULL)
      {
        COMMON_ERROR_PRINT("urlTireNode malloc error");
        ret = -1;
        goto end;
      }
      if (i == urlLen - 1)
      {
        //at the end of url
        newNode->cloudResponse = (CloudResponse *)calloc(1, sizeof(CloudResponse));
        if (newNode->cloudResponse != NULL)
        {
          if (cloudResp->categories != NULL)
          {
            newNode->cloudResponse->categories = (char *)calloc(strlen(cloudResp->categories) + 1, sizeof(char));
            if (newNode->cloudResponse->categories != NULL)
            {
              strcpy((char *)newNode->cloudResponse->categories, (char *)cloudResp->categories);
            }
          }
          if (cloudResp->source != NULL)
          {
            newNode->cloudResponse->source = (char *)calloc(strlen(cloudResp->source) + 1, sizeof(char));
            if (newNode->cloudResponse->source != NULL)
            {
              strcpy((char *)newNode->cloudResponse->source, (char *)cloudResp->source);
            }
          }
          newNode->cloudResponse->isgrey = cloudResp->isgrey;
          newNode->cloudResponse->status = cloudResp->status;
          newNode->cloudResponse->status_message = cloudResp->status_message;
        }
        newNode->end = 1;
        URLs.number++;
        log_info("add url, URLs: %ld [%s]\n", URLs.number, url);
      }
      newNode->character = character;
      current->nodes[character] = newNode;
      newNode->parent = current;
      current->kidsCount++;
    }
    current = current->nodes[character];
  }
end:
  pthread_mutex_unlock(&urlCacheMutex);
  return ret;
}

/**
* @returns error: -1, success: 0, already exist: 1
*/
int deleteUrlCache(const char *url, size_t urlLen)
{
  urlTireNode *endNode = NULL;
  urlTireNode *tmp = NULL;
  int ret = 0;
  if (strlen(url) != urlLen)
  {
    COMMON_ERROR_PRINT("url len doesn't match");
    return -1;
  }
  pthread_mutex_lock(&urlCacheMutex);
  if (isUrlExist(url, urlLen, &endNode) != 1)
  {
    // url not exist or error
    ret = 1;
    goto end;
  }
  if (urlCacheInitFlag == 0)
  {
    ret = -1;
    goto end;
  }
  endNode->end = 0;
  tmp = endNode;
  if (urlCacheInitFlag == 0)
  {
    goto end;
  }
  //only the root node's parent is NULL
  while (tmp != NULL && tmp->parent != NULL && tmp->end != 1 && tmp->kidsCount <= 0)
  {
    urlTireNode *parent = tmp->parent;
    parent->kidsCount--;
    parent->nodes[tmp->character] = NULL;
    if (tmp->cloudResponse != NULL)
    {
      if (tmp->cloudResponse->categories != NULL)
      {
        free((char *)tmp->cloudResponse->categories);
      }
      if (tmp->cloudResponse->source != NULL)
      {
        free((char *)tmp->cloudResponse->source);
      }
      free(tmp->cloudResponse);
    }
    free(tmp);
    tmp = parent;
  }
  URLs.number--;
  log_info("delete url, URLs: %ld [%s]\n", URLs.number, url);
end:
  pthread_mutex_unlock(&urlCacheMutex);
  return ret;
}

void cleanUrlNodes(urlTireNode *node)
{
  for (int i = 0; i < URL_CHARACTER_SIZE; i++)
  {
    if (node->nodes[i] != NULL)
    {
      cleanUrlNodes(node->nodes[i]);
      node->nodes[i] = NULL;
    }
  }
  if (node->parent != NULL)
  {
    if (node->cloudResponse != NULL)
    {
      if (node->cloudResponse->categories != NULL)
      {
        free((char *)node->cloudResponse->categories);
      }
      if (node->cloudResponse->source != NULL)
      {
        free((char *)node->cloudResponse->source);
      }
      free(node->cloudResponse);
    }
    if (node->end == 1)
    {
      URLs.number--;
    }
    free(node);
  }
}

void cleanUrlCache()
{
  pthread_mutex_lock(&urlCacheMutex);
  urlTireNode *root = &(URLs.root);
  cleanUrlNodes(root);
  URLs.number = 0;
  urlCacheInitFlag = 0;
  pthread_mutex_unlock(&urlCacheMutex);
}

void initUrlCache()
{
  pthread_mutex_init(&urlCacheMutex, NULL);
  cleanUrlCache();
  pthread_mutex_lock(&urlCacheMutex);
  memset(&URLs, 0, sizeof(urlTireTree));
  urlCacheInitFlag = 1;
  pthread_mutex_unlock(&urlCacheMutex);
}

char urlContainer[2196] = {0};
void showUrls(urlTireNode *node)
{
  if (node->end == 1)
  {
    int i = 0;
    memset(urlContainer, 0, 2196);
    urlTireNode *tmp = node;
    while (tmp != NULL)
    {
      urlContainer[i++] = tmp->character;
      tmp = tmp->parent;
    }
    for (i = strlen(urlContainer) - 1; i >= 0; i--)
    {
      printf("%c", urlContainer[i]);
    }
    printf("\n");
  }
  for (int i = 0; i < URL_CHARACTER_SIZE; i++)
  {
    if (node->nodes[i] != NULL)
    {
      showUrls(node->nodes[i]);
    }
  }
}

void urlCacheTest()
{
  CloudResponse resp;
  char source[] = "source";
  char categories[] = "categories";
  resp.source = source;
  resp.categories = categories;

  memset(&URLs, 0, sizeof(urlTireTree));
  initUrlCache();
  addUrlCache("google.com", strlen("google.com"), &resp);
  addUrlCache("google3123.com", strlen("google3123.com"), &resp);
  addUrlCache("google.com999", strlen("google.com999"), &resp);

  addUrlCache("1234google.com", strlen("1234google.com"), &resp);
  addUrlCache("baidu.com", strlen("baidu.com"), &resp);
  addUrlCache("wxy.com", strlen("wxy.com"), &resp);
  addUrlCache("wxyyy.com", strlen("wxyyy.com"), &resp);
  addUrlCache("wxyyy.com123", strlen("wxyyy.com123"), &resp);
  showUrls(&(URLs.root));
  printf("google.com %d\n", isUrlExist("google.com", strlen("google.com"), NULL));
  printf("baidu.com %d\n", isUrlExist("baidu.com", strlen("baidu.com"), NULL));
  printf("wxyyy.com %d\n", isUrlExist("wxyyy.com", strlen("wxyyy.com"), NULL));
  printf("|\n");
  cleanUrlCache();
  addUrlCache("wxyyy.com123", strlen("wxyyy.com123"), &resp);
  showUrls(&(URLs.root));
  printf("\n");
  printf("google.com %d\n", isUrlExist("google.com", strlen("google.com"), NULL));
  printf("baidu.com %d\n", isUrlExist("baidu.com", strlen("baidu.com"), NULL));
  printf("wxyyy.com %d\n", isUrlExist("wxyyy.com", strlen("wxyyy.com"), NULL));
}

// int main()
// {
//   urlCacheTest();
// }