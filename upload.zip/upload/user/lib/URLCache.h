#ifndef URL_CAHCE_H
#define URL_CAHCE_H

#include "common.h"
#include "interface.h"

#define URL_CHARACTER_SIZE 128

typedef struct _urlTireNode
{
  unsigned char end;
  short kidsCount;
  unsigned char character;
  struct _urlTireNode *parent;
  struct _urlTireNode *nodes[URL_CHARACTER_SIZE];
  CloudResponse *cloudResponse;
} urlTireNode;

typedef struct _urlTireTree
{
  urlTireNode root;
  unsigned long number;
} urlTireTree;

int isUrlExist(const char *url, size_t urlLen, urlTireNode **node);
int addUrlCache(const char *url, size_t urlLen, CloudResponse *cloudResp);
// int deleteUrlCache(const char *url, size_t urlLen);
void cleanUrlCache();
void initUrlCache();

#endif