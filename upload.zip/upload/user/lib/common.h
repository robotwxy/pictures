/**
@file
@brief    interceptor common includes.
@details  Copyright (c) 2020 Acronis
@author   Bruce Wang (Bruce.Wang@acronis.com)
*/

#ifndef HTTP_COMMON_H
#define HTTP_COMMON_H

#include <stdlib.h>
#include <string.h>

#include "log.h"

#ifdef COMMON_DEBUG
#define DEBUG_PRINT printf
#else
#define DEBUG_PRINT(...) /*...*/
#endif

#define COMMON_ERROR
#ifdef COMMON_ERROR
#define COMMON_ERROR_PRINT log_error
#else
#define COMMON_ERROR_PRINT(...) /*...*/
#endif

#endif
