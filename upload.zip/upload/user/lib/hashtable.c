/**
@file
@brief    interceptor hashtable functions.
@details  Copyright (c) 2020 Acronis
@author   Bruce Wang (Bruce.Wang@acronis.com)
*/


#include "hashtable.h"
#include "common.h"
#include <pthread.h>

static pthread_mutex_t hashTableMutex = PTHREAD_MUTEX_INITIALIZER;

void travel_hashtable(struct hlist_head *hashtable, unsigned int size);

static unsigned short get_hash_code(unsigned short key)
{
  return key % HASHTABLE_SIZE;
}

static int hlist_add_head(struct hlist_head *h, struct hlist_node *n)
{
  struct hlist_node *first;
  if (h == NULL || n == NULL)
  {
    COMMON_ERROR_PRINT("%s: ptr is NULL", __func__);
    return -1;
  }
  first = h->first;
  n->next = first;
  if (first)
    first->pprev = &n->next;
  h->first = n;
  n->pprev = &h->first;
  return 0;
}

static int hlist_del_node(struct hlist_node *n)
{
  struct hlist_node *next = n->next;
  struct hlist_node **pprev = n->pprev;

  if (n == NULL)
  {
    COMMON_ERROR_PRINT("ptr is NULL");
    return -1;
  }

  *pprev = next;
  if (next)
    next->pprev = pprev;

  return 0;
}

int hash_init(struct hlist_head *hashtable, unsigned int size)
{
  if (hashtable == NULL)
  {
    COMMON_ERROR_PRINT("ptr is NULL");
    return -1;
  }
  memset(hashtable, 0, sizeof(struct hlist_head) * size);
  return 0;
}

static int hash_add(struct hlist_head *hashtable, struct hlist_node *n, unsigned short key)
{
  struct hlist_head *head = NULL;
  if (hashtable == NULL)
  {
    COMMON_ERROR_PRINT("ptr is NULL");
    return -1;
  }

  head = &(hashtable[key]);

  return hlist_add_head(head, n);
}

static int hash_del(struct hlist_node *n)
{
  return hlist_del_node(n);
}

struct hlist_node *hash_find_by_id(struct hlist_head *hashtable, unsigned long long id)
{
  struct hlist_head *head = NULL;
  struct hlist_node *node = NULL;
  unsigned short key = 0;
  if (hashtable == NULL)
  {
    COMMON_ERROR_PRINT("ptr is NULL");
    return NULL;
  }

  memcpy(&key, &id, sizeof(unsigned short));
  if (key == 0)
  {
    COMMON_ERROR_PRINT("invalid key");
    return NULL;
  }

  key = get_hash_code(key);

  head = &(hashtable[key]);

  if (head == NULL)
  {
    COMMON_ERROR_PRINT("ptr is NULL");
    return NULL;
  }
  for (node = head->first; node != NULL; node = node->next)
  {
    if (node->id == id)
    {
      return node;
    }
  }
  return NULL;
}

int hash_add_by_id(struct hlist_head *hashtable, struct hlist_node *n, unsigned long long id)
{
  unsigned short key = 0;
  struct hlist_node *foundNode = NULL;
  int ret = -1;
  pthread_mutex_lock(&hashTableMutex);
  if (n == NULL)
  {
    COMMON_ERROR_PRINT("ptr is NULL");
    ret = -1;
    goto end;
  }

  foundNode = hash_find_by_id(hashtable, id);
  if (foundNode != NULL)
  {
    COMMON_ERROR_PRINT("node exist");
    ret = -1;
    goto end;
  }

  memcpy(&key, &id, sizeof(unsigned short));
  if (key == 0)
  {
    COMMON_ERROR_PRINT("invalid key");
    ret = -1;
    goto end;
  }

  key = get_hash_code(key);

  n->id = id;
  ret = hash_add(hashtable, n, key);
end:
  pthread_mutex_unlock(&hashTableMutex);
  return ret;
}

int hash_del_by_id(struct hlist_head *hashtable, unsigned long long id)
{
  struct hlist_node *n = NULL;
  int ret = -1;
  pthread_mutex_lock(&hashTableMutex);
  n = hash_find_by_id(hashtable, id);
  if (n == NULL)
  {
    COMMON_ERROR_PRINT("%s: node can't find", __func__);
    ret = -1;
    goto end;
  }
  ret = hash_del(n);
end:
  pthread_mutex_unlock(&hashTableMutex);
  return ret;
}

void travel_hashtable(struct hlist_head *hashtable, unsigned int size)
{
  unsigned int i;
  struct hlist_head *head = NULL;
  struct hlist_node *node = NULL;
  for (i = 0; i < size; i++)
  {
    head = &(hashtable[i]);
    if (head != NULL)
    {
      for (node = head->first; node != NULL; node = node->next)
      {
        // unsigned char *idPtr = (unsigned char *)&node->id;
        // HASHTABLE_DEBUG_PRINT("travel_hashtable[%u]: ", i);
        // HASHTABLE_DEBUG_PRINT("node_id[0x%02x%02x%02x%02x%02x%02x%02x%02x]",
        //                       idPtr[1], idPtr[0], idPtr[2], idPtr[3], idPtr[4], idPtr[5], idPtr[6], idPtr[7]);
      }
    }
  }
}
