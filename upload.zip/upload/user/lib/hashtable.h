/**
@file
@brief    interceptor hashtable functions.
@details  Copyright (c) 2020 Acronis
@author   Bruce Wang (Bruce.Wang@acronis.com)
*/

#ifndef HTTP_HAHSTABLE_H
#define HTTP_HAHSTABLE_H

#define HASHTABLE_SIZE 1024

//#define HASHTABLE_DEBUG
#ifdef HASHTABLE_DEBUG
#define HASHTABLE_DEBUG_PRINT log_debug
#else
#define HASHTABLE_DEBUG_PRINT(...) /*...*/
#endif

struct hlist_node
{
  unsigned long long id;
  //Connection *conn;
  struct hlist_node *next, **pprev;
};

struct hlist_head
{
  struct hlist_node *first;
};

int hash_add_by_id(struct hlist_head *hashtable, struct hlist_node *n, unsigned long long id);
int hash_del_by_id(struct hlist_head *hashtable, unsigned long long id);
struct hlist_node *hash_find_by_id(struct hlist_head *hashtable, unsigned long long id);

#endif
