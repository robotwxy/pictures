/**
@file
@brief    interceptor HTTP related functions.
@details  Copyright (c) 2020 Acronis
@author   Bruce Wang (Bruce.Wang@acronis.com)
*/

#include "common.h"
#include "interceptor.h"
#include "zlibFunctions.h"
#include "interface_functions.h"
#include "http_parser_callbacks.h"
// #include "hashtable.h"
#include "http_functions.h"
#include "path_exclusions.h"
#include "https.h"

#include <errno.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <wchar.h>

int compareHeader(const char *header1, const char *header2)
{
  char c1, c2;
  unsigned int len1, len2, i;
  if (header1 == NULL || header2 == NULL)
  {
    COMMON_ERROR_PRINT("ptr is NULL");
    return -1;
  }
  len1 = strlen(header1);
  len2 = strlen(header2);
  if (len1 != len2)
  {
    return 1;
  }
  for (i = 0; i < len1; i++)
  {
    c1 = header1[i];
    c2 = header2[i];
    if (c1 >= 65 && c1 <= 90)
    {
      c1 += 32;
    }
    if (c2 >= 65 && c2 <= 90)
    {
      c2 += 32;
    }
    if (c1 != c2)
    {
      return 1;
    }
  }
  return 0;
}

const char *findHeader(struct Header *headers, unsigned int headersLen, const char *headerName)
{
  unsigned int i;
  struct Header *header = NULL;
  if (headers == NULL)
  {
    return NULL;
  }
  for (i = 0; i < headersLen; i++)
  {
    header = &(headers[i]);
    if (header == NULL)
    {
      continue;
    }
    if (header->name == NULL || header->value == NULL)
    {
      continue;
    }
    if (compareHeader(header->name, headerName) == 0)
    {
      return (const char *)header->value;
    }
  }
  return NULL;
}

const char *findHeaderValue(struct Header *headers, unsigned int headersLen, const char *headerName, const char *headerValue)
{
  unsigned int i;
  struct Header *header = NULL;
  if (headers == NULL)
  {
    return NULL;
  }
  for (i = 0; i < headersLen; i++)
  {
    header = &(headers[i]);
    if (header == NULL)
    {
      continue;
    }
    if (header->name == NULL || header->value == NULL)
    {
      continue;
    }
    if (compareHeader(header->name, headerName) == 0 && compareHeader(header->value, headerValue) == 0)
    {
      return (const char *)header->value;
    }
  }
  return NULL;
}

/**
* find header from header list by header name and replace header value, heaer name case-insensitive
* @param[in] headers - headers list
* @param[in] headersLen - list length
* @param[in] headerName - header name to find
* @param[in] headerValue - header value to replace
* @returns -1 on error, 0 on success
*/
int setHedaer(struct Header **headers, unsigned int *headersLen, const char *headerName, const char *headerValue)
{
  unsigned int i;
  struct Header *header = NULL;
  struct Header *headersPtr = *headers;
  if (headersPtr == NULL)
  {
    headersPtr = (struct Header *)malloc(sizeof(struct Header));
    *headersLen = 0;
  }
  if (headersPtr == NULL)
  {
    return -1;
  }
  for (i = 0; i < (*headersLen); i++)
  {
    header = &(headersPtr[i]);
    if (header == NULL)
    {
      continue;
    }
    if (header->name == NULL || header->value == NULL)
    {
      continue;
    }
    if (compareHeader(header->name, headerName) == 0)
    {
      header->value = (char *)realloc(header->value, strlen(headerValue) + 1);
      if (header->value == NULL)
      {
        COMMON_ERROR_PRINT("malloc failed");
        header->valueLen = 0;
        return -1;
      }
      memcpy(header->value, headerValue, strlen(headerValue));
      header->value[strlen(headerValue)] = 0;
      header->valueLen = strlen(headerValue);
      return 0;
    }
  }
  //not found, insert new header in to header list
  headersPtr = (struct Header *)realloc(headersPtr, ((*headersLen) + 1) * sizeof(struct Header));
  if (headersPtr == NULL)
  {
    COMMON_ERROR_PRINT("malloc failed");
    (*headersLen) = 0;
    return -1;
  }
  header = &(headersPtr[(*headersLen)]);
  if (header == NULL)
  {
    COMMON_ERROR_PRINT("ptr NULL");
    return -1;
  }

  memset(header, 0, sizeof(struct Header));
  header->name = (char *)malloc(strlen(headerName) + 1);
  if (header->name == NULL)
  {
    COMMON_ERROR_PRINT("malloc failed");
    return -1;
  }
  header->value = (char *)malloc(strlen(headerValue) + 1);
  if (header->value == NULL)
  {
    COMMON_ERROR_PRINT("malloc failed");
    return -1;
  }
  memcpy(header->name, headerName, strlen(headerName));
  header->name[strlen(headerName)] = 0;
  header->nameLen = strlen(headerName);
  memcpy(header->value, headerValue, strlen(headerValue));
  header->value[strlen(headerValue)] = 0;
  header->valueLen = strlen(headerValue);

  (*headersLen) = (*headersLen) + 1;
  *headers = headersPtr;
  return 0;
}

int getHeaderList(struct Header *myHeaders, unsigned int headersLen, char ***headers, unsigned long *size)
{
  char *headerStr = NULL;
  if (myHeaders == NULL)
  {
    return -1;
  }
  char **newHeaders = (char **)malloc(sizeof(char *) * headersLen);
  if (newHeaders == NULL)
  {
    return -1;
  }
  unsigned int i;
  for (i = 0; i < headersLen; i++)
  {
    struct Header *header = &(myHeaders[i]);
    if (header == NULL)
    {
      continue;
    }
    if (header->name == NULL || header->value == NULL)
    {
      continue;
    }
    headerStr = (char *)malloc(header->nameLen + header->valueLen + 3);
    if (headerStr == NULL)
    {
      COMMON_ERROR_PRINT("malloc failed");
      continue;
    }
    memcpy(headerStr, header->name, header->nameLen);
    headerStr[header->nameLen] = ':';
    headerStr[header->nameLen + 1] = ' ';
    memcpy(headerStr + header->nameLen + 2, header->value, header->valueLen);
    headerStr[header->nameLen + header->valueLen + 2] = 0;
    newHeaders[(*size)] = headerStr;
    (*size)++;
  }
  *headers = newHeaders;
  return 0;
}

int deleteAllHeader(struct Header **headers, unsigned int *headersLen)
{
  unsigned int i;
  struct Header *headersPtr = *headers;
  if (headersPtr == NULL)
  {
    return -1;
  }
  for (i = 0; i < (*headersLen); i++)
  {
    struct Header *header = &(headersPtr[i]);
    if (header == NULL)
    {
      continue;
    }
    if (header->name != NULL)
    {
      free(header->name);
    }
    if (header->value != NULL)
    {
      free(header->value);
    }
  }
  headersPtr = (struct Header *)realloc(headersPtr, sizeof(struct Header));
  *headers = headersPtr;
  *headersLen = 0;
  return 0;
}

int deleteHeader(struct Header *headers, unsigned int headersLen, const char *headerName)
{
  unsigned int i;
  struct Header *header;
  if (headers == NULL)
  {
    return -1;
  }
  for (i = 0; i < headersLen; i++)
  {
    header = &(headers[i]);
    if (header == NULL)
    {
      continue;
    }
    if (header->name == NULL || header->value == NULL)
    {
      continue;
    }
    if (compareHeader(header->name, headerName) == 0)
    {
      free(header->name);
      free(header->value);
      header->name = NULL;
      header->value = NULL;
      return 0;
    }
  }
  return 1;
}

int sendReqResp(int toSocket, struct HttpStartLine *startLine, struct Header **headers, unsigned int *headersNum, struct Body *body)
{
  unsigned int headerLen = 0;
  unsigned int i = 0;
  unsigned int cur = 0;
  struct Header *header = NULL;
  char *headerBuf = NULL;
  ssize_t m;
  if (toSocket == 0)
  {
    return -1;
  }
  if (headers == NULL || startLine == NULL || body == NULL)
  {
    COMMON_ERROR_PRINT("ptr is NULL");
    return -1;
  }

  if ((body->flags & BODY_IS_CHUNKED) <= 0)
  {
    if (findHeader(*headers, *headersNum, "Transfer-Encoding") != NULL)
    {
      //delete chunked header if body is not chunked
      if (findHeaderValue(*headers, *headersNum, "Transfer-Encoding", "chunked") != NULL)
      {
        deleteHeader(*headers, *headersNum, "Transfer-Encoding");
      }
    }
    //set content-length for non-chunked body
    if (body->str != NULL)
    {
      //modify content length in body
      char lengthBuf[64];
      memset(lengthBuf, 0, 64);
      sprintf(lengthBuf, "%llu", body->contentLength);
      setHedaer(headers, headersNum, "Content-Length", lengthBuf);
    }
  }

  if (findHeader(*headers, *headersNum, "Content-Encoding") != NULL)
  {
    if ((body->flags & BODY_IS_GZIP) <= 0)
    {
      //delete gzip header if body is not gzip
      if (findHeaderValue(*headers, *headersNum, "Content-Encoding", "gzip") != NULL)
      {
        deleteHeader(*headers, *headersNum, "Content-Encoding");
      }
    }
  }

  struct Header *headersPtr = *headers;

  //caculate header len
  switch (startLine->httpType)
  {
  case HTTP_REQ:
    headerLen += (startLine->method.len + startLine->url.len + startLine->version.len + 2); // 2 for 2 spaces
    break;
  case HTTP_RESP:
    headerLen += (startLine->version.len + startLine->status.len + startLine->reason.len + 2); // 2 for 2 spaces
    break;
  default:
    log_error("start line's http type should not be null");
    return -1;
    break;
  }

  headerLen += 2; // "\r\n"
  for (i = 0; i < *headersNum; i++)
  {
    header = &(headersPtr[i]);
    if (header == NULL)
    {
      continue;
    }
    if (header->name == NULL || header->value == NULL)
    {
      continue;
    }
    headerLen += header->nameLen + 2 + header->valueLen + 2; // ": " and "\r\n"
  }

  headerLen += 2; // "\r\n"

  headerBuf = (char *)malloc(headerLen + 1);
  if (headerBuf == NULL)
  {
    COMMON_ERROR_PRINT("malloc failed");
    return -1;
  }
  memset(headerBuf, 0, headerLen + 1);

  //assmeble header
  switch (startLine->httpType)
  {
  case HTTP_REQ:
    if (startLine->method.str != NULL)
    {
      memcpy(headerBuf + cur, startLine->method.str, startLine->method.len);
      cur += startLine->method.len;
      headerBuf[cur] = ' ';
      cur += 1;
    }
    if (startLine->url.str != NULL)
    {
      memcpy(headerBuf + cur, startLine->url.str, startLine->url.len);
      cur += startLine->url.len;
      headerBuf[cur] = ' ';
      cur += 1;
    }
    if (startLine->version.str != NULL)
    {
      memcpy(headerBuf + cur, startLine->version.str, startLine->version.len);
      cur += startLine->version.len;
    }
    break;
  case HTTP_RESP:
    if (startLine->version.str != NULL)
    {
      memcpy(headerBuf + cur, startLine->version.str, startLine->version.len);
      cur += startLine->version.len;
      headerBuf[cur] = ' ';
      cur += 1;
    }
    if (startLine->status.str != NULL)
    {
      memcpy(headerBuf + cur, startLine->status.str, startLine->status.len);
      cur += startLine->status.len;
      headerBuf[cur] = ' ';
      cur += 1;
    }
    if (startLine->reason.str != NULL)
    {
      memcpy(headerBuf + cur, startLine->reason.str, startLine->reason.len);
      cur += startLine->reason.len;
    }
    break;
  default:
    log_error("start line's http type should not be null");
    return -1;
  }

  headerBuf[cur] = 0x0d;     // "\r"
  headerBuf[cur + 1] = 0x0a; //	"\n"
  cur += 2;
  for (i = 0; i < *headersNum; i++)
  {
    header = &(headersPtr[i]);
    if (header == NULL)
    {
      continue;
    }
    if (header->name == NULL || header->value == NULL)
    {
      continue;
    }
    memcpy(headerBuf + cur, header->name, header->nameLen);
    cur += header->nameLen;
    headerBuf[cur] = ':';
    headerBuf[cur + 1] = ' ';
    cur += 2;
    memcpy(headerBuf + cur, header->value, header->valueLen);
    cur += header->valueLen;
    headerBuf[cur] = 0x0d;     //	"\r"
    headerBuf[cur + 1] = 0x0a; //	"\n"
    cur += 2;
  }
  headerBuf[cur] = 0x0d;     //	"\r"
  headerBuf[cur + 1] = 0x0a; //	"\n"
  cur += 2;

  if (cur != headerLen)
  {
    COMMON_ERROR_PRINT("request buffer size not match");
    goto end;
  }
  //log_trace("send header[%s]", headerBuf);
  m = send(toSocket, headerBuf, headerLen, 0);
  if (m != headerLen)
  {
    COMMON_ERROR_PRINT("send failed:%d", errno);
  }

  //assmeble body and send
  if (body->str != NULL)
  {
    ssize_t m;
    body->contentLength = body->currentLength;
    if ((body->flags & BODY_IS_CHUNKED) > 0)
    {
      //chunked body need special format: len\r\nbody\r\n
      char tmpbuf[32];
      memset(tmpbuf, 0, 32);
      sprintf(tmpbuf, "%llx%c%c", body->contentLength, 0x0d, 0x0a);
      send(toSocket, tmpbuf, strlen(tmpbuf), 0); //	"len\r\n"

      m = send(toSocket, body->str, body->contentLength, 0);
      if ((unsigned long long)m != body->contentLength)
      {
        COMMON_ERROR_PRINT("send failed\n");
      }

      memset(tmpbuf, 0, 32);
      sprintf(tmpbuf, "%c%c", 0x0d, 0x0a);
      send(toSocket, tmpbuf, strlen(tmpbuf), 0); //	"\r\n"
    }
    else
    {
      m = send(toSocket, body->str, body->contentLength, 0);
      if ((unsigned long long)m != body->contentLength)
      {
        COMMON_ERROR_PRINT("send failed errno:%d", errno);
      }
    }
    //log_trace("send body[%s][%u][%x][%u]", body->str, body->contentLength, body->contentLength, m);
  }
end:
  free(headerBuf);
  return 0;
}

int getStartLine(const char *buffer, unsigned long bufferLen, struct HttpStartLine *startLine, unsigned char httpType)
{
  if (buffer == NULL || startLine == NULL)
  {
    COMMON_ERROR_PRINT("ptr is NULL");
    return -1;
  }

  unsigned int i = 0;
  char *lineStart = NULL;
  char *lineEnd = NULL;
  unsigned int lineLen = 0;
  lineStart = (char *)buffer;
  for (i = 0; i < bufferLen; i++)
  {
    if (buffer[i] == 0x0d) //CR
    {
      lineEnd = (char *)(buffer + i);
      break;
    }
  }
  if (lineEnd == NULL)
  {
    return -1;
  }
  lineLen = i;

  switch (httpType)
  {
  case HTTP_REQ:
  {
    startLine->httpType = HTTP_REQ;
    unsigned int j;
    char *methodStart = lineStart;
    char *methodEnd = NULL;
    unsigned int methodLen = 0;
    char *urlStart = NULL;
    char *urlEnd = NULL;
    unsigned int urlLen = 0;
    char *versionStart = NULL;
    char *versionEnd = NULL;
    unsigned int versionLen = 0;
    for (j = 0; j < lineLen; j++)
    {
      if (methodStart[j] == ' ')
      {
        methodEnd = (char *)(methodStart + j);
        methodLen = j;
        break;
      }
    }
    if (methodEnd == NULL)
    {
      return -1;
    }
    urlStart = (char *)(methodEnd + 1);
    for (j = 0; j < lineLen - methodLen; j++)
    {
      if (urlStart[j] == ' ')
      {
        urlEnd = (char *)(urlStart + j);
        urlLen = j;
        break;
      }
    }
    if (urlEnd == NULL)
    {
      return -1;
    }
    versionStart = (char *)(urlEnd + 1);
    for (j = 0; j < lineLen - methodLen - urlLen; j++)
    {
      if (versionStart[j] == 0x0d)
      {
        versionEnd = (char *)(versionStart + j);
        versionLen = j;
        break;
      }
    }
    if (versionEnd == NULL)
    {
      return -1;
    }
    startLine->method.str = (char *)malloc(methodLen + 1);
    startLine->url.str = (char *)malloc(urlLen + 1);
    startLine->version.str = (char *)malloc(versionLen + 1);
    if (startLine->method.str == NULL || startLine->url.str == NULL || startLine->version.str == NULL)
    {
      if (startLine->method.str != NULL)
      {
        free(startLine->method.str);
      }
      if (startLine->url.str != NULL)
      {
        free(startLine->url.str);
      }
      if (startLine->version.str != NULL)
      {
        free(startLine->version.str);
      }
      return -1;
    }

    memset(startLine->method.str, 0, methodLen + 1);
    memset(startLine->url.str, 0, urlLen + 1);
    memset(startLine->version.str, 0, versionLen + 1);

    memcpy(startLine->method.str, methodStart, methodLen);
    startLine->method.len = methodLen;
    memcpy(startLine->url.str, urlStart, urlLen);
    startLine->url.len = urlLen;
    memcpy(startLine->version.str, versionStart, versionLen);
    startLine->version.len = versionLen;

    //log_trace("method: %s, url: %s, version: %s", startLine->method.str, startLine->url.str, startLine->version.str);
    break;
  }
  case HTTP_RESP:
  {
    startLine->httpType = HTTP_RESP;
    unsigned int j;
    char *versionStart = lineStart;
    char *versionEnd = NULL;
    unsigned int versionLen = 0;
    char *statusStart = NULL;
    char *statusEnd = NULL;
    unsigned int statusLen = 0;
    char *reasonStart = NULL;
    char *reasonEnd = NULL;
    unsigned int reasonLen = 0;
    for (j = 0; j < lineLen; j++)
    {
      if (versionStart[j] == ' ')
      {
        versionEnd = (char *)(versionStart + j);
        versionLen = j;
        break;
      }
    }
    if (versionEnd == NULL)
    {
      return -1;
    }
    statusStart = (char *)(versionEnd + 1);
    for (j = 0; j < lineLen - versionLen; j++)
    {
      if (statusStart[j] == ' ')
      {
        statusEnd = (char *)(statusStart + j);
        statusLen = j;
        break;
      }
    }
    if (statusEnd == NULL)
    {
      return -1;
    }
    reasonStart = (char *)(statusEnd + 1);
    for (j = 0; j < lineLen - versionLen - statusLen; j++)
    {
      if (reasonStart[j] == 0x0d)
      {
        reasonEnd = (char *)(reasonStart + j);
        reasonLen = j;
        break;
      }
    }
    if (reasonEnd == NULL)
    {
      return -1;
    }
    startLine->version.str = (char *)malloc(versionLen + 1);
    startLine->status.str = (char *)malloc(statusLen + 1);
    startLine->reason.str = (char *)malloc(reasonLen + 1);
    if (startLine->version.str == NULL || startLine->status.str == NULL || startLine->reason.str == NULL)
    {
      if (startLine->version.str != NULL)
      {
        free(startLine->version.str);
      }
      if (startLine->status.str != NULL)
      {
        free(startLine->status.str);
      }
      if (startLine->reason.str != NULL)
      {
        free(startLine->reason.str);
      }
      return -1;
    }
    memset(startLine->version.str, 0, versionLen + 1);
    memset(startLine->status.str, 0, statusLen + 1);
    memset(startLine->reason.str, 0, reasonLen + 1);

    memcpy(startLine->version.str, versionStart, versionLen);
    startLine->version.len = versionLen;
    memcpy(startLine->status.str, statusStart, statusLen);
    startLine->status.len = statusLen;
    memcpy(startLine->reason.str, reasonStart, reasonLen);
    startLine->reason.len = reasonLen;

    //log_trace("version: %s, status: %s, reason: %s", startLine->version.str, startLine->status.str, startLine->reason.str);
    break;
  }
  default:
    return -1;
  }
  return 0;
}

int cleanStartLine(struct HttpStartLine *startLine)
{
  if (startLine != NULL)
  {
    switch (startLine->httpType)
    {
    case HTTP_REQ:
      if (startLine->method.str != NULL)
      {
        free(startLine->method.str);
        startLine->method.str = NULL;
      }
      if (startLine->url.str != NULL)
      {
        free(startLine->url.str);
        startLine->url.str = NULL;
      }
      if (startLine->realUrl.str != NULL)
      {
        free(startLine->realUrl.str);
        startLine->realUrl.str = NULL;
      }
      if (startLine->version.str != NULL)
      {
        free(startLine->version.str);
        startLine->version.str = NULL;
      }
      break;
    case HTTP_RESP:
      if (startLine->version.str != NULL)
      {
        free(startLine->version.str);
        startLine->version.str = NULL;
      }
      if (startLine->status.str != NULL)
      {
        free(startLine->status.str);
        startLine->status.str = NULL;
      }
      if (startLine->reason.str != NULL)
      {
        free(startLine->reason.str);
        startLine->reason.str = NULL;
      }
      break;
    default:
      return -1;
      break;
    }
  }
  return 0;
}

int cleanMembersInReqResp(struct HttpStartLine *startLine, struct Header **headers, unsigned int headersLen, struct Body *body)
{
  struct Header *tmpHeader;
  cleanStartLine(startLine);
  if (headers != NULL)
  {
    tmpHeader = *headers;
    unsigned int i = 0;
    for (; i < headersLen; i++)
    {
      struct Header *header = &(tmpHeader[i]);
      if (header == NULL)
      {
        continue;
      }
      if (header->name != NULL)
      {
        free(header->name);
        header->name = NULL;
      }
      if (header->value != NULL)
      {
        free(header->value);
        header->value = NULL;
      }
    }
    free(tmpHeader);
    *headers = NULL;
  }
  if (body != NULL)
  {
    if (body->str != NULL)
    {
      free(body->str);
      body->str = NULL;
    }
  }
  //memset(req, 0, sizeof(Request));
  return 0;
}

int reqRespIdGenerator(unsigned char *idPtr, unsigned short reqCount, unsigned short respCount)
{
  if (idPtr == NULL)
  {
    COMMON_ERROR_PRINT("ptr is NULL");
    return -1;
  }
  memcpy(idPtr + sizeof(unsigned char) * 4, &reqCount, sizeof(unsigned short));
  memcpy(idPtr + sizeof(unsigned char) * 6, &respCount, sizeof(unsigned short));
  return 0;
}

int unzipBody(struct Body *body)
{
  if (body == NULL)
  {
    return -1;
  }
  if (body->str == NULL)
  {
    return -1;
  }
  body->contentLength = body->currentLength;
  char *outData = (char *)malloc(body->contentLength * 4);
  if (outData == NULL)
  {
    return -1;
  }
  unsigned long totalOut = 0;
  memset(outData, 0, body->contentLength * 4);
  chunkInflate(body->str, body->contentLength, outData, body->contentLength * 4, &totalOut);

  body->str = (char *)realloc(body->str, totalOut + 1);
  memset(body->str, 0, totalOut + 1);
  memcpy(body->str, outData, totalOut);
  body->str[totalOut] = 0;
  body->contentLength = totalOut;
  body->currentLength = totalOut;
  free(outData);

  body->flags &= ~(BODY_IS_GZIP);

  return 0;
}

Request *completeRequest(Connection *conn)
{
  Request *req = NULL;
  if (conn == NULL)
  {
    COMMON_ERROR_PRINT("conn == NULL");
    return NULL;
  }
  req = conn->currentReqPtr;
  conn->requestCount++;

  if ((req->body.flags & BODY_IS_GZIP) > 0 && (req->body.flags & BODY_IS_TOO_LARGE) <= 0)
  {
    unzipBody(&(req->body));
  }

  if ((req->body.flags & BODY_IS_CHUNKED) > 0 && (req->body.flags & BODY_IS_TOO_LARGE) <= 0)
  {
    req->body.flags &= ~(BODY_IS_CHUNKED); //when recv whole chunked body, we forward with non-chunked body
    req->body.contentLength = req->body.currentLength;
  }

  return req;
}

Response *completeResponse(Connection *conn)
{
  Response *resp = NULL;
  if (conn == NULL)
  {
    COMMON_ERROR_PRINT("conn == NULL");
    return NULL;
  }

  resp = conn->currentRespPtr;
  conn->responseCount++;
  if ((resp->body.flags & BODY_IS_GZIP) > 0 && (resp->body.flags & BODY_IS_TOO_LARGE) <= 0)
  {
    unzipBody(&(resp->body));
  }

  if ((resp->body.flags & BODY_IS_CHUNKED) > 0 && (resp->body.flags & BODY_IS_TOO_LARGE) <= 0)
  {
    resp->body.flags &= ~(BODY_IS_CHUNKED); //when recv whole chunked body, we forward with non-chunked body
    resp->body.contentLength = resp->body.currentLength;
  }
  return resp;
}

int cleanRequest(Request *req)
{
  if (req == NULL)
  {
    return -1;
  }

  cleanMembersInReqResp(&(req->startLine), &(req->headers), req->headersLen, &(req->body));
  memset(req, 0, sizeof(Request));
  setRequestFunctions(&(req->requestFunctions));

  return 0;
}

int cleanResponses(Response *resp)
{
  if (resp == NULL)
  {
    return -1;
  }

  cleanMembersInReqResp(&(resp->startLine), &(resp->headers), resp->headersLen, &(resp->body));
  memset(resp, 0, sizeof(Response));
  setResponseFunctions(&(resp->responseFunctions));
  return 0;
}

int assembleHeaderField(struct Header *header, const char *at, size_t length)
{
  header->name = (char *)malloc(length + 1);
  if (header->name == NULL)
  {
    COMMON_ERROR_PRINT("malloc failed");
    return -1;
  }
  memcpy(header->name, at, length);
  header->name[length] = 0;
  header->nameLen = length;
  return 0;
}

static char transferEncodingStr[] = "Transfer-Encoding";
static char chunkedStr[] = "chunked";
static char contentEncodingStr[] = "Content-Encoding";
static char gzipStr[] = "gzip";
static char contentLengthStr[] = "Content-Length";

extern unsigned int gHttpMaxBodySize;

int assembleHeaderValue(struct Header *header, const char *at, size_t length, struct Body *body)
{
  header->value = (char *)malloc(length + 1);
  if (header->value == NULL)
  {
    COMMON_ERROR_PRINT("malloc failed");
    return -1;
  }
  memcpy(header->value, at, length);
  header->value[length] = 0;
  header->valueLen = length;
  char *ret;
  if (strcmp(header->name, transferEncodingStr) == 0)
  {
    ret = strstr(header->value, chunkedStr);
    if (ret != NULL)
    {
      body->flags |= BODY_IS_CHUNKED;
    }
  }
  else if (strcmp(header->name, contentEncodingStr) == 0)
  {
    ret = strstr(header->value, gzipStr);
    if (ret != NULL)
    {
      body->flags |= BODY_IS_GZIP;
    }
  }
  else if (strcmp(header->name, contentLengthStr) == 0)
  {
    body->contentLength = (unsigned long long)atoll(header->value);
  }
  return 0;
}

int assembleBody(struct Body *body, const char *at, size_t length)
{
  if ((body->flags & BODY_IS_TOO_LARGE) > 0)
  {
    return -1;
  }
  if (body->currentLength + length > gHttpMaxBodySize)
  {
    body->flags |= BODY_IS_TOO_LARGE;
    return -1;
  }
  if (body->str == NULL)
  {
    body->str = (char *)malloc(body->currentLength + 1);
    memset(body->str, 0, body->currentLength + 1);
  }

  body->currentLength += length;
  body->str = (char *)realloc(body->str, body->currentLength + 1);
  if (body->str == NULL)
  {
    COMMON_ERROR_PRINT("realloc failed");
    return -1;
  }
  memcpy(body->str + body->currentLength - length, at, length);
  body->str[body->currentLength] = 0;
  return 0;
}

int initBodyBuffer(struct Body *body)
{
  if (body == NULL)
  {
    return -1;
  }
  if (body->str != NULL)
  {
    free(body->str);
  }
  return 0;
}
// id: port[2] + ip last 2 bytes[2] + request count[2] + response count[2]
int connIdGenerator(unsigned char *idPtr, unsigned short port, unsigned char *ip)
{
  if (idPtr == NULL)
  {
    COMMON_ERROR_PRINT("ptr is NULL");
    return -1;
  }
  memcpy(idPtr, &port, sizeof(unsigned short));
  memcpy(idPtr + sizeof(unsigned char) * 2, ip + 2, 2 * sizeof(unsigned char));
  return 0;
}

static char procStr[] = "/proc/";
static char exeStr[] = "/exe";
static char lsofStr[] = "lsof -i :";
static char commandStr[] = "COMMAND";

#define STR_LONG_LEN 4096
#define STR_SHORT_LEN 128
char *getProcPathByPort(unsigned short port, unsigned long long *processId)
{
  char *pathResult = NULL;
  char popenResult[STR_LONG_LEN] = {0};
  char path[STR_LONG_LEN] = {0};
  char pidStr[STR_SHORT_LEN] = {0};
  char myPidStr[STR_SHORT_LEN] = {0};
  char pidPathStr[STR_LONG_LEN] = {0};
  char popenCmd[STR_SHORT_LEN] = {0};
  FILE *fp = NULL;
  char space[] = " ";
  char *token = NULL;
  char *res = NULL;
  ssize_t pathLen = -1;
  *processId = 0;
  int pid = getpid();
  sprintf(myPidStr, "%d", pid);
  sprintf(popenCmd, "%s%u", lsofStr, port);
  fp = popen(popenCmd, "r");
  if (fp == NULL)
  {
    return pathResult;
  }
  res = fgets(popenResult, STR_LONG_LEN, fp);
  while (res != NULL)
  {
    char tmpPopenResult[STR_LONG_LEN];
    memcpy(tmpPopenResult, popenResult, STR_LONG_LEN);
    memset(popenResult, 0, STR_LONG_LEN);
    res = fgets(popenResult, STR_LONG_LEN, fp);
    if (memcmp(tmpPopenResult, commandStr, strlen(commandStr)) == 0) // ignore the line start with "COMMAND"
    {
      continue;
    }
    token = strtok(tmpPopenResult, space);
    if (token == NULL)
    {
      goto FAILED;
    }
    if (strcmp(token, "sh") == 0) // ignore the "sh" process
    {
      continue;
    }
    token = strtok(NULL, space);
    if (token == NULL)
    {
      goto FAILED;
    }
    if (strcmp(token, myPidStr) == 0) // ignore myself
    {
      continue;
    }
    strcpy(pidStr, token);
    char *ptr;
    *processId = strtoull(pidStr, &ptr, 10);
  }
  if (strlen(pidStr) == 0)
  {
    goto FAILED;
  }
  sprintf(pidPathStr, "%s%s%s", procStr, pidStr, exeStr); // /proc/pid/exe
  //printf("[%s]\n", pidPathStr);
  pathLen = readlink(pidPathStr, path, 1024);
  if (pathLen < 0)
  {
    goto FAILED;
  }
  pathResult = (char *)malloc(pathLen + 1);
  if (pathResult == NULL)
  {
    COMMON_ERROR_PRINT("malloc failed");
    goto FAILED;
  }
  memset(pathResult, 0, pathLen + 1);
  memcpy(pathResult, path, pathLen);
  pclose(fp);
  return pathResult;
FAILED:
  pclose(fp);
  return pathResult;
}

// static struct hlist_head ConnHashtable[HASHTABLE_SIZE] = {{0}};

Connection *createConnection(struct sockaddr_in *sourceAddr, struct sockaddr_in *destAddr, struct sockaddr_in *localBindAddr,
int client_socket, int remote_socket)
{
  Connection *conn = NULL;
  unsigned short localGeneratedPort; //used for connection id
  uint32_t clientIp;                 //used for connection id
  // int ret;
  char *path = NULL;
  if (sourceAddr == NULL || destAddr == NULL || localBindAddr == NULL)
  {
    goto failed;
  }

  conn = (Connection *)malloc(sizeof(Connection));
  if (conn == NULL)
  {
    COMMON_ERROR_PRINT("malloc failed");
    goto failed;
  }
  memset(conn, 0, sizeof(Connection));

  localGeneratedPort = ntohs(localBindAddr->sin_port);
  clientIp = destAddr->sin_addr.s_addr;

  conn->clientSocket = client_socket;
  conn->remoteSocket = remote_socket;

  conn->message.conn = conn;

  connIdGenerator((unsigned char *)&conn->id, localGeneratedPort, (unsigned char *)&clientIp);
  // ret = hash_add_by_id(ConnHashtable, &(conn->lnode), conn->id);
  // if (ret < 0)
  // {
  // 	goto failed;
  // }

  conn->currentReqPtr = &(conn->currentReq);
  conn->currentRespPtr = &(conn->currentResp);
  memset(conn->currentReqPtr, 0, sizeof(Request));
  memset(conn->currentRespPtr, 0, sizeof(Response));
  setRequestFunctions(&(conn->currentReqPtr->requestFunctions));
  setResponseFunctions(&(conn->currentRespPtr->responseFunctions));

  conn->localAddress.addrlength = 4;
  conn->remoteAddress.addrlength = 4;
  memcpy(&(conn->localAddress.ipaddr), &(sourceAddr->sin_addr.s_addr), sizeof(in_addr_t));
  memcpy(&(conn->remoteAddress.ipaddr), &(destAddr->sin_addr.s_addr), sizeof(in_addr_t));
  conn->localAddress.port = ntohs(sourceAddr->sin_port);
  conn->remoteAddress.port = ntohs(destAddr->sin_port);
  conn->info.localAddress = &(conn->localAddress);
  conn->info.remoteAddress = &(conn->remoteAddress);
  conn->info.protocol = PROTOCOL_UNAVAILABLE;
  conn->info.direction = DIRECTION_OUT;
  if (conn->remoteAddress.port == 443)
  {
    conn->type = CONN_HTTPS;
    conn->info.protocol = PROTOCOL_SSL;
    memcpy(&(conn->sslDomain.ip), conn->remoteAddress.ipaddr, 4);
    createSSLSession(conn, client_socket);
  }
  path = getProcPathByPort(conn->localAddress.port, &(conn->info.processId));
  if (path != NULL)
  {
    wchar_t *wcharPath = NULL;
    wcharPath = (wchar_t *)malloc((strlen(path) + 4) * sizeof(wchar_t));
    if (wcharPath != NULL)
    {
      memset(wcharPath, L'\0', (strlen(path) + 4) * sizeof(wchar_t));
      mbstowcs(wcharPath, path, strlen(path));
      conn->info.processPath = wcharPath;
    }
    else
    {
      COMMON_ERROR_PRINT("malloc failed");
      free(path);
      goto failed;
    }
    free(path);
  }
  else
  {
    goto failed;
  }

  if (isPathInExclustions(conn->info.processPath) == 0)
  {
    //skip intercepting
    log_warn("skip process in exclusions[%ls]", conn->info.processPath);
    UnfilterDetails details;
    details.reason = UNFILTER_REASON_FILE_EXCLUSION;
    cbNotifyConnectionUnfiltered(conn, &details);
    conn->skipFiltering = 1;
  }
  else
  {
    log_info("provcess not in exclusions[%ls]", conn->info.processPath);
  }

  http_parser_init(&(conn->requestParser), HTTP_REQUEST);
  conn->requestParser.data = conn;
  http_parser_init(&conn->responseParser, HTTP_RESPONSE);
  conn->responseParser.data = conn;

  setConnectionFunctions(&(conn->connectionFunctions));
  setRawDataFunctions(&(conn->rawDataFunctions));

  setHttpParserCallbacks(conn);

  return conn;
failed:
  if (conn != NULL)
  {
    free(conn);
  }
  return NULL;
}

void cleanCloudScan(Connection *conn)
{
  if (conn == NULL)
  {
    return;
  }
  if (conn->cloudScan.cloudResponseThread != 0)
  {
    pthread_join(conn->cloudScan.cloudResponseThread, NULL);
  }
  if (conn->cloudScan.queryURL != NULL)
  {
    free((void *)conn->cloudScan.queryURL);
  }
  if (conn->cloudScan.cloudresponse.source != NULL)
  {
    free((void *)conn->cloudScan.cloudresponse.source);
  }
  if (conn->cloudScan.cloudresponse.categories != NULL)
  {
    free((void *)conn->cloudScan.cloudresponse.categories);
  }
  memset(&(conn->cloudScan), 0, sizeof(CloudScan));
}

void destroyConnection(Connection *conn)
{
  cleanRequest(conn->currentReqPtr);
  cleanResponses(conn->currentRespPtr);
  cleanCloudScan(conn);
  if (conn->info.processPath != NULL)
  {
    free((void *)conn->info.processPath);
  }
  // hash_del_by_id(ConnHashtable, conn->id);
  if (conn != NULL)
  {
    free(conn);
  }
}

// void getConnection(unsigned long long id)
// {
// 	Connection *conn = NULL;
// 	struct hlist_node *node = NULL;
// 	node = hash_find_by_id(ConnHashtable, id);
// 	if (node == NULL)
// 	{
// 		COMMON_ERROR_PRINT("%s: node == NULL ", __func__);
// 		return;
// 	}
// 	conn = (Connection *)((size_t)node - (size_t)offsetof(Connection, lnode));
// 	if (conn == NULL)
// 	{
// 		COMMON_ERROR_PRINT("%s: conn == NULL ", __func__);
// 		return;
// 	}
// }
