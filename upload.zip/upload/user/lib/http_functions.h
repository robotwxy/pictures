/**
@file
@brief    interceptor HTTP related structs and defines.
@details  Copyright (c) 2020 Acronis
@author   Bruce Wang (Bruce.Wang@acronis.com)
*/

#ifndef HTTP_FUNCTIONS_H
#define HTTP_FUNCTIONS_H

// #include "hashtable.h"
#include "http_parser.h"
#include "interface.h"
#include "openssl/ssl.h"

#include <pthread.h>
#include <netinet/in.h>

#define MAX_DOMAIN_LEN 256

enum HttpParseState
{
	HTTP_PARSE_END = 0,
	HTTP_PARSE_MESSAGE_BEGIN,
	HTTP_PARSE_URL,
	HTTP_PARSE_STATUS,
	HTTP_PARSE_HEADER_FIELD,
	HTTP_PARSE_HEADER_VALUE,
	HTTP_PARSE_HEADER_COMPLETE,
	HTTP_PARSE_CHUNK_HEADER,
	HTTP_PARSE_CHUNK_COMPLETE,
	HTTP_PARSE_BODY,
	HTTP_PARSE_MESSAGE_COMPLETE,
};

struct Header
{
	char *name;
	unsigned short nameLen;
	char *value;
	unsigned short valueLen;
};

struct Method
{
	unsigned int number;
	char *str;
	unsigned short len;
};

struct Url
{
	char *str;
	unsigned int len;
};

struct HttpVersion
{
	char *str;
	unsigned int len;
};

struct StatusCode
{
	char *str;
	unsigned int len;
};

struct Reason
{
	char *str;
	unsigned int len;
};

enum HttpType
{
	HTTP_UNKNOWN = 0,
	HTTP_REQ,
	HTTP_RESP,
};

struct HttpStartLine
{
	unsigned httpType;
	struct HttpVersion version;
	struct Method method;
	struct Url url;
	struct Url realUrl;
	struct StatusCode status;
	struct Reason reason;
};

#define BODY_IS_CHUNKED (1 << 0)
#define BODY_IS_GZIP (1 << 1)
#define BODY_IS_TOO_LARGE (1 << 2)

struct Body
{
	char *str;
	unsigned long long contentLength;
	unsigned long long currentLength;
	unsigned char flags;
};

typedef struct _Request
{
	unsigned long long id;
	struct HttpStartLine startLine;
	struct Header *headers;
	unsigned int headersLen;
	struct Body body;

	unsigned char modifiedFlag;
	unsigned char notifyCompleteFlag;
	unsigned char blockFlag;

	RequestFunctions requestFunctions;

	enum HttpParseState parseState;
} Request;

typedef struct _Response
{
	unsigned long long id;
	struct HttpStartLine startLine;
	struct Header *headers;
	unsigned int headersLen;
	struct Body body;

	unsigned char modifiedFlag;
	unsigned char notifyCompleteFlag;

	ResponseFunctions responseFunctions;

	enum HttpParseState parseState;
} Response;

typedef struct httpHandleStruct
{
	struct _Connection *conn;
} HttpHandle;

enum ConnectionType
{
	CONN_UNKNOWN = 0,
	CONN_RAW,
	CONN_HTTP,
	CONN_HTTPS,
};

typedef struct _sslDomainInfo
{
	char name[MAX_DOMAIN_LEN];
	uint32_t ip;
	unsigned tlsHelloFlag;
	unsigned char notifyFlag;
} sslDomainInfo;

typedef struct _CloudScan
{
	char *queryURL;
	unsigned int queryURLLen;
	pthread_t cloudResponseThread;
	CloudResponse cloudresponse;
	unsigned char isInCache;
} CloudScan;

typedef struct _Connection
{
	unsigned long long id;
	enum ConnectionType type;
	struct http_parser requestParser;
	http_parser_settings requestParserSettings;
	struct http_parser responseParser;
	http_parser_settings responseParserSettings;

	char *bufferAddress;
	ssize_t bufferLen;

	unsigned char requestCount;
	unsigned char responseCount;

	Request currentReq;
	Response currentResp;

	Request *currentReqPtr;
	Response *currentRespPtr;

	ConnectionAddress localAddress;
	ConnectionAddress remoteAddress;
	ConnectionInfo info;

	unsigned char skipMessage;
	unsigned char skipFiltering;
	unsigned char disConnect;

	int clientSocket;
	int remoteSocket;

	HttpHandle message;
	ConnectionFunctions connectionFunctions;
	RawDataFunctions rawDataFunctions;

	sslDomainInfo sslDomain;
	CloudScan cloudScan;

	void *connContext;

	SSL *ssl;

	// struct hlist_node lnode;
} Connection;

/**
* Compare 2 header strings, case-insensitive
* @param[in] header1 - header1
* @param[in] header2 - header2
* @returns -1 on error, 1 on not equal, 0 on equal
*/
int compareHeader(const char *header1, const char *header2);

/**
* Get header from header list by header name, case-insensitive
* @param[in] headers - headers list
* @param[in] headersLen - list length
* @param[in] headerName - header name to find
* @returns -NULL on error, not NULL on success
*/
const char *findHeader(struct Header *headers, unsigned int headersLen, const char *headerName);

const char *findHeaderValue(struct Header *headers, unsigned int headersLen, const char *headerName, const char *headerValue);

/**
* find header from header list by header name and replace header value, heaer name case-insensitive
* @param[in] headers - headers list
* @param[in] headersLen - list length
* @param[in] headerName - header name to find
* @param[in] headerValue - header value to replace
* @returns -1 on error, 0 on success
*/
int setHedaer(struct Header **headers, unsigned int *headersLen, const char *headerName, const char *headerValue);

int getHeaderList(struct Header *myHeaders, unsigned int headersLen, char ***headers, unsigned long *size);

int deleteAllHeader(struct Header **headers, unsigned int *headersLen);

int deleteHeader(struct Header *headers, unsigned int headersLen, const char *headerName);

/**
* assemble request buffer and send
* @param[in] req - request to send
* @param[in] conn - current connetion
* @returns -1 on error, 0 on success
*/
int sendReqResp(int toSocket, struct HttpStartLine *startLine, struct Header **headers, unsigned int *headersNum, struct Body *body);

int cleanStartLine(struct HttpStartLine *startLine);

int cleanMembersInReqResp(struct HttpStartLine *startLine, struct Header **headers, unsigned int headersLen, struct Body *body);

int reqRespIdGenerator(unsigned char *idPtr, unsigned short reqCount, unsigned short respCount);

int unzipBody(struct Body *body);

Request *completeRequest(Connection *conn);

Response *completeResponse(Connection *conn);

int cleanRequest(Request *req);

int cleanResponses(Response *resp);

int assembleHeaderField(struct Header *header, const char *at, size_t length);

int assembleHeaderValue(struct Header *header, const char *at, size_t length, struct Body *body);

int assembleBody(struct Body *body, const char *at, size_t length);

int initBodyBuffer(struct Body *body);

int connIdGenerator(unsigned char *idPtr, unsigned short port, unsigned char *ip);

Connection *createConnection(struct sockaddr_in *sourceAddr, struct sockaddr_in *destAddr, struct sockaddr_in *localBindAddr,
int client_socket, int remote_socket);

void cleanCloudScan(Connection *conn);

void destroyConnection(Connection *conn);

void getConnection(unsigned long long id);

int getStartLine(const char *buffer, unsigned long bufferLen, struct HttpStartLine *startLine, unsigned char httpType);

#endif
