/**
@file
@brief    interceptor HTTP related functions.
@details  Copyright (c) 2020 Acronis
@author   Bruce Wang (Bruce.Wang@acronis.com)
*/

#include "common.h"
#include "interface_functions.h"
#include "http_parser.h"
#include "http_functions.h"
#include "http_parser_callbacks.h"
#include "URLCache.h"

#include <errno.h>
#include <curl/curl.h>

#define REDIRECT_SOCK_MARK2 20130509 //user kernel must be same

static int handleRequest(http_parser *p, const char *at, size_t length);
static int handleResponse(http_parser *p, const char *at, size_t length);

extern InterfaceSetting gInterfaceSetting;

static int requestOnMessageBegin(http_parser *p)
{
  Connection *conn = (Connection *)p->data;
  conn->currentReqPtr->parseState = HTTP_PARSE_MESSAGE_BEGIN;
  return handleRequest(p, NULL, 0);
}

static int responseOnMessageBegin(http_parser *p)
{
  Connection *conn = (Connection *)p->data;
  conn->currentRespPtr->parseState = HTTP_PARSE_MESSAGE_BEGIN;
  return handleResponse(p, NULL, 0);
}

static int requestOnHeadersComplete(http_parser *p)
{
  Connection *conn = (Connection *)p->data;
  conn->currentReqPtr->parseState = HTTP_PARSE_HEADER_COMPLETE;
  return handleRequest(p, NULL, 0);
}

static int responseOnHeadersComplete(http_parser *p)
{
  Connection *conn = (Connection *)p->data;
  conn->currentRespPtr->parseState = HTTP_PARSE_HEADER_COMPLETE;
  return handleResponse(p, NULL, 0);
}
static int requestOnChunkHeader(http_parser *p)
{
  return 0;
}

static int responseOnChunkHeader(http_parser *p)
{
  return 0;
}

static int requestOnChunkComplete(http_parser *p)
{
  return 0;
}

static int responseOnChunkComplete(http_parser *p)
{
  return 0;
}

static int requestOnMessageComplete(http_parser *p)
{
  Connection *conn = (Connection *)p->data;
  conn->currentReqPtr->parseState = HTTP_PARSE_MESSAGE_COMPLETE;
  return handleRequest(p, NULL, 0);
}

static int responseOnMessageComplete(http_parser *p)
{
  Connection *conn = (Connection *)p->data;
  conn->currentRespPtr->parseState = HTTP_PARSE_MESSAGE_COMPLETE;
  return handleResponse(p, NULL, 0);
}

static int requestOnUrlandVersion(http_parser *p, const char *at, size_t length)
{
  Connection *conn = (Connection *)p->data;
  conn->currentReqPtr->parseState = HTTP_PARSE_URL;
  return handleRequest(p, at, length);
}
static int requestOnStatus(http_parser *p, const char *at, size_t length)
{
  return 0;
}

static int responseOnStatus(http_parser *p, const char *at, size_t length)
{
  Connection *conn = (Connection *)p->data;
  conn->currentRespPtr->parseState = HTTP_PARSE_STATUS;
  return handleResponse(p, at, length);
}

static int requestOnHeaderField(http_parser *p, const char *at, size_t length)
{
  Connection *conn = (Connection *)p->data;
  conn->currentReqPtr->parseState = HTTP_PARSE_HEADER_FIELD;
  return handleRequest(p, at, length);
}

static int responseOnHeaderField(http_parser *p, const char *at, size_t length)
{
  Connection *conn = (Connection *)p->data;
  conn->currentRespPtr->parseState = HTTP_PARSE_HEADER_FIELD;
  return handleResponse(p, at, length);
}
static int requestOnHeaderValue(http_parser *p, const char *at, size_t length)
{
  Connection *conn = (Connection *)p->data;
  conn->currentReqPtr->parseState = HTTP_PARSE_HEADER_VALUE;
  return handleRequest(p, at, length);
}

static int responseOnHeaderValue(http_parser *p, const char *at, size_t length)
{
  Connection *conn = (Connection *)p->data;
  conn->currentRespPtr->parseState = HTTP_PARSE_HEADER_VALUE;
  return handleResponse(p, at, length);
}

static int requestOnBody(http_parser *p, const char *at, size_t length)
{
  Connection *conn = (Connection *)p->data;
  conn->currentReqPtr->parseState = HTTP_PARSE_BODY;
  return handleRequest(p, at, length);
}
static int responseOnBody(http_parser *p, const char *at, size_t length)
{
  Connection *conn = (Connection *)p->data;
  conn->currentRespPtr->parseState = HTTP_PARSE_BODY;
  return handleResponse(p, at, length);
}

int setHttpParserCallbacks(Connection *conn)
{
  if (conn == NULL)
  {
    return -1;
  }
  //set request func pointer
  conn->requestParserSettings.on_message_begin = requestOnMessageBegin;
  conn->requestParserSettings.on_message_complete = requestOnMessageComplete;
  conn->requestParserSettings.on_chunk_header = requestOnChunkHeader;
  conn->requestParserSettings.on_chunk_complete = requestOnChunkComplete;
  conn->requestParserSettings.on_headers_complete = requestOnHeadersComplete;
  conn->requestParserSettings.on_url = requestOnUrlandVersion;
  conn->requestParserSettings.on_status = requestOnStatus;
  conn->requestParserSettings.on_header_field = requestOnHeaderField;
  conn->requestParserSettings.on_header_value = requestOnHeaderValue;
  conn->requestParserSettings.on_body = requestOnBody;
  //set response func pointer
  conn->responseParserSettings.on_message_begin = responseOnMessageBegin;
  conn->responseParserSettings.on_message_complete = responseOnMessageComplete;
  conn->responseParserSettings.on_chunk_header = responseOnChunkHeader;
  conn->responseParserSettings.on_chunk_complete = responseOnChunkComplete;
  conn->responseParserSettings.on_headers_complete = responseOnHeadersComplete;
  conn->responseParserSettings.on_status = responseOnStatus;
  conn->responseParserSettings.on_header_field = responseOnHeaderField;
  conn->responseParserSettings.on_header_value = responseOnHeaderValue;
  conn->responseParserSettings.on_body = responseOnBody;

  return 0;
}

static int initRequest(Connection *conn)
{
  Request *req = conn->currentReqPtr;
  unsigned char *idPtr;
  if (req == NULL)
  {
    return -1;
  }
  cleanRequest(req);
  req->id = conn->id;
  idPtr = (unsigned char *)&(req->id);
  reqRespIdGenerator(idPtr, conn->requestCount + 1, 0);
  return 0;
}

static int storeHeaderField(struct Header **headersPtr, unsigned int *headersLenPtr, const char *at, size_t length)
{
  struct Header *header = NULL;
  if (headersPtr == NULL)
  {
    return -1;
  }
  if (*headersLenPtr == 0)
  {
    if ((*headersPtr) != NULL)
    {
      free((*headersPtr));
    }
    (*headersPtr) = (struct Header *)malloc(sizeof(struct Header));
  }
  else
  {
    (*headersPtr) = (struct Header *)realloc((*headersPtr), sizeof(struct Header) * (*headersLenPtr + 1));
  }
  if ((*headersPtr) == NULL)
  {
    COMMON_ERROR_PRINT("malloc failed, errno: %d", errno);
    return -1;
  }
  header = &((*headersPtr)[*headersLenPtr]);
  if (header == NULL)
  {
    COMMON_ERROR_PRINT("ptr is NULL");
    return -1;
  }
  memset(header, 0, sizeof(struct Header));
  if (assembleHeaderField(header, at, length) == 0)
  {
    *headersLenPtr = *headersLenPtr + 1;
  }
  return 0;
}

int storeHeaderValue(struct Header *headers, unsigned int headersLen, struct Body *body, const char *at, size_t length)
{
  struct Header *header = NULL;
  if (headers == NULL)
  {
    return -1;
  }
  header = &(headers[headersLen - 1]);
  if (header == NULL)
  {
    COMMON_ERROR_PRINT("ptr is NULL, errno: %d", errno);
    return -1;
  }
  if (assembleHeaderValue(header, at, length, body) < 0)
  {
    return -1;
  }
  return 0;
}

int requestCompleteUrl(Connection *conn)
{
  if (conn == NULL)
  {
    return -1;
  }
  Request *req = conn->currentReqPtr;
  if (http_request_get_header_value(&(conn->message), "host") != NULL)
  {
    const char *host = http_request_get_header_value(&(conn->message), "host");
    req->startLine.realUrl.str = (char *)malloc(strlen(host) + req->startLine.url.len + 1);
    if (req->startLine.realUrl.str != NULL)
    {
      unsigned int i;
      memset(req->startLine.realUrl.str, 0, strlen(host) + req->startLine.url.len + 1);
      //in case the host includes port, i.e. 192.168.163.1:3000
      for (i = 0; i < strlen(host); i++)
      {
        if (host[i] == ':')
        {
          break;
        }
      }
      memcpy(req->startLine.realUrl.str, host, i);
      req->startLine.realUrl.len = i;
      //real url = host + url, i.e. 192.168.163.1 + /index.html = 192.168.163.1/index.html
      if (req->startLine.url.len > 1)
      {
        memcpy(req->startLine.realUrl.str + i, req->startLine.url.str, req->startLine.url.len);
        req->startLine.realUrl.len += req->startLine.url.len;
      }
    }
  }
  return 0;
}

int sendLargeBodySegment(struct Body *body, const char *at, size_t length, int socket)
{
  if (body == NULL)
  {
    return -1;
  }
  ssize_t m;
  if ((body->flags & BODY_IS_CHUNKED) > 0)
  {
    char tmpbuf[128];
    memset(tmpbuf, 0, 128);
    sprintf(tmpbuf, "%lx%c%c", length, 0x0d, 0x0a);
    send(socket, tmpbuf, strlen(tmpbuf), 0);
    //log_trace("send[%s]", at);
    m = send(socket, at, length, 0);
    memset(tmpbuf, 0, 128);
    sprintf(tmpbuf, "%c%c", 0x0d, 0x0a);
    send(socket, tmpbuf, strlen(tmpbuf), 0);
  }
  else
  {
    m = send(socket, at, length, 0);
  }
  if ((size_t)m != length)
  {
    COMMON_ERROR_PRINT("send failed errno:%d", errno);
  }
  return 0;
}

int sendChunkEnd(int socket)
{
  ssize_t m;
  char tmpbuf[32];
  memset(tmpbuf, 0, 32);
  sprintf(tmpbuf, "%x%c%c", 0, 0x0d, 0x0a);
  m = send(socket, tmpbuf, strlen(tmpbuf), 0);
  if ((size_t)m != strlen(tmpbuf))
  {
    COMMON_ERROR_PRINT("send failed");
  }
  memset(tmpbuf, 0, 32);
  sprintf(tmpbuf, "%c%c", 0x0d, 0x0a);
  m = send(socket, tmpbuf, strlen(tmpbuf), 0);
  if ((size_t)m != strlen(tmpbuf))
  {
    COMMON_ERROR_PRINT("send failed");
  }
  return 0;
}

static int handleRequest(http_parser *p, const char *at, size_t length)
{
  Connection *conn = (Connection *)p->data;
  Request *req = conn->currentReqPtr;
  if (conn->disConnect == 1)
  {
    return -1;
  }
  switch (req->parseState)
  {
  case HTTP_PARSE_MESSAGE_BEGIN:
    if (conn->type == CONN_UNKNOWN)
    {
      conn->type = CONN_HTTP;
      conn->info.protocol = PROTOCOL_HTTP;
    }
    conn->currentReqPtr = &(conn->currentReq);
    initRequest(conn);
    conn->skipMessage = 0;
    break;

  case HTTP_PARSE_URL:
    getStartLine(conn->bufferAddress, conn->bufferLen, &(req->startLine), HTTP_REQ);
    break;

  case HTTP_PARSE_HEADER_FIELD:
    storeHeaderField(&(req->headers), &(req->headersLen), at, length);
    break;

  case HTTP_PARSE_HEADER_VALUE:
    storeHeaderValue(req->headers, req->headersLen, &req->body, at, length);
    break;

  case HTTP_PARSE_HEADER_COMPLETE:
    requestCompleteUrl(conn);
    cbNotifyRequestHeaders(conn);
    initBodyBuffer(&(req->body));
    startCloudScanThread(conn, req->startLine.realUrl.str, req->startLine.realUrl.len);
    break;

  case HTTP_PARSE_BODY:
    assembleBody(&(req->body), at, length);
    if ((req->body.flags & BODY_IS_TOO_LARGE) > 0)
    {
      cbNotifyRequestComplete(conn);
      if (req->modifiedFlag == 0 && req->blockFlag == 0 && conn->disConnect == 0)
      {
        sendLargeBodySegment(&req->body, at, length, conn->remoteSocket);
      }
    }
    break;

  case HTTP_PARSE_MESSAGE_COMPLETE:
    completeRequest(conn);
    cbNotifyRequestComplete(conn);
    //chunked large data need 0\r\n\r\n as end symbol
    if ((req->body.flags & BODY_IS_TOO_LARGE) > 0 && (req->body.flags & BODY_IS_CHUNKED) > 0 &&
        req->modifiedFlag == 0 && req->blockFlag == 0 && conn->disConnect == 0)
    {
      sendChunkEnd(conn->remoteSocket);
    }
    break;

  default:
    break;
  }
  if (conn->disConnect != 0)
  {
    return -1;
  }
  return 0;
}

#ifndef CURL_SOCKOPT_OK
#define CURL_SOCKOPT_OK 0
#endif
#ifndef CURL_SOCKOPT_ERROR
#define CURL_SOCKOPT_ERROR 1
#endif

static int sockopt_callback(void *clientp,
                            curl_socket_t curlfd,
                            curlsocktype purpose)
{
  int mark = REDIRECT_SOCK_MARK2;
  if (setsockopt(curlfd, SOL_SOCKET, SO_MARK, &mark, sizeof(mark)) < 0)
  {
    COMMON_ERROR_PRINT("Cannot set listen socket mark option, errno: %d", errno);
    return CURL_SOCKOPT_ERROR;
  }
  return CURL_SOCKOPT_OK;
}

static size_t header_callback(char *buffer, size_t size,
                              size_t nitems, void *userdata)
{
  if (userdata == NULL)
  {
    return nitems;
  }
  CloudResponse *cloudResponse = (CloudResponse *)userdata;
  if (cloudResponse->status == 0)
  {
    struct HttpStartLine startLine;
    getStartLine(buffer, nitems, &startLine, HTTP_RESP);
    cloudResponse->status = atoi(startLine.status.str);
    cleanStartLine(&startLine);
  }
  return nitems;
}

static size_t write_callback(char *ptr, size_t size, size_t nmemb, void *userdata)
{
  //TODO
  if (userdata == NULL)
  {
    return nmemb;
  }
  CloudResponse *cloudResponse = (CloudResponse *)userdata;
  cloudResponse->source = (const char *)malloc(nmemb + 1);
  if (cloudResponse->source != NULL)
  {
    memset((char *)cloudResponse->source, 0, nmemb + 1);
    memcpy((char *)cloudResponse->source, ptr, nmemb);
  }
  return nmemb;
}

static void *issueCloudScan(void *arg)
{
  Connection *conn = (Connection *)arg;
  if (conn == NULL)
  {
    return NULL;
  }
  // unsigned short id = 0;
  // unsigned short key = 0;
  const char *server = gInterfaceSetting.cloudServer;
  CloudResponse *cloudResponse = &(conn->cloudScan.cloudresponse);
  const char *postData = conn->cloudScan.queryURL;
  unsigned int dataLen = conn->cloudScan.queryURLLen;
  if (server == NULL || postData == NULL || cloudResponse == NULL)
  {
    return NULL;
  }
  CURL *curl;
  CURLcode res;
  curl = curl_easy_init();
  if (curl)
  {
    struct curl_slist *list = NULL;
    curl_easy_setopt(curl, CURLOPT_URL, server);
    curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, write_callback);
    curl_easy_setopt(curl, CURLOPT_WRITEDATA, (void *)cloudResponse);
    curl_easy_setopt(curl, CURLOPT_SOCKOPTFUNCTION, sockopt_callback);
    curl_easy_setopt(curl, CURLOPT_HEADERDATA, (void *)cloudResponse);
    curl_easy_setopt(curl, CURLOPT_HEADERFUNCTION, header_callback);
    curl_easy_setopt(curl, CURLOPT_POSTFIELDSIZE, dataLen);
    curl_easy_setopt(curl, CURLOPT_POSTFIELDS, postData);
    list = curl_slist_append(list, "content-type: text/html");
    curl_easy_setopt(curl, CURLOPT_HTTPHEADER, list);
    // printf("cloudTimeout %u\n", gInterfaceSetting.cloudTimeout);
    curl_easy_setopt(curl, CURLOPT_TIMEOUT, gInterfaceSetting.cloudTimeout);
    res = curl_easy_perform(curl);
    curl_slist_free_all(list);
    if (res != CURLE_OK)
    {
      COMMON_ERROR_PRINT("curl_easy_perform error: %d", res);
    }
    curl_easy_cleanup(curl);
    return conn;
  }
  return NULL;
}

int startCloudScanThread(Connection *conn, const char *queryURL, unsigned int queryURLLen)
{
  if (conn == NULL || queryURL == NULL || queryURLLen == 0)
  {
    return -1;
  }
  if (gInterfaceSetting.cloudEnable == 0 || gInterfaceSetting.cloudServer == NULL)
  {
    return -1;
  }

  cleanCloudScan(conn);
  conn->cloudScan.queryURL = (char *)malloc(queryURLLen + 1);
  if (conn->cloudScan.queryURL == NULL)
  {
    COMMON_ERROR_PRINT("malloc failed");
    return -1;
  }
  memcpy(conn->cloudScan.queryURL, queryURL, queryURLLen);
  conn->cloudScan.queryURL[queryURLLen] = 0;
  conn->cloudScan.queryURLLen = strlen(conn->cloudScan.queryURL);
  //check url cache first
  urlTireNode *urlNode = NULL;
  int ret = isUrlExist(queryURL, strlen(queryURL), &urlNode);
  if (ret == 1)
  {
    //url is in cache, no need to send request to server
    conn->cloudScan.isInCache = 1;
    log_info("url already exists: [%s]\n", queryURL);
  }
  else if (ret == 0)
  {
    //url is not in cache, need to send request to server
    log_warn("url doesn't exist: [%s]\n", queryURL);
    conn->cloudScan.isInCache = 0;
    pthread_create(&(conn->cloudScan.cloudResponseThread), NULL, issueCloudScan, (void *)conn);
  }
  else
  {
    return -1;
  }
  return 0;
}

int cloudScanResult(Connection *conn)
{
  if (gInterfaceSetting.cloudEnable == 0 || gInterfaceSetting.cloudServer == NULL)
  {
    return -1;
  }
  if (conn->cloudScan.isInCache == 0)
  {
    // url not in cache, need to check result from server
    if (conn->cloudScan.cloudResponseThread == 0)
    {
      //cloudResponseThread already joined
      return -2;
    }
    Connection *retConn = NULL;
    pthread_join(conn->cloudScan.cloudResponseThread, (void **)&retConn);
    if (retConn != conn)
    {
      COMMON_ERROR_PRINT("pthread_join return is wrong");
      return -1;
    }
    conn->cloudScan.cloudResponseThread = 0;
    addUrlCache(conn->cloudScan.queryURL, conn->cloudScan.queryURLLen, &(conn->cloudScan.cloudresponse));
    conn->cloudScan.isInCache = 1;
  }
  else
  {
    // url in cache, just copy to
    urlTireNode *urlCache = NULL;
    isUrlExist(conn->cloudScan.queryURL, conn->cloudScan.queryURLLen, &urlCache);
    if (urlCache != NULL)
    {
      if (urlCache->cloudResponse->categories != NULL)
      {
        conn->cloudScan.cloudresponse.categories = (char *)calloc(strlen(urlCache->cloudResponse->categories) + 1, sizeof(char));
        if (conn->cloudScan.cloudresponse.categories != NULL)
        {
          strcpy((char *)conn->cloudScan.cloudresponse.categories, (char *)urlCache->cloudResponse->categories);
        }
      }
      if (urlCache->cloudResponse->source != NULL)
      {
        conn->cloudScan.cloudresponse.source = (char *)calloc(strlen(urlCache->cloudResponse->source) + 1, sizeof(char));
        if (conn->cloudScan.cloudresponse.source != NULL)
        {
          strcpy((char *)conn->cloudScan.cloudresponse.source, (char *)urlCache->cloudResponse->source);
        }
      }
      conn->cloudScan.cloudresponse.isgrey = urlCache->cloudResponse->isgrey;
      conn->cloudScan.cloudresponse.status = urlCache->cloudResponse->status;
      conn->cloudScan.cloudresponse.status_message = urlCache->cloudResponse->status_message;
    }
  }
  if (conn->cloudScan.cloudresponse.status != 0)
  {
    //TODO
    if (conn->cloudScan.cloudresponse.status == 200)
    {
      conn->cloudScan.cloudresponse.status_message = CLOUD_STATUS_SAFE;
    }
    else
    {
      conn->cloudScan.cloudresponse.status_message = CLOUD_STATUS_UNKNOWN;
    }
    cbNotifyCloudResponse(conn);
  }
  cleanCloudScan(conn);
  return 0;
}

static int handleResponse(http_parser *p, const char *at, size_t length)
{
  Connection *conn = (Connection *)p->data;
  Response *resp = conn->currentRespPtr;
  unsigned char *idPtr;
  if (conn->disConnect != 0)
  {
    return -1;
  }
  switch (resp->parseState)
  {
  case HTTP_PARSE_MESSAGE_BEGIN:
    conn->currentRespPtr = &(conn->currentResp);
    cleanResponses(conn->currentRespPtr);
    resp->id = conn->id;
    idPtr = (unsigned char *)&(resp->id);
    reqRespIdGenerator(idPtr, 0, conn->responseCount + 1);
    break;

  case HTTP_PARSE_STATUS:
    getStartLine(conn->bufferAddress, conn->bufferLen, &(resp->startLine), HTTP_RESP);
    break;

  case HTTP_PARSE_HEADER_FIELD:
    storeHeaderField(&(resp->headers), &(resp->headersLen), at, length);
    break;

  case HTTP_PARSE_HEADER_VALUE:
    storeHeaderValue(resp->headers, resp->headersLen, &resp->body, at, length);
    break;

  case HTTP_PARSE_HEADER_COMPLETE:
    cbNotifyResponseHeaders(conn);
    initBodyBuffer(&(resp->body));
    break;

  case HTTP_PARSE_BODY:
    assembleBody(&(resp->body), at, length);
    if ((resp->body.flags & BODY_IS_TOO_LARGE) > 0)
    {
      if (resp->notifyCompleteFlag == 0)
      {
        cbNotifyMessage(conn);
        cloudScanResult(conn);
        cbNotifyPostScan(conn);
        resp->notifyCompleteFlag = 1;
      }
      if (resp->modifiedFlag == 0 && conn->disConnect == 0)
      {
        sendLargeBodySegment(&resp->body, at, length, conn->clientSocket);
      }
    }
    break;

  case HTTP_PARSE_MESSAGE_COMPLETE:
    completeResponse(conn);
    if (resp->notifyCompleteFlag == 0)
    {
      cbNotifyMessage(conn);
      cloudScanResult(conn);
      cbNotifyPostScan(conn);
      resp->notifyCompleteFlag = 1;
    }
    //chunked large data need 0\r\n\r\n as end symbol
    if ((resp->body.flags & BODY_IS_TOO_LARGE) > 0 && (resp->body.flags & BODY_IS_CHUNKED) > 0 &&
        resp->modifiedFlag == 0 && conn->disConnect == 0)
    {
      sendChunkEnd(conn->clientSocket);
    }
    cleanRequest(conn->currentReqPtr);
    cleanResponses(conn->currentRespPtr);
    break;

  default:
    break;
  }
  if (conn->disConnect != 0)
  {
    return -1;
  }
  return 0;
}
