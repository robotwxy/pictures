/**
@file
@brief    http parser callback implementations.
@details  Copyright (c) 2020 Acronis
@author   Bruce Wang (Bruce.Wang@acronis.com)
*/

#ifndef HTTP_PARSER_CALLBACKS_H
#define HTTP_PARSER_CALLBACKS_H

int setHttpParserCallbacks(Connection *conn);
int startCloudScanThread(Connection *conn, const char *queryURL, unsigned int queryURLLen);
int cloudScanResult(Connection *conn);
#endif
