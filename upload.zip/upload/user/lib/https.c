#include <string.h>
#include <stdlib.h>
#include "log.h"
#include "http_functions.h"
#include "openssl/ssl.h"
SSL_CTX *ctx = NULL;
SSL_CTX *initSSL(const char *CertFile, const char *KeyFile)
{
    const SSL_METHOD *method;
    SSL_library_init();
    OpenSSL_add_all_algorithms(); /* load & register all cryptos, etc. */
    //SSL_load_error_strings();
    method = TLS_server_method(); /* create new server-method instance */
    ctx = SSL_CTX_new(method);        /* create new context from method */
    if (ctx == NULL)
    {
        log_error("SSL_CTX_new create failed");
        return NULL;
    }
    /* set the local certificate from CertFile */
    if (SSL_CTX_use_certificate_file(ctx, CertFile, SSL_FILETYPE_PEM) <= 0)
    {
        log_error("load SSL certificate failed");
        goto free;
    }
    /* set the private key from KeyFile (may be the same as CertFile) */
    if (SSL_CTX_use_PrivateKey_file(ctx, KeyFile, SSL_FILETYPE_PEM) <= 0)
    {
        log_error("load SSL certificate key failed");
        goto free;
    }
    /* verify private key */
    if (!SSL_CTX_check_private_key(ctx))
    {
        log_error("verify certificate and key failed");
        goto free;
    }
    log_info("%s successful", __func__);
    return ctx;
free:
    SSL_CTX_free(ctx);
    ctx = NULL;
    return NULL;
}

int createSSLSession(Connection *conn, int clientSocket)
{
    SSL *ssl;
    if (ctx == NULL)
    {
        log_error("SSL ctx is NULL");
        return -1;
    }
    ssl = SSL_new(ctx);            /* get new SSL state with context */
    SSL_set_fd(ssl, clientSocket); /* set connection socket to SSL state */
    if (SSL_accept(ssl) == -1)
    {
        log_error("SSL_accept failed");
        return -1;
    }
    conn->ssl = ssl;
    return 0;
}

int uninitSSL()
{
    if (ctx != NULL)
    {
        SSL_CTX_free(ctx); /* release context */
        log_info("%s successful", __func__);
    }
    return 0;
}