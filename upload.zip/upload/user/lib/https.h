#ifndef HTTP_HTTPS_H
#define HTTP_HTTPS_H
#include "openssl/ssl.h"
SSL_CTX *initSSL(const char *CertFile, const char *KeyFile);
int uninitSSL();
int createSSLSession(Connection *conn, int clientSocket);
#endif