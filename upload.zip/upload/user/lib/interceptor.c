/**
@file
@brief    interceptor loop.
@details  Copyright (c) 2020 Acronis
@author   Bruce Wang (Bruce.Wang@acronis.com)
*/

#include "common.h"
#include "interceptor.h"
#include "interface_functions.h"
#include "tls.h"
#include "http_functions.h"
#include "http_parser_callbacks.h"

#include <errno.h>
#include <sys/select.h>

#define BUFFER_SIZE 65535
#define CONNECTION_TIMEOUT 360 // 6min

static http_parser_settings voidSettings = {0};

unsigned int gHttpMaxBodySize = 0;

//TODO
int initInterceptorSetting(const HttpInitParams *params)
{
  if (params->maxHttpBodySize == 0)
  {
    gHttpMaxBodySize = DEFAULT_MAX_BODY_SIZE;
  }
  else
  {
    gHttpMaxBodySize = params->maxHttpBodySize;
  }
  return 0;
}

int interceptorUninitialize()
{
  return 0;
}

enum ConnectionType checkConnectionType(unsigned char *buffer, size_t n)
{
  http_parser parser;
  http_parser_init(&parser, HTTP_REQUEST);
  size_t nparsed = 0;
  nparsed = http_parser_execute(&parser, (const http_parser_settings *)&voidSettings, (const char *)buffer, n);
  if (nparsed == n)
  {
    return CONN_HTTP;
  }
  return CONN_RAW;
}

extern InterfaceSetting gInterfaceSetting;

ssize_t handleDataByType(struct http_parser *parser, int tosocket)
{
  Connection *conn = (Connection *)parser->data;
  ssize_t sent = 0;
  size_t nparsed = 0;
  if (parser == NULL)
  {
    return -1;
  }
  sent = 0;
  switch (conn->type)
  {
  case CONN_HTTP:
    switch (parser->type)
    {
    case HTTP_REQUEST:
      nparsed = http_parser_execute(parser, (const http_parser_settings *)&(conn->requestParserSettings), (const char *)conn->bufferAddress, conn->bufferLen);
      break;
    case HTTP_RESPONSE:
      nparsed = http_parser_execute(parser, (const http_parser_settings *)&(conn->responseParserSettings), (const char *)conn->bufferAddress, conn->bufferLen);
    }
    if (nparsed != (size_t)conn->bufferLen && conn->disConnect == 0)
    {
      //http parsing error, unfilter the connection, and send this packet
      sent = send(tosocket, conn->bufferAddress, conn->bufferLen, 0);
      UnfilterDetails details;
      details.reason = UNFILTER_REASON_HTTP_PARSING_ERROR;
      cbNotifyConnectionUnfiltered(conn, &details);
      conn->skipFiltering = 1;
      // conn->type = CONN_RAW;
    }
    else
    {
      sent = conn->bufferLen;
    }
    break;

  case CONN_HTTPS:
  {
    if (conn->sslDomain.tlsHelloFlag == 0)
    {
      conn->sslDomain.tlsHelloFlag = 1;
      char *serverName = NULL;
      int ret = parse_tls_header((const uint8_t *)conn->bufferAddress, (size_t)conn->bufferLen, &serverName);
      if (ret > 0 && serverName != NULL)
      {
        if (gInterfaceSetting.cloudScanForSSLEnable != 0)
        {
          startCloudScanThread(conn, serverName, strlen(serverName));
        }
        cbNotifySSLDomain(conn, serverName);
        if (gInterfaceSetting.cloudScanForSSLEnable != 0)
        {
          cloudScanResult(conn);
        }
      }
      if (serverName != NULL)
      {
        free(serverName);
      }
    }
    if (conn->disConnect == 0)
    {
      sent = send(tosocket, conn->bufferAddress, conn->bufferLen, 0);
    }
    break;
  }

  case CONN_RAW:
    cbNotifyRawData(conn, parser->type);
    if (conn->disConnect == 0)
    {
      sent = send(tosocket, conn->bufferAddress, conn->bufferLen, 0);
    }
    break;

  default:
    INTERCEPTOR_DEBUG_PRINT("conn->type wrong");
    return -1;
    break;
  }
  return sent;
}
static ssize_t handleData(int fromsocket, int tosocket, struct http_parser *parser)
{
  Connection *conn = (Connection *)parser->data;
  unsigned char buffer[BUFFER_SIZE + 1];
  memset(buffer, 0, BUFFER_SIZE + 1);
  ssize_t sent = 0;
  ssize_t n = recv(fromsocket, buffer, BUFFER_SIZE, 0);
  conn->bufferAddress = (char *)buffer;
  conn->bufferLen = n;
  if (n < 0)
  {
    //COMMON_ERROR_PRINT("recv failed, errno: %d", errno);
    return n;
  }
  if (conn->skipFiltering == 1)
  {
    //skip filtering, just forward
    sent = send(tosocket, buffer, n, 0);
    goto end;
  }

  if (conn->type == CONN_UNKNOWN)
  {
    conn->type = checkConnectionType(buffer, n);
  }

  if(conn->type == CONN_HTTP){
    conn->info.protocol = PROTOCOL_HTTP;
  }
  if(conn->type == CONN_RAW){
    conn->info.protocol = PROTOCOL_NOT_ANALYZED;
  }
  sent = handleDataByType(parser, tosocket);

end:
  if (n == 0)
  {
    //INTERCEPTOR_DEBUG_PRINT("socket closed: %d", fromsocket);
    return 0;
  }
  return sent;
}

void interceptor(int client_socket, int remote_socket, struct sockaddr_in *sourceAddr, struct sockaddr_in *destAddr, struct sockaddr_in *localBindAddr)
{
  fd_set fdsets;
  struct timeval timeout;
  Connection *conn = NULL;
  //new connection
  conn = createConnection(sourceAddr, destAddr, localBindAddr, client_socket, remote_socket);
  if (conn == NULL)
  {
    INTERCEPTOR_DEBUG_PRINT("%s: createConnection failed", __func__);
    goto end;
  }

  INTERCEPTOR_DEBUG_PRINT("new connection [client]:[%u]->[%s]:[%u], proxy out port[%u]",
                          ntohs(sourceAddr->sin_port), inet_ntoa(destAddr->sin_addr), ntohs(destAddr->sin_port), ntohs(localBindAddr->sin_port));

  cbNotifyNewConnection(conn);

  while (1)
  {
    if (conn->disConnect == 1)
    {
      //close connetion
      break;
    }

    timeout.tv_sec = CONNECTION_TIMEOUT;
    timeout.tv_usec = 0;
    FD_ZERO(&fdsets);
    FD_SET(client_socket, &fdsets);
    FD_SET(remote_socket, &fdsets);
    int ret = select(FD_SETSIZE, &fdsets, NULL, NULL, &timeout);
    if (ret < 0)
    {
      COMMON_ERROR_PRINT("select failed, errno: %d", errno);
      break;
    }
    else if (ret == 0)
    {
      if (timeout.tv_sec == 0)
      {
        //COMMON_ERROR_PRINT("select timeout errno: %d", errno);
        break;
      }
      continue;
    }

    if (FD_ISSET(client_socket, &fdsets))
    {
      ssize_t n = handleData(client_socket, remote_socket, &(conn->requestParser));
      if (n <= 0)
      {
        break;
      }
    }

    if (FD_ISSET(remote_socket, &fdsets))
    {
      ssize_t n = handleData(remote_socket, client_socket, &(conn->responseParser));
      if (n <= 0)
      {
        break;
      }
    }
  } //while (1)

  cbNotifyConnectionDestroyed(conn);
  destroyConnection(conn);

  INTERCEPTOR_DEBUG_PRINT("connection closed [client]:[%u]->[%s]:[%u], proxy out port[%u]",
                          ntohs(sourceAddr->sin_port), inet_ntoa(destAddr->sin_addr), ntohs(destAddr->sin_port), ntohs(localBindAddr->sin_port));

end:
  return;
}
