/**
@file
@brief    interceptor loop.
@details  Copyright (c) 2020 Acronis
@author   Bruce Wang (Bruce.Wang@acronis.com)
*/

#ifndef HTTP_INTERCEPTOR_H
#define HTTP_INTERCEPTOR_H

#include <arpa/inet.h>
#include "interface.h"

//#define INTERCEPTOR_DEBUG
#ifdef INTERCEPTOR_DEBUG
#define INTERCEPTOR_DEBUG_PRINT log_debug
#else
#define INTERCEPTOR_DEBUG_PRINT(...) /*...*/
#endif

void interceptor(int client_socket, int remote_socket, struct sockaddr_in *clientAddr, struct sockaddr_in *originDst, struct sockaddr_in *localAddr);
int initInterceptorSetting(const HttpInitParams *params);
int interceptorUninitialize();

#endif
