/**
@file
@brief    interceptor interface.
@details  Copyright (c) 2020 Acronis
@author   Bruce Wang (Bruce.Wang@acronis.com)
*/

#include "interface.h"
#include "interceptor.h"
#include "proxy.h"
#include "interface_functions.h"
#include "log.h"
#include "path_exclusions.h"
#include "URLCache.h"
#include "https.h"

#include <unistd.h>
#include <curl/curl.h>
#include <string.h>
#include <stdlib.h>

InterfaceSetting gInterfaceSetting;

//TODO
static char defaultCouldServer[] = "http://bitdefender-testing.com/untrusted";

static void cleanSetting(InterfaceSetting *setting)
{
  if (setting->cloudServer != NULL)
  {
    free(setting->cloudServer);
  }
  memset(setting, 0, sizeof(InterfaceSetting));
}

static void initCloudScan(InterfaceSetting * interfaceSetting, const HttpInitParams *params){
  if (params->cloudScanEnable != 0)
  {
    curl_global_init(CURL_GLOBAL_DEFAULT);
    interfaceSetting->cloudEnable = params->cloudScanEnable;
    interfaceSetting->cloudScanForSSLEnable = params->cloudScanForSSLEnable;
    char *tmpCloudServer;
    if (params->cloudScanServer != NULL)
    {
      tmpCloudServer = params->cloudScanServer;
    }
    else
    {
      tmpCloudServer = defaultCouldServer;
    }
    unsigned long size = strlen(tmpCloudServer);
    interfaceSetting->cloudServer = (char *)malloc(size + 1);
    if (interfaceSetting->cloudServer != NULL)
    {
      memset(interfaceSetting->cloudServer, 0, size + 1);
      memcpy(interfaceSetting->cloudServer, tmpCloudServer, size);
    }
    if (params->cloudTimeout == 0)
    {
      interfaceSetting->cloudTimeout = DEFAULT_CLOUD_TIMEOUT;
    }
    else
    {
      interfaceSetting->cloudTimeout = params->cloudTimeout;
    }
  }
}

int Http_Initialize(const HttpInitParams *params)
{
  int ret = 0;
  cleanSetting(&gInterfaceSetting);
  if (params->logEnable == 1 && params->logCb != NULL)
  {
    log_set_cb(params->logCb);
    log_set_level(-1);
  }
  else
  {
    log_set_level(7); //disable log
  }

  if (geteuid() == 0)
  {
    //must run as root
  }
  else
  {
    log_error("user is not root, run as root and try again");
    return -1;
  }

  initSSL("server.crt", "server.key");

  initCloudScan(&gInterfaceSetting, params);

  ret = initInterceptorSetting(params);
  if (ret < 0)
  {
    log_error("initInterceptorSetting failed");
    return ret;
  }

  ret = initExclusions();
  if (ret < 0)
  {
    log_error("initExclusions failed");
    return ret;
  }

  initUrlCache();

  ret = proxyThreadInitialize(params);
  if (ret < 0)
  {
    log_error("proxyThreadInitialize failed");
    return ret;
  }

  gInterfaceSetting.interfaceInitFlag = 1;

  log_info("Http_Initialize success!");
  return ret;
}

int Http_Start()
{
  if (gInterfaceSetting.interfaceInitFlag != 1)
  {
    return -1;
  }
  return proxyStart();
}

int Http_Stop()
{
  if (gInterfaceSetting.interfaceInitFlag != 1)
  {
    return -1;
  }
  return proxyStop();
}

int Http_Uninitialize()
{
  int ret;
  waitCallbackCounterIsZero(-1);
  ret = interceptorUninitialize();
  if (ret < 0)
  {
    log_error("interceptorUninitialize failed");
  }

  ret = proxyUninitialize();
  if (ret < 0)
  {
    log_error("proxyUninitialize failed");
  }

  ret = uninitExclusions();
  if (ret < 0)
  {
    log_error("uninitExclusions failed");
  }

  cleanUrlCache();

  if (gInterfaceSetting.cloudEnable != 0)
  {
    curl_global_cleanup();
  }

  log_info("http interceptor exit");
  log_set_level(0);
  log_set_cb(NULL);

  cleanSetting(&gInterfaceSetting);
  cleanCallbackCounter();
  cleanCallbacks();

  uninitSSL();
  return ret;
}

int Http_SetCallbacks(const HttpCbks *cbks)
{
  if (gInterfaceSetting.interfaceInitFlag != 1)
  {
    return -1;
  }
  waitCallbackCounterIsZero(0);
  return setCallbacks(cbks);
}

int Http_IsPathExcluded(const wchar_t *path, int *isExcluded)
{
  *isExcluded = 0;
  return HTTP_STATUS_SUCCESS;
}

int Http_AddFileExclusion(const wchar_t *path)
{
  return HTTP_STATUS_SUCCESS;
}

int Http_RemoveFileExclusion(const wchar_t *path)
{
  return HTTP_STATUS_SUCCESS;
}

int Http_GetFileExclusions(wchar_t ***pathExclusions, unsigned int *dwSize)
{
  *pathExclusions = NULL;
  *dwSize = 0;
  return HTTP_STATUS_SUCCESS;
}

int Http_FreeFileExclusions(wchar_t **pathExclusions, unsigned int dwSize)
{
  return HTTP_STATUS_SUCCESS;
}

int Http_ClearFileExclusions()
{
  return HTTP_STATUS_SUCCESS;
}

int Http_AddFolderExclusion(const wchar_t *path)
{
  if (addPathToExclusions(path) == 0)
  {
    return HTTP_STATUS_SUCCESS;
  }
  else
  {
    return HTTP_STATUS_NOT_FOUND;
  }
}

int Http_IsPathInExclustions(const wchar_t *path)
{
  return isPathInExclustions(path);
}

int Http_RemoveFolderExclusion(const wchar_t *path)
{
  if (removePathFromExclusions(path) == 0)
  {
    return HTTP_STATUS_SUCCESS;
  }
  else
  {
    return HTTP_STATUS_NOT_FOUND;
  }
}

//TODO
int Http_GetFolderExclusions(wchar_t ***pathExclusions, unsigned int *dwSize)
{
  *pathExclusions = NULL;
  *dwSize = 0;
  return HTTP_STATUS_SUCCESS;
}

int Http_FreeFolderExclusions(wchar_t **pathExclusions, unsigned int dwSize)
{
  return HTTP_STATUS_SUCCESS;
}

int Http_ClearFolderExclusions()
{
  if (cleanExclusions() == 0)
  {
    return HTTP_STATUS_SUCCESS;
  }
  else
  {
    return HTTP_STATUS_NOT_FOUND;
  }
}

int Http_ClearExclusions()
{
  if (cleanExclusions() == 0)
  {
    return HTTP_STATUS_SUCCESS;
  }
  else
  {
    return HTTP_STATUS_NOT_FOUND;
  }
}
