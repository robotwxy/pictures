/**
@file
@brief    interceptor interface.
@details  Copyright (c) 2020 Acronis
@author   Bruce Wang (Bruce.Wang@acronis.com)
*/
#ifndef HTTP_INTERFACE_H
#define HTTP_INTERFACE_H
#include <stdint.h>
#include <stddef.h>
#include <stdarg.h>

static const int UNFILTER_REASON_FILE_EXCLUSION = 0;
static const int UNFILTER_REASON_HTTP_PARSING_ERROR = 1;
static const int UNFILTER_REASON_WHITELISTED_CONNECTION = 1;
static const int UNFILTER_REASON_MESSAGE_TOO_LONG = 2;
static const int UNFILTER_REASON_PIPELINED_REQUEST = 3;
static const int UNFILTER_REASON_UNKNOWN_PROTOCOL = 4;
static const int UNFILTER_REASON_CONNECTION_UPGRADE = 5;
static const int UNFILTER_REASON_UNKNOWN = 100;

static const int CLOUD_STATUS_SAFE = 0;
static const int CLOUD_STATUS_MALWARE = 1;
static const int CLOUD_STATUS_PHISHING = 2;
static const int CLOUD_STATUS_FRAUD = 4;
static const int CLOUD_STATUS_UNTRUSTED = 8;
static const int CLOUD_STATUS_SPAM = 16;
static const int CLOUD_STATUS_UNKNOWN = 32;
static const int CLOUD_STATUS_PUA = 64;
static const int CLOUD_STATUS_MINER = 128;

static const int DIRECTION_IN = 0;
static const int DIRECTION_OUT = 1;
static const int DIRECTION_UNKNOWN = 2;

static const int PROTOCOL_SMB = 0;
static const int PROTOCOL_HTTP = 1;
static const int PROTOCOL_SMTP = 2;
static const int PROTOCOL_POP3 = 3;
static const int PROTOCOL_SSL = 4;
static const int PROTOCOL_FTP = 5;
static const int PROTOCOL_RPC = 6;
static const int PROTOCOL_LSA = 7;
static const int PROTOCOL_BITTORRENT = 8;
static const int PROTOCOL_NOT_ANALYZED = 100;
static const int PROTOCOL_UNAVAILABLE = 101;

#define MAKECODE_HTTP_ERROR(code) ((int)((3 << 30) | (code)))
#define HTTP_SUCCESS(Status) (Status >= 0)

#define HTTP_STATUS_SUCCESS 0
#define HTTP_ERROR_FAILED MAKECODE_HTTP_ERROR(0)
#define HTTP_ERROR_INVALID_PARAMETER MAKECODE_HTTP_ERROR(1)
#define HTTP_ERROR_INVALID_OPTION MAKECODE_HTTP_ERROR(2)
#define HTTP_ERROR_INVALID_LICENSE MAKECODE_HTTP_ERROR(3)
#define HTTP_ERROR_EXPIRED_LICENSE MAKECODE_HTTP_ERROR(4)
#define HTTP_ERROR_CLOUD_INIT_FAILED MAKECODE_HTTP_ERROR(5)
#define HTTP_ERROR_CBK_ALREADY_SET MAKECODE_HTTP_ERROR(6)
#define HTTP_ERROR_ALREADY_EXCLUDED MAKECODE_HTTP_ERROR(7)
#define HTTP_ERROR_NOT_ABSOLUTE_PATH MAKECODE_HTTP_ERROR(8)
#define HTTP_ERROR_NOT_FOUND MAKECODE_HTTP_ERROR(9)
#define HTTP_ERROR_NOT_FILE_PATH MAKECODE_HTTP_ERROR(10)
#define HTTP_ERROR_NOT_FOLDER_PATH MAKECODE_HTTP_ERROR(11)
#define HTTP_ERROR_INIT_REQUIRED MAKECODE_HTTP_ERROR(12)
#define HTTP_ERROR_ALREADY_INITIALIZED MAKECODE_HTTP_ERROR(13)
#define HTTP_ERROR_SERVICE_NOT_READY MAKECODE_HTTP_ERROR(14)
#define HTTP_ERROR_NO_MEMORY MAKECODE_HTTP_ERROR(15)
#define HTTP_ERROR_INCOMPATIBLE_DRIVER MAKECODE_HTTP_ERROR(16)
#define HTTP_ERROR_LOADING_SAV MAKECODE_HTTP_ERROR(17)
#define HTTP_ERROR_CACHE_INIT_FAILED MAKECODE_HTTP_ERROR(18)
#define HTTP_ERROR_OPTIONS_COMBINATION_NOT_ALLOWED MAKECODE_HTTP_ERROR(19)
#define HTTP_ERROR_CLOUD_TIMEOUT MAKECODE_HTTP_ERROR(20)
#define HTTP_ERROR_NO_CLOUD_QUERY_MADE MAKECODE_HTTP_ERROR(21)
#define HTTP_ERROR_CLOUD_ERROR MAKECODE_HTTP_ERROR(22)
#define HTTP_ERROR_CLOUD_NOT_INITIALIZED MAKECODE_HTTP_ERROR(23)
#define HTTP_ERROR_RAWDATA_CANNOT_BE_MODIFIED MAKECODE_HTTP_ERROR(24)
#define HTTP_ERROR_NOT_LOCAL_PATH MAKECODE_HTTP_ERROR(25)
#define HTTP_ERROR_NOT_VALID_UNC_PATH MAKECODE_HTTP_ERROR(26)
#define HTTP_ERROR_REPLACE_CONTENT_NOT_VALID MAKECODE_HTTP_ERROR(27)

typedef struct httpHandleStruct HttpHandle;

typedef struct _ConnectionAddress
{
  unsigned short port;
  unsigned int addrlength; // 4 for ipv4, 16 for ipv6
  unsigned char ipaddr[16];
} ConnectionAddress;

typedef struct _ConnectionInfo
{
  const wchar_t *processPath;
  unsigned long long processId;
  ConnectionAddress *localAddress;
  ConnectionAddress *remoteAddress;
  int direction;
  int protocol;
} ConnectionInfo;

typedef struct _RawData
{
  const void *data;
  unsigned int dataSize;
  int direction; // 0 is out, 1 is in
  int bCanBeModified;
} RawData;

typedef struct _PortRange
{
  unsigned short start;
  unsigned short end;
} PortRange;

typedef struct _UnfilterDetails
{
  int reason;
} UnfilterDetails;

typedef struct _CloudResponse
{
  int status;         // http response code
  int status_message; // CLOUD_STATUS values;
  int isgrey;
  const char *categories;
  const char *source;
} CloudResponse;

/**
* Get request unique identifier
*
* @param[in] message - the message to be queried
* @returns unique id
*/
typedef unsigned long long (*HTTP_REQUEST_GET_ID)(HttpHandle *message);

/**
* Get request header
*
* @param[in] message - the message to be queried
* @param[in] name - header name
*
* @returns header value if the header with name exists
* @returns NULL if the header with name does not exist
*/
typedef const char *(*HTTP_REQUEST_GET_HEADER_VALUE)(HttpHandle *message, const char *name);

/**
* Set or Update a request header.
*
* @param[in] message - the message to be used
* @param[in] name - header name
* @param[in] value - header value
*
* If the header with name does not exist, a new header will be added, otherwise the existing value will be updated
* @returns -1 on error
* @returns 0 on success
*/
typedef int (*HTTP_REQUEST_SET_HEADER_VALUE)(HttpHandle *message, const char *name, const char *value);

/**
* Deletes a header if it exists. Does nothing if it does not exist.
*
* @param[in] message - the message to be used
* @param[in] name - header name to be deleted
*/
typedef void (*HTTP_REQUEST_DELETE_HEADER)(HttpHandle *message, const char *name);

/**
* Obtain a list copy of the request headers. Must release memory with a call to FreeHeadersList()
* 
* @param[in] message - the message to be queried
* @param[in, out] headers - pointer to a headers list which will be allocated and populated with all the request headers
* @param[in, out] size - size of the headers list
*/
typedef void (*HTTP_REQUEST_GET_HEADER_VALUES_LIST)(HttpHandle *message, char ***headers, unsigned long *size);

/**
* Release memory for a header list.
* 
* @param[in] message - the message to be used
* @param[in] headers - pointer to a header list obtain after a call to GetHeadersList()
* @param[in] size - size of the headers list
*/
typedef void (*HTTP_REQUEST_FREE_HEADERS_LIST)(HttpHandle *message, char **headers, unsigned long size);

/**
* Get request method
* @param[in] message - the message to be queried
* @returns pointer to http method(GET, POST etc)
*/
typedef const char *(*HTTP_REQUEST_METHOD)(HttpHandle *message);

/**
* Get request url
* @param[in] message - the message to be queried
* @returns http request path.
*/
typedef const char *(*HTTP_REQUEST_URL)(HttpHandle *message);

/**
* Get request body, if the body size exceeds max body size, then null will be return.
* @param[in] message - the message to be queried
* @returns pointer to the request parsed body.
*/
typedef const unsigned char *(*HTTP_REQUEST_BODY)(HttpHandle *message);

/**
* Get request body size
* @param[in] message - the message to be queried
* @returns pointer to the request parsed body.
*/
typedef unsigned int (*HTTP_REQUEST_BODY_SIZE)(HttpHandle *message);

/**
* Blocks the HTTP request from being sent to the original server
* @param[in] message - the message to be queried
*/
typedef void (*HTTP_REQUEST_BLOCK)(HttpHandle *message);

/**
* Delete all HTTP headers in the HTTP request
* @param[in] message - the message to be queried
*/
typedef void (*HTTP_REQUEST_DELETE_ALL_HEADERS)(HttpHandle *message);

/**
* Returns the HTTP version
*/
typedef const char *(*HTTP_REQUEST_GET_HTTP_VERSION)(HttpHandle *message);

typedef struct _RequestFunctions
{
  HTTP_REQUEST_GET_ID GetId;
  HTTP_REQUEST_GET_HEADER_VALUE GetHeader;
  HTTP_REQUEST_SET_HEADER_VALUE SetHeader;
  HTTP_REQUEST_DELETE_HEADER DeleteHeader;
  HTTP_REQUEST_GET_HEADER_VALUES_LIST GetHeadersList;
  HTTP_REQUEST_FREE_HEADERS_LIST FreeHeadersList;
  HTTP_REQUEST_METHOD Method;
  HTTP_REQUEST_URL Url;
  HTTP_REQUEST_BODY Body;
  HTTP_REQUEST_BODY_SIZE BodySize;
  HTTP_REQUEST_BLOCK Block;
  HTTP_REQUEST_DELETE_ALL_HEADERS DeleteAllHeaders;
  HTTP_REQUEST_GET_HTTP_VERSION GetHttpVersion;
} RequestFunctions;

/**
* Get response unique identifier
* @param[in] message - the message to be queried
* @returns unique id
*/
typedef unsigned long long (*HTTP_RESPONSE_GET_ID)(HttpHandle *message);

/**
* Get response header
* @param[in] message - the message to be queried
* @param[in] name - header name
* @returns header value if the header with name exists
* @returns NULL if the header with name does not exist
*/
typedef const char *(*HTTP_RESPONSE_GET_HEADER_VALUE)(HttpHandle *message, const char *name);

/**
* find header from header list by header name and replace header value, if header not exist, then create it, heaer name case-insensitive
* @param[in] headerName - header name to find
* @param[in] headerValue - header value to replace
* @returns -1 on error
* @returns 0 on success
*/
typedef int (*HTTP_RESPONSE_SET_HEADER_VALUE)(HttpHandle *message, const char *name, const char *value);

/**
* Deletes a header if it exists. Does nothing if it does not exist.
* @param[in] message - the message to be used
* @param[in] name - header name to be deleted
*/
typedef void (*HTTP_RESPONSE_DELETE_HEADER)(HttpHandle *message, const char *name);

/**
* Obtain a list copy of the response headers. Must release memory with a call to FreeHeadersList()
* @param[in] message - the message to be queried
* @param[in, out] headers - pointer to a headers list which will be allocated and populated with all the response headers
* @param[in, out] size - size of the headers list
*/
typedef void (*HTTP_RESPONSE_GET_HEADERS_LIST)(HttpHandle *message, char ***headers, unsigned long *size);

/**
* Release memory for a header list.
* @param[in] message - the message to be used
* @param[in] headers - pointer to a header list obtain after a call to GetHeadersList()
* @param[in] size - size of the headers list
*/
typedef void (*HTTP_RESPONSE_FREE_HEADERS_LIST)(HttpHandle *message, char **headers, unsigned long size);

/**
* Get the response status code
* @param[in] message - the message to be queried
* @returns the response status code.
*/
typedef int (*HTTP_RESPONSE_STATUS_CODE)(HttpHandle *message);

/**
* Get the response content, if the content size exceeds max body size, then null will be returned.
* @param[in] message - the message to be queried
* Returns a pointer the response body. It is already decoded/decompressed.
*/
typedef const unsigned char *(*HTTP_RESPONSE_CONTENT)(HttpHandle *message);

/**
* Get the response content size
* @param[in] message - the message to be queried
* Returns the size of decoded/decompressed response body.
*/
typedef unsigned int (*HTTP_RESPONSE_CONTENT_SIZE)(HttpHandle *message);

/**
* Buffer this chunked response instead of flushing the first n - 1 chunks. If the message is not chunked this
* method does nothing
* @param[in] message - the message to be queried
* @param[in] enable - enable/disable buffering of the first n - 1 chunks
*/
typedef void (*HTTP_RESPONSE_BUFFER_CHUNKED)(HttpHandle *message, int enable);

/**
* Deletes all headers for this message.
* @param[in] message - the message to be queried
*/
typedef void (*HTTP_RESPONSE_DELETE_ALL_HEADERS)(HttpHandle *message);

/**
* Returns the HTTP version
* @param[in] message - the message to be queried
* @param[out] version_major - the http version major
* @param[out] version_minor - the http version mainor
* @returns -1 if failed, 0 if success
*/
typedef const char *(*HTTP_RESPONSE_GET_HTTP_VERSION)(HttpHandle *message);

/**
* Replaces the status code 
* @param[in] message - the message to be queried
* @param[in] status - status code e.g. 403
*/
typedef int (*HTTP_RESPONSE_REPLACE_STATUS)(HttpHandle *message, unsigned int status);

/**
* Returns the reason phrase.
* @param[in] message - the message to be queried
*/
typedef const char *(*HTTP_RESPONSE_GET_REASON)(HttpHandle *message);

/**
* Replaces the reason phrase
* @param[in] message - the message to be queried
* @param[in] reason - reason phrase e.g. "Forbidden" (nullptr = empty reason phrase)
*/
typedef int (*HTTP_RESPONSE_REPLACE_REASON)(HttpHandle *message, const char *reason);

/**
* Replaces the response body with the buffer specified by `content` with size `contentSize`.
* The response header 'Content-Length' will be update accordingly before the message is sent
* By default, the header 'Content-Type' is not changed. To change it, pass a valid buffer to `contentType`
* parameter
* @param[in] message - the message to be queried
* @param[in] content - pointer to a valid buffer with new response body
* @param[in] contentSize - size of the `content` buffer
* @param[in] contentType - sets the response header 'Content-Type' to the specified value if it's not a null value
*/
typedef int (*HTTP_RESPONSE_REPLACE_CONTENT)(HttpHandle *message, const unsigned char *content, int contentSize, const char *contentType);

typedef struct _ResponseFunctions
{
  HTTP_RESPONSE_GET_ID GetId;
  HTTP_RESPONSE_GET_HEADER_VALUE GetHeader;
  HTTP_RESPONSE_SET_HEADER_VALUE SetHeader;
  HTTP_RESPONSE_DELETE_HEADER DeleteHeader;
  HTTP_RESPONSE_GET_HEADERS_LIST GetHeadersList;
  HTTP_RESPONSE_FREE_HEADERS_LIST FreeHeadersList;
  HTTP_RESPONSE_STATUS_CODE StatusCode;
  HTTP_RESPONSE_CONTENT Content;
  HTTP_RESPONSE_CONTENT_SIZE ContentSize;
  //HTTP_RESPONSE_BUFFER_CHUNKED BufferChunked;
  HTTP_RESPONSE_DELETE_ALL_HEADERS DeleteAllHeaders;
  HTTP_RESPONSE_GET_HTTP_VERSION GetHttpVersion;
  HTTP_RESPONSE_REPLACE_STATUS ReplaceStatus;
  HTTP_RESPONSE_GET_REASON GetReason;
  HTTP_RESPONSE_REPLACE_REASON ReplaceReason;
  HTTP_RESPONSE_REPLACE_CONTENT ReplaceContent;
} ResponseFunctions;

/**
* Get connection unique identifier
* @param[in] message - the message to be queried
* @returns on success, return unique id; on error, return 0
*/
typedef unsigned long long (*HTTP_CONNECTION_GET_ID)(HttpHandle *message);

/**
* Get thread id 
* @param[in] message - the message to be queried
* @returns unique id
*/
typedef unsigned int (*HTTP_CONNECTION_GET_THREAD_ID)(HttpHandle *message);

/**
* Get connection detailed information. See struct `ConnectionInfo`
* @param[in] message - the message to be queried
* @returns pointer to connection detailed information. No need to release memory.
*/
typedef const ConnectionInfo *(*HTTP_CONNECTION_GET_INFO)(HttpHandle *message);

/**
* Creates a response which should be used only when there is no response available in the event callback
* signature(ex: RequestHeaders()), but you want to block the connection and generate a block page before
* waiting for the response.
* @param[in] message - the message to be used
* @returns a pointer to an allocated response structure. Memory must be release with FreeResponse().
*/
typedef ResponseFunctions *(*HTTP_CONNECTION_MAKE_RESPONSE)(HttpHandle *message);

/**
* Release memory for a response.
* @param[in] message - the message to be used
* @param[in] response - pointer to response obtained from a call to MakeResponse()
*/
typedef void (*HTTP_CONNECTION_FREE_RESPONSE)(HttpHandle *message, ResponseFunctions *responseFunctions);

/**
* Replace the response content.
* @param[in] message - the message to be used
* @param[in] request - http request sent to the server
* @param[in, out] response - http response whouse content will be modified
* @param[in] body - body of the page
* @param[in] size - size of the body
* The replaced response will have the format:
* @code{.txt}
* HTTP/1.1 200
* Content-Type: text/html
* Connection: close
* Content-Length: value of the parameter size
* @endcode
* @retval HTTP_STATUS_SUCCESS always
*/
typedef int (*HTTP_CONNECTION_BLOCK_PAGE)(HttpHandle *message, const RequestFunctions *request, ResponseFunctions *response, const unsigned char *body, int size);

/**
* Unfilter the http request and http response associated with the request.
* @param[in] message - the message to be used
* @param[in] request - pointer to http request which will be unfiltered
* @retval HTTP_STATUS_SUCCESS always
*/
typedef int (*HTTP_CONNECTION_SKIP_MESSAGE)(HttpHandle *message, RequestFunctions *request);

/**
* Exclude the current connection
* @param[in] message - the message to be used
* @retval HTTP_STATUS_SUCCESS always
*/
typedef int (*HTTP_CONNECTION_SKIP_FILTERING)(HttpHandle *message);

/**
* Unfilter the http response associated with the request.
* @param[in] message - the message to be used
* @param[in] request - pointer to http request
* @param[in] response - pointer to http response
* @retval HTTP_STATUS_SUCCESS always
*/
typedef int (*HTTP_CONNECTION_SKIP_RESPONSE)(HttpHandle *message, const RequestFunctions *request, ResponseFunctions *response);

/**
* Insert a disconnect on this connection
* @param[in] message - the message to be used
* @retval HTTP_STATUS_SUCCESS always
*/
typedef int (*HTTP_CONNECTION_DISCONNECT)(HttpHandle *message);

/**
* Use this method when you call `Disconnect` or you Block a request and you want to still generate a response
* since the current response(if it exists) would be discarded.
* @param[in] message - the message to be used
* @param[in] request - pointer to request which corresponds to this response. Can be a blocked request for which
* you want to create a fake response
* @param[in] response - pointer to the response which you want to insert
* @retval HTTP_STATUS_SUCCESS always
*/
typedef int (*HTTP_CONNECTION_INSERT_RESPONSE)(HttpHandle *message, const RequestFunctions *request, ResponseFunctions *response);

// /**
// * Use this method when you call `Disconnect` on a SMTP connection and you want to generate a response
// * @param[in] message - the message to be used
// * @param[in] smtpMessage - Original SMTP message
// * @param[in] response - Server response that you want to insert
// * @retval HTTP_STATUS_SUCCESS always
// */
// typedef int					  (*SMTP_CONNECTION_INSERT_SMTP_RESPONSE)(HttpHandle * message, const SmtpMessageFunctions* smtpMessage, const char* response);
/**
* Enable/Disable cloud queries. Default is enabled if ncClientId was set.
* @param[in] message - the message to be used
* @param[in] enable - enable/disable cloud queries
* @retval HTTP_STATUS_SUCCESS always
*/
typedef int (*HTTP_CONNECTION_SET_CLOUD_STATE)(HttpHandle *message, int enable);

/**
* By default we wait for 'url/status' result when the response is completely parsed so the process is as async as
* possible. If needed, call this method to block the current connection until an answer is available or an error
* occurs. Will generate the callback `OnCloudResponse`. If this event already occurred, this function does nothing.
* @param[in] message - the message to be used
* @param[in] request - pointer to http request whose url was used to make the query to 'url/status'.
* @returns HTTP_STATUS_SUCCESS if `OnCloudResponse` was generated or an error code with descriptive name.
*/
typedef int (*HTTP_CONNECTION_WAIT_CLOUD_STATUS)(HttpHandle *message, RequestFunctions *request);

typedef struct _ConnectionFunctions
{
  HTTP_CONNECTION_GET_ID GetId;
  //HTTP_CONNECTION_GET_THREAD_ID GetThreadId;
  HTTP_CONNECTION_GET_INFO GetInfo;
  HTTP_CONNECTION_MAKE_RESPONSE MakeResponse;
  HTTP_CONNECTION_FREE_RESPONSE FreeResponse;
  HTTP_CONNECTION_BLOCK_PAGE BlockPage;
  HTTP_CONNECTION_SKIP_MESSAGE SkipMessage;
  HTTP_CONNECTION_SKIP_FILTERING SkipFiltering;
  HTTP_CONNECTION_SKIP_RESPONSE SkipResponse;
  HTTP_CONNECTION_DISCONNECT Disconnect;
  HTTP_CONNECTION_INSERT_RESPONSE InsertResponse;
  HTTP_CONNECTION_WAIT_CLOUD_STATUS WaitCloudStatus;
} ConnectionFunctions;

/**
* Use this method to replace data.
* @param message: message handler that the caller can use to manipulate this message
* @param data : data to be inserted
* @param dataSize : size of the data to be inserted
* @retval 0 on success, -1 on error
*/
typedef int (*RAW_REPLACE_DATA)(HttpHandle *message, const void *data, unsigned int dataSize);

typedef struct _RawDataFunctions
{
  RAW_REPLACE_DATA ReplaceData;
} RawDataFunctions;

/**
* Called when a new connection is created. Will always be the first event received.
* @param message: message handler that the caller can use to manipulate this message
* @param connection: pointer to newly created connection
* @param connContext : context for the connection
*/
typedef int (*HTTP_NEW_CONNECTION)(HttpHandle *message, ConnectionFunctions *connection, void **connContext);

/**
* Called when the connection is destroyed
* @param message: message handler that the caller can use to manipulate this message
* @param connection: pointer to the connection
* @param connContext : context for the connection
*/
typedef int (*HTTP_CONNECTION_DESTROYED)(HttpHandle *message, ConnectionFunctions *connection, void *connContext);

/**
* Called when a connection is unfilter after a decision is made by the proxy.
* It's not generated when a provider decides to explicitly unfilter this connection(by making a call to SkipFiltering())
* @param message: message handler that the caller can use to manipulate this message
* @param connectionInfo: pointer to struct ConnectionInfo with connection detailed information
* to be unfiltered can be made before the http parsing begins(file/folder exclusion)
* @param unfilterReason: why we don't scan the connection anymore. UNFILTER_REASON values
*/
typedef int (*HTTP_CONNECTION_UNFILTERED)(HttpHandle *message, const ConnectionInfo *connectionInfo, UnfilterDetails *unfilterDetails);

/**
* Called after the request headers are parsed.
* To edit headers use RequestFunctions.
* @param message: message handler that the caller can use to manipulate this message
* @param connection: pointer to connection
* @param request: pointer to the request. Note: the request body is not available at this stage
* @param connContext : context for the connection
*/
typedef int (*HTTP_REQUEST_HEADERS)(HttpHandle *message, ConnectionFunctions *connection, RequestFunctions *request, void *connContext);

/**
* This is the last place where the request headers can be modified before sending them to the server.
* Also, last place where the request can be blocked.
* To edit headers use RequestFunctions.
* Called after the request body is parsed
* @param message: message handler that the caller can use to manipulate this message
* @param connection: pointer to connection
* @param request: pointer to the request.
* @param connContext : context for the connection
*/
typedef int (*HTTP_REQUEST_COMPLETE)(HttpHandle *message, ConnectionFunctions *connection, RequestFunctions *request, void *connContext);

/**
* Called after the response headers are parsed.
* To edit headers use ResponseFunctions.
* @param message: message handler that the caller can use to manipulate this message
* @param connection: pointer to connection
* @param request: pointer to the request.
* @param response: pointer to http response Note: the response body is not available at this stage
* @param connContext : context for the connection
*/
typedef int (*HTTP_RESPONSE_HEADERS)(HttpHandle *message, ConnectionFunctions *connection, const RequestFunctions *request, ResponseFunctions *response, void *connContext);

/**
* Called on every completely received and parsed (request, response) pair for this connection.
* It is not allowed to modify the response here. The modification must occur in the callback PostScan which always occurs after.
* @param message: message handler that the caller can use to manipulate this message
* @param connection: pointer to connection
* @param request: pointer to fully parsed http request
* @param response: pointer to http response coresponding to request
* @param connContext : context for the connection
*/
typedef int (*HTTP_MESSAGE)(HttpHandle *message, const ConnectionFunctions *connection, const RequestFunctions *request, const ResponseFunctions *response, void *connContext);

/**
* Generated  only if cloud scanning is enabled
* It is not allowed to modify the response here. The modification must occur in the callback OnPostScan which always occurs after.
* @param connection pointer to connection
* @param message: message handler that the caller can use to manipulate this message
* @param request: pointer to a fully parsed http request (header + body)
* @param response: pointer to http response coresponding to @request
* @param cloudResponse: response of the query to 'url/status' service
* @param connContext : context for the connection
*/
typedef int (*HTTP_ON_CLOUD_RESPONSE)(HttpHandle *message, const ConnectionFunctions *connection, const RequestFunctions *request, const ResponseFunctions *response, const CloudResponse *cloudResponse, void *connContext);

/**
* Called on every completely received and parsed (request, response) pair for this connection.
* The difference to Message() is that here you are allowed to modify connection data and response.
* Flow: modify response content => set block page(BlockPage()) => disconnect:Disconnect())
* @param message: message handler that the caller can use to manipulate this message
* @param connection: pointer to connection
* @param request: pointer to fully parsed http request
* @param response: pointer to http response coresponding to request
* @param connContext : context for the connection
*/
typedef int (*HTTP_POST_SCAN)(HttpHandle *message, ConnectionFunctions *connection, const RequestFunctions *request, ResponseFunctions *response, void *connContext);

// /**
// * Called on every completely received POP3 message for this connection.
// * @param message: message handler that the caller can use to manipulate this message
// * @param connection pointer to connection
// * @param message pointer to fully parsed pop3 message
// * @param connContext : context for the connection
// */
// typedef int (*POP3_MESSAGE)(HttpHandle *message, ConnectionFunctions *connection, Pop3MessageFunctions *pop3Message, void *connContext);
/**
// * Called on every completely received SMTP message for this connection.
// * @param message: message handler that the caller can use to manipulate this message
// * @param connection pointer to connection
// * @param message pointer to fully parsed smtp message
// * @param connContext : context for the connection
// */
// typedef int (*SMTP_MESSAGE)(HttpHandle *message, ConnectionFunctions *connection, SmtpMessageFunctions *smtpMessage, void *connContext);

/**
* Called on every domain found for this connection if the connection is via SSL.
* @param message: message handler that the caller can use to manipulate this message
* @param connection pointer to connection
* @param domain pointer to the string containing the domain name
* @param connContext : context for the connection
*/
typedef int (*SSL_DOMAIN)(HttpHandle *message, ConnectionFunctions *connection, const char *domain, void *connContext);

/**
* Called when the protocol was not identified.
* @param message: message handler that the caller can use to manipulate this message
* @param connection pointer to connection
* @param rawDataFcts pointer to raw data functions	
* @param rawData pointer to a RawData structure
* @param connContext : context for the connection
*/
typedef int (*ON_RAW_DATA)(HttpHandle *message, ConnectionFunctions *connection, RawDataFunctions *rawDataFcts, RawData *rawData, void *connContext);

/**
* callback of logs in interceptor.
* @param level: log level: enum { LOG_TRACE, LOG_DEBUG, LOG_INFO, LOG_WARN, LOG_ERROR, LOG_FATAL };
* @param file: the file print the log
* @param line: the line the log is called	
* @param fmt, ...: formatting strings
*/
typedef void (*INTERCEPTOR_LOG_CB)(int level, const char *file, int line, const char *fmt, va_list arg);

typedef struct _HttpCbks
{
  HTTP_NEW_CONNECTION NewConnection;
  HTTP_CONNECTION_DESTROYED ConnectionDestroyed;
  HTTP_CONNECTION_UNFILTERED ConnectionUnfiltered;
  HTTP_REQUEST_HEADERS RequestHeaders;
  HTTP_REQUEST_COMPLETE RequestComplete;
  HTTP_RESPONSE_HEADERS ResponseHeaders;
  HTTP_MESSAGE Message;
  HTTP_ON_CLOUD_RESPONSE OnCloudResponse;
  HTTP_POST_SCAN PostScan;
  //POP3_MESSAGE Pop3Message;
  //SMTP_MESSAGE SmtpMessage;
  SSL_DOMAIN SSLDomain;
  ON_RAW_DATA OnRawData;
} HttpCbks;

#define DEFAULT_MAX_CONNECTION_THREADS 128
#define DEFAULT_MAX_BODY_SIZE (3 * 1024 * 1024) //3 MB
#define DEFAULT_CLOUD_TIMEOUT 10

typedef struct _HttpInitParams
{
  unsigned char cloudScanEnable;        //enable URL cloud scan
  unsigned char cloudScanForSSLEnable;  //enable URL cloud scan for SSL domain
  char *cloudScanServer;                //The server address to the URL reputation cloud service, URL reputation won’t work without this server address.
  unsigned short *remoteHttpPorts;      //tcp ports list to monitor, default is 80
  unsigned short remoteHttpPortsCount;  //number of tcp ports list
  PortRange *remotePortRanges;          //tcp ports ranges list to monitor, default is null
  unsigned short remotePortRangesCount; //number of tcp ports ranges list
  uint32_t listenIpAddr;                //the ip address the interceptor uses to listen
  unsigned short listenPort;            //the tcp ports the interceptor uses to listen
  unsigned short maxConnectionThreads;  //max tcp connection the interceptor can accept, default is 128
  unsigned int maxHttpBodySize;         // max http body size the interceptor can recv, the body exceed this size will be ignore, the default size is 3MB
  int logEnable;                        //set this value to 1 to mute log in stderr
  // char *logFile;                        // the name of the log file, the default is "default.log"
  INTERCEPTOR_LOG_CB logCb;
  unsigned int cloudTimeout;
} HttpInitParams;

/**
* Initializes the SDK
* @param[in] params - data used for initializing the SDK
* @returns 0 if success
* @returns <0 if error
*/
int Http_Initialize(const HttpInitParams *params);

/**
* Uninitializes the SDK
* @returns 0 if success
* @returns <0 if error
*/
int Http_Uninitialize();

/**
* Let SDK start to intercept packets
* @returns 0 if success
* @returns <0 if error
*/
int Http_Start();

/**
* Let SDK stop to intercept packets
* @returns 0 if success
* @returns <0 if error
*/
int Http_Stop();

/**
* Set the callbacks. The callbacks are automatically removed at Http_Uninitialize.
* @param[in] cbks - data containing the pointers for the callbacks
* @returns 0 if success
* @returns <0 if error
*/
int Http_SetCallbacks(const HttpCbks *cbks);

// int Http_GetOption(int option, void *value);
// int Http_SetOption(int option, const void *value);

/**
* Check if the specified path is excluded. Can be a file or a folder.
* @param[in] path - path to be checked
* @param[in, out] isExcluded - true if the path is excluded
* @return HTTP_STATUS_SUCCESS on success or an error code 
*/
int Http_IsPathExcluded(const wchar_t *path, int *isExcluded);
/**
* Add a new file path to the exclusion list
* @param[in] path - path to be added (ex: L"/opt/google/chrome/chrome")
* @return HTTP_STATUS_SUCCESS on success or an error code 
*/
int Http_AddFileExclusion(const wchar_t *path);
/**
* Remove path from the exclusion list
* @param[in] path - path to be removed (ex: L"/opt/google/chrome/chrome")
* @return HTTP_STATUS_SUCCESS on success or an error code 
*/
int Http_RemoveFileExclusion(const wchar_t *path);
/**
* Get all the file exclusions.
* @param[in, out] pathExclusions - list of files being skipped by httpproxy. Must release the memory using FreeFileExclusions()
* @param[in, out] dwSize - the number of file exclusions returned
* @return HTTP_STATUS_SUCCESS on success or an error code 
*/
int Http_GetFileExclusions(wchar_t ***pathExclusions, unsigned int *dwSize);
/**
* Release memory of a file exclusion list.
* @param[in] pathExclusions - pointer to list obtained from a call to GetFileExclusions()
* @param[in] dwSize - the number of file exclusions returned by a call to GetFileExclusions
* @return HTTP_STATUS_SUCCESS on success or an error code 
*/
int Http_FreeFileExclusions(wchar_t **pathExclusions, unsigned int dwSize);

/**
* Delete all the file exclusions.
* @return HTTP_STATUS_SUCCESS on success or an error code 
*/
int Http_ClearFileExclusions();
/**
* Will exclude everything under the specified folder an unlimited number of levels.
* ex: L"/opt/google/" => "/opt/google/chrome/chrome" will be excluded
* @param[in] path - folder to be excluded
* @return HTTP_STATUS_SUCCESS on success or an error code 
*/
int Http_AddFolderExclusion(const wchar_t *path);

int Http_IsPathInExclustions(const wchar_t *path);

/**
* Remove path from exclusion list
* @param[in] path - folder to be removed from exclusion list
* @return HTTP_STATUS_SUCCESS on success or an error code 
*/
int Http_RemoveFolderExclusion(const wchar_t *path);
/**
* Get all folder exclusions.
* @param[in,out] pathExclusions - list of folders being skipped by httpproxy. Must release the memory using FreeFolderExclusions()
* @param[out] dwSize - the number of folder exclusions returned 
* @return HTTP_STATUS_SUCCESS on success or an error code
*/
int Http_GetFolderExclusions(wchar_t ***pathExclusions, unsigned int *dwSize);
/**
* Release memory of a folder exclusion list.
* @param[in] pathExclusions - pointer to list obtained from a call to GetFolderExclusions()
* @param[int] dwSize - the number of folder exclusions returned by a call to GetFolderExclusions()
* @return HTTP_STATUS_SUCCESS on success or an error code
*/
int Http_FreeFolderExclusions(wchar_t **pathExclusions, unsigned int dwSize);
/**
* Delete all the folder exclusions.
* @return HTTP_STATUS_SUCCESS on success or an error code
*/
int Http_ClearFolderExclusions();
/**
* Delete all exclusions.
* @return HTTP_STATUS_SUCCESS on success or an error code 
*/
int Http_ClearExclusions();
#endif
