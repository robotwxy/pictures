/**
@file
@brief    interceptor interface functions implementation.
@details  Copyright (c) 2020 Acronis
@author   Bruce Wang (Bruce.Wang@acronis.com)
*/

#include "common.h"
#include "interceptor.h"
#include "interface.h"
#include "interface_functions.h"
#include "http_functions.h"
#include "http_parser_callbacks.h"

#include <pthread.h>

static HttpCbks interceptorHttpCbks = {0};

int setRequestFunctions(RequestFunctions *request)
{
  if (request == NULL)
  {
    return -1;
  }
  request->GetId = http_request_get_id;
  request->GetHeadersList = http_request_get_header_values_list;
  request->FreeHeadersList = http_request_free_headers_list;
  request->Method = http_request_method;
  request->Url = http_request_url;
  request->Body = http_request_body;
  request->BodySize = http_request_body_size;
  request->Block = http_request_block;
  request->DeleteAllHeaders = http_request_delete_all_headers;
  request->GetHttpVersion = http_request_get_http_version;
  request->GetHeader = http_request_get_header_value;
  request->SetHeader = http_request_set_header_value;
  request->DeleteHeader = http_request_delete_header;
  return 0;
}

int setResponseFunctions(ResponseFunctions *response)
{
  if (response == NULL)
  {
    return -1;
  }
  response->GetId = http_response_get_id;
  response->GetHeadersList = http_response_get_header_values_list;
  response->FreeHeadersList = http_response_free_headers_list;
  response->Content = http_response_content;
  response->ContentSize = http_response_content_size;
  response->StatusCode = http_response_status_code;
  response->GetHttpVersion = http_response_get_http_version;
  response->GetReason = http_response_get_reason;
  response->GetHeader = http_response_get_header_value;
  response->SetHeader = http_response_set_header_value;
  response->DeleteHeader = http_response_delete_header;
  response->DeleteAllHeaders = http_response_delete_all_headers;
  response->ReplaceContent = http_response_replace_content;
  response->ReplaceStatus = http_response_replace_status;
  response->ReplaceReason = http_response_replace_reason;
  return 0;
}

int setConnectionFunctions(ConnectionFunctions *connection)
{
  if (connection == NULL)
  {
    return -1;
  }
  connection->GetId = http_connection_get_id;
  connection->GetInfo = http_connection_get_info;
  connection->SkipMessage = http_connection_skip_message;
  connection->SkipFiltering = http_connection_skip_filtering;
  connection->Disconnect = http_connection_disconnect;
  connection->MakeResponse = http_connection_make_response;
  connection->FreeResponse = http_connection_free_response;
  connection->InsertResponse = http_connection_insert_response;
  connection->SkipResponse = http_connection_skip_response;
  connection->BlockPage = http_connection_block_page;
  connection->WaitCloudStatus = http_connection_wait_cloud_status;
  return 0;
}

int setRawDataFunctions(RawDataFunctions *rawData)
{
  if (rawData == NULL)
  {
    return -1;
  }
  rawData->ReplaceData = raw_data_replace_data;
  return 0;
}

// recv callbcks and register callbacks
int setCallbacks(const HttpCbks *cbks)
{
  if (cbks == NULL)
  {
    return -1;
  }
  if (cbks->NewConnection != NULL)
  {
    interceptorHttpCbks.NewConnection = cbks->NewConnection;
  }
  if (cbks->ConnectionDestroyed != NULL)
  {
    interceptorHttpCbks.ConnectionDestroyed = cbks->ConnectionDestroyed;
  }
  if (cbks->ConnectionUnfiltered != NULL)
  {
    interceptorHttpCbks.ConnectionUnfiltered = cbks->ConnectionUnfiltered;
  }
  if (cbks->RequestHeaders != NULL)
  {
    interceptorHttpCbks.RequestHeaders = cbks->RequestHeaders;
  }
  if (cbks->RequestComplete != NULL)
  {
    interceptorHttpCbks.RequestComplete = cbks->RequestComplete;
  }
  if (cbks->ResponseHeaders != NULL)
  {
    interceptorHttpCbks.ResponseHeaders = cbks->ResponseHeaders;
  }
  if (cbks->Message != NULL)
  {
    interceptorHttpCbks.Message = cbks->Message;
  }
  if (cbks->OnCloudResponse != NULL)
  {
    interceptorHttpCbks.OnCloudResponse = cbks->OnCloudResponse;
  }
  if (cbks->SSLDomain != NULL)
  {
    interceptorHttpCbks.SSLDomain = cbks->SSLDomain;
  }
  if (cbks->PostScan != NULL)
  {
    interceptorHttpCbks.PostScan = cbks->PostScan;
  }
  if (cbks->OnRawData != NULL)
  {
    interceptorHttpCbks.OnRawData = cbks->OnRawData;
  }
  INTERCEPTOR_DEBUG_PRINT("setCallbacks ok");
  return 0;
}

void cleanCallbacks()
{
  memset(&interceptorHttpCbks, 0, sizeof(HttpCbks));
}

static int currentCallbackCounter = 0;
static pthread_mutex_t callbackCounterMutex = PTHREAD_MUTEX_INITIALIZER;

static int addCallbackCounter()
{
  if (currentCallbackCounter < 0)
  {
    return -1;
  }
  pthread_mutex_lock(&callbackCounterMutex);
  currentCallbackCounter++;
  pthread_mutex_unlock(&callbackCounterMutex);
  return 0;
}

static void deleteCallbackCounter()
{
  if (currentCallbackCounter < 0)
  {
    return;
  }
  pthread_mutex_lock(&callbackCounterMutex);
  currentCallbackCounter--;
  pthread_mutex_unlock(&callbackCounterMutex);
}

int waitCallbackCounterIsZero(int newCounter)
{

  while (1)
  {
    pthread_mutex_lock(&callbackCounterMutex);
    if (currentCallbackCounter <= 0)
    {
      currentCallbackCounter = newCounter;
      pthread_mutex_unlock(&callbackCounterMutex);
      break;
    }
    pthread_mutex_unlock(&callbackCounterMutex);
  }

  return 0;
}

void cleanCallbackCounter()
{
  currentCallbackCounter = 0;
  pthread_mutex_unlock(&callbackCounterMutex);
}

int cbNotifyNewConnection(Connection *conn)
{
  if (conn == NULL)
  {
    return -1;
  }
  if (interceptorHttpCbks.NewConnection == NULL)
  {
    return -1;
  }
  if (addCallbackCounter() < 0)
  {
    return -1;
  }
  if (conn->skipMessage == 0 && conn->skipFiltering == 0)
  {
    interceptorHttpCbks.NewConnection(&(conn->message), &(conn->connectionFunctions), &(conn->connContext));
  }
  deleteCallbackCounter();
  return 0;
}

int cbNotifyConnectionDestroyed(Connection *conn)
{
  if (conn == NULL)
  {
    return -1;
  }
  if (interceptorHttpCbks.ConnectionDestroyed == NULL)
  {
    return -1;
  }
  if (addCallbackCounter() < 0)
  {
    return -1;
  }
  if (conn->skipMessage == 0 && conn->skipFiltering == 0)
  {
    interceptorHttpCbks.ConnectionDestroyed(&(conn->message), &(conn->connectionFunctions), conn->connContext);
  }
  deleteCallbackCounter();
  return 0;
}

int cbNotifyConnectionUnfiltered(Connection *conn, UnfilterDetails *details)
{
  if (conn == NULL)
  {
    return -1;
  }
  if (interceptorHttpCbks.ConnectionUnfiltered == NULL)
  {
    return -1;
  }
  if (addCallbackCounter() < 0)
  {
    return -1;
  }
  interceptorHttpCbks.ConnectionUnfiltered(&(conn->message), (const ConnectionInfo *)&(conn->info), details);
  deleteCallbackCounter();
  return 0;
}

int cbNotifyRequestHeaders(Connection *conn)
{
  if (conn == NULL)
  {
    return -1;
  }
  if (conn->skipMessage == 0 && conn->skipFiltering == 0)
  {
    if (interceptorHttpCbks.RequestHeaders == NULL)
    {
      return -1;
    }
    if (addCallbackCounter() < 0)
    {
      return -1;
    }
    interceptorHttpCbks.RequestHeaders(&(conn->message), &(conn->connectionFunctions), &(conn->currentReqPtr->requestFunctions), conn->connContext);
    deleteCallbackCounter();
  }
  return 0;
}

int cbNotifyRequestComplete(Connection *conn)
{
  Request *req;
  if (conn == NULL)
  {
    return -1;
  }
  req = conn->currentReqPtr;
  if (req->notifyCompleteFlag == 1)
  {
    return -1;
  }
  req->notifyCompleteFlag = 1;

  if (conn->skipMessage != 0 || conn->skipFiltering != 0 || conn->disConnect != 0)
  {
    goto send;
  }
  if (interceptorHttpCbks.RequestComplete == NULL)
  {
    goto send;
  }
  if (addCallbackCounter() < 0)
  {
    goto send;
  }
  interceptorHttpCbks.RequestComplete(&(conn->message), &(conn->connectionFunctions), &(conn->currentReqPtr->requestFunctions), conn->connContext);
  deleteCallbackCounter();
send:
  if (req->blockFlag == 0 && conn->disConnect == 0)
  {
    sendReqResp(conn->remoteSocket, &(req->startLine), &(req->headers), &(req->headersLen), &(req->body));
  }
  return 0;
}

int cbNotifyResponseHeaders(Connection *conn)
{
  if (conn == NULL)
  {
    return -1;
  }

  if (conn->skipMessage == 0 && conn->skipFiltering == 0)
  {
    if (interceptorHttpCbks.ResponseHeaders == NULL)
    {
      return -1;
    }
    if (addCallbackCounter() < 0)
    {
      return -1;
    }
    interceptorHttpCbks.ResponseHeaders(&(conn->message), &(conn->connectionFunctions), &(conn->currentReqPtr->requestFunctions), &(conn->currentRespPtr->responseFunctions), conn->connContext);
    deleteCallbackCounter();
  }
  return 0;
}

int cbNotifyMessage(Connection *conn)
{
  Response *resp;
  if (conn == NULL)
  {
    return -1;
  }
  resp = conn->currentRespPtr;
  if (resp->notifyCompleteFlag == 1)
  {
    return -1;
  }
  resp->notifyCompleteFlag = 1;

  if (conn->skipMessage != 0 || conn->skipFiltering != 0 || conn->disConnect != 0)
  {
    return -1;
  }
  if (interceptorHttpCbks.Message == NULL)
  {
    return -1;
  }
  if (addCallbackCounter() < 0)
  {
    return -1;
  }
  interceptorHttpCbks.Message(&(conn->message), &(conn->connectionFunctions), &(conn->currentReqPtr->requestFunctions), &(conn->currentRespPtr->responseFunctions), conn->connContext);
  deleteCallbackCounter();
  return 0;
}

int cbNotifyCloudResponse(Connection *conn)
{
  if (conn == NULL)
  {
    return -1;
  }

  if (conn->skipMessage != 0 || conn->skipFiltering != 0 || conn->disConnect != 0)
  {
    return 1;
  }
  if (interceptorHttpCbks.OnCloudResponse == NULL)
  {
    return -1;
  }
  if (addCallbackCounter() < 0)
  {
    return -1;
  }
  interceptorHttpCbks.OnCloudResponse(&(conn->message), &(conn->connectionFunctions), NULL, NULL, &(conn->cloudScan.cloudresponse), conn->connContext);
  deleteCallbackCounter();
  return 0;
}

int cbNotifyPostScan(Connection *conn)
{
  Response *resp;
  if (conn == NULL)
  {
    return -1;
  }
  resp = conn->currentRespPtr;
  if (conn->skipMessage != 0 || conn->skipFiltering != 0 || conn->disConnect != 0)
  {
    goto send;
  }
  if (interceptorHttpCbks.PostScan == NULL)
  {
    goto send;
  }
  if (addCallbackCounter() < 0)
  {
    goto send;
  }
  interceptorHttpCbks.PostScan(&(conn->message), &(conn->connectionFunctions), &(conn->currentReqPtr->requestFunctions), &(conn->currentRespPtr->responseFunctions), conn->connContext);
  deleteCallbackCounter();
send:
  if (conn->disConnect == 0)
  {
    sendReqResp(conn->clientSocket, &(resp->startLine), &(resp->headers), &(resp->headersLen), &(resp->body));
  }
  return 0;
}

int cbNotifySSLDomain(Connection *conn, char *serverName)
{
  if (conn == NULL)
  {
    return -1;
  }

  if (conn->sslDomain.notifyFlag == 1)
  {
    return -1;
  }
  conn->sslDomain.notifyFlag = 1;

  if (conn->skipMessage != 0 || conn->skipFiltering != 0 || conn->disConnect != 0)
  {
    return 1;
  }

  if (interceptorHttpCbks.SSLDomain == NULL)
  {
    return -1;
  }
  if (addCallbackCounter() < 0)
  {
    return -1;
  }
  interceptorHttpCbks.SSLDomain(&(conn->message), &(conn->connectionFunctions), (const char *)serverName, conn->connContext);
  deleteCallbackCounter();
  return 0;
}

int cbNotifyRawData(Connection *conn, int direction)
{
  RawData rawData;
  if (conn == NULL)
  {
    return -1;
  }

  if (conn->skipMessage != 0 || conn->skipFiltering != 0 || conn->disConnect != 0)
  {
    return 1;
  }

  if (interceptorHttpCbks.OnRawData == NULL)
  {
    return -1;
  }

  memset(&rawData, 0, sizeof(RawData));
  rawData.bCanBeModified = 1;
  rawData.data = conn->bufferAddress;
  rawData.dataSize = conn->bufferLen;
  rawData.direction = direction;
  if (addCallbackCounter() < 0)
  {
    return -1;
  }
  interceptorHttpCbks.OnRawData(&(conn->message), &(conn->connectionFunctions), &(conn->rawDataFunctions), &rawData, conn->connContext);
  deleteCallbackCounter();
  return 0;
}

unsigned long long http_connection_get_id(HttpHandle *message)
{
  if (message == NULL)
  {
    return 0;
  }
  if (message->conn == NULL)
  {
    return 0;
  }
  return message->conn->id;
}

const ConnectionInfo *http_connection_get_info(HttpHandle *message)
{
  if (message == NULL)
  {
    return NULL;
  }
  if (message->conn == NULL)
  {
    return NULL;
  }
  return &(message->conn->info);
}

unsigned long long http_request_get_id(HttpHandle *message)
{
  if (message == NULL)
  {
    return 0;
  }
  if (message->conn == NULL)
  {
    return 0;
  }
  return message->conn->currentReqPtr->id;
}

unsigned long long http_response_get_id(HttpHandle *message)
{
  if (message == NULL)
  {
    return 0;
  }
  if (message->conn == NULL)
  {
    return 0;
  }
  return message->conn->currentRespPtr->id;
}

void http_request_get_header_values_list(HttpHandle *message, char ***headers, unsigned long *size)
{
  if (message == NULL)
  {
    return;
  }
  if (message->conn == NULL)
  {
    return;
  }
  *size = 0;
  Request *req = message->conn->currentReqPtr;
  getHeaderList(req->headers, req->headersLen, headers, size);
  return;
}

void http_response_get_header_values_list(HttpHandle *message, char ***headers, unsigned long *size)
{
  if (message == NULL)
  {
    return;
  }
  if (message->conn == NULL)
  {
    return;
  }
  *size = 0;
  Response *resp = message->conn->currentRespPtr;
  getHeaderList(resp->headers, resp->headersLen, headers, size);
  return;
}

static int free_headers_list(char **headers, unsigned long size)
{
  if (headers == NULL)
  {
    return -1;
  }
  unsigned int i;
  for (i = 0; i < size; i++)
  {
    char *header = headers[i];
    if (header == NULL)
    {
      continue;
    }
    free(header);
  }
  free(headers);
  return 0;
}

void http_request_free_headers_list(HttpHandle *message, char **headers, unsigned long size)
{
  free_headers_list(headers, size);
}

void http_response_free_headers_list(HttpHandle *message, char **headers, unsigned long size)
{
  free_headers_list(headers, size);
}

const char *http_request_method(HttpHandle *message)
{
  if (message == NULL)
  {
    return NULL;
  }
  if (message->conn == NULL)
  {
    return NULL;
  }
  return message->conn->currentReqPtr->startLine.method.str;
}

const char *http_request_url(HttpHandle *message)
{
  if (message == NULL)
  {
    return NULL;
  }
  if (message->conn == NULL)
  {
    return NULL;
  }
  return message->conn->currentReqPtr->startLine.realUrl.str;
}

const unsigned char *http_request_body(HttpHandle *message)
{
  if (message == NULL)
  {
    return NULL;
  }
  if (message->conn == NULL)
  {
    return NULL;
  }
  return (unsigned char *)message->conn->currentReqPtr->body.str;
}

const unsigned char *http_response_content(HttpHandle *message)
{
  if (message == NULL)
  {
    return NULL;
  }
  if (message->conn == NULL)
  {
    return NULL;
  }
  return (unsigned char *)message->conn->currentRespPtr->body.str;
}

unsigned int http_request_body_size(HttpHandle *message)
{
  if (message == NULL)
  {
    return -1;
  }
  if (message->conn == NULL)
  {
    return -1;
  }
  return (unsigned int)message->conn->currentReqPtr->body.currentLength;
}

void http_request_block(HttpHandle *message)
{
  if (message == NULL)
  {
    return;
  }
  if (message->conn == NULL)
  {
    return;
  }
  message->conn->skipMessage = 1;
  message->conn->currentReqPtr->blockFlag = 1;
  return;
}

void http_request_delete_all_headers(HttpHandle *message)
{
  if (message == NULL)
  {
    return;
  }
  if (message->conn == NULL)
  {
    return;
  }
  deleteAllHeader(&(message->conn->currentReqPtr->headers), &(message->conn->currentReqPtr->headersLen));
}

void http_response_delete_all_headers(HttpHandle *message)
{
  if (message == NULL)
  {
    return;
  }
  if (message->conn == NULL)
  {
    return;
  }
  deleteAllHeader(&(message->conn->currentRespPtr->headers), &(message->conn->currentRespPtr->headersLen));
}

unsigned int http_response_content_size(HttpHandle *message)
{
  if (message == NULL)
  {
    return -1;
  }
  if (message->conn == NULL)
  {
    return -1;
  }
  return (unsigned int)message->conn->currentRespPtr->body.currentLength;
}

int http_response_status_code(HttpHandle *message)
{
  if (message == NULL)
  {
    return -1;
  }
  if (message->conn == NULL)
  {
    return -1;
  }
  if (message->conn->currentRespPtr->startLine.status.str == NULL)
  {
    return -1;
  }

  return atoi(message->conn->currentRespPtr->startLine.status.str);
}

const char *http_request_get_http_version(HttpHandle *message)
{
  if (message == NULL)
  {
    return NULL;
  }
  if (message->conn == NULL)
  {
    return NULL;
  }
  return message->conn->currentReqPtr->startLine.version.str;
}

const char *http_response_get_http_version(HttpHandle *message)
{
  if (message == NULL)
  {
    return NULL;
  }
  if (message->conn == NULL)
  {
    return NULL;
  }
  return message->conn->currentRespPtr->startLine.version.str;
}

const char *http_response_get_reason(HttpHandle *message)
{
  if (message == NULL)
  {
    return NULL;
  }
  if (message->conn == NULL)
  {
    return NULL;
  }
  return (const char *)message->conn->currentRespPtr->startLine.reason.str;
}

const char *http_request_get_header_value(HttpHandle *message, const char *name)
{
  if (message == NULL)
  {
    return NULL;
  }
  if (message->conn == NULL)
  {
    return NULL;
  }
  return findHeader(message->conn->currentReqPtr->headers, message->conn->currentReqPtr->headersLen, name);
}

const char *http_response_get_header_value(HttpHandle *message, const char *name)
{
  //struct Header *header = NULL;
  if (message == NULL)
  {
    return NULL;
  }
  if (message->conn == NULL)
  {
    return NULL;
  }
  return findHeader(message->conn->currentRespPtr->headers, message->conn->currentRespPtr->headersLen, name);
}

int http_request_set_header_value(HttpHandle *message, const char *name, const char *value)
{
  if (message == NULL)
  {
    return -1;
  }
  if (message->conn == NULL)
  {
    return -1;
  }
  return setHedaer(&(message->conn->currentReqPtr->headers), &(message->conn->currentReqPtr->headersLen), name, value);
}

int http_response_set_header_value(HttpHandle *message, const char *name, const char *value)
{
  if (message == NULL)
  {
    return -1;
  }
  if (message->conn == NULL)
  {
    return -1;
  }
  return setHedaer(&(message->conn->currentRespPtr->headers), &(message->conn->currentRespPtr->headersLen), name, value);
}

void http_request_delete_header(HttpHandle *message, const char *name)
{
  if (message == NULL)
  {
    return;
  }
  if (message->conn == NULL)
  {
    return;
  }
  deleteHeader(message->conn->currentReqPtr->headers, message->conn->currentReqPtr->headersLen, name);
  return;
}

void http_response_delete_header(HttpHandle *message, const char *name)
{
  if (message == NULL)
  {
    return;
  }
  if (message->conn == NULL)
  {
    return;
  }
  deleteHeader(message->conn->currentRespPtr->headers, message->conn->currentRespPtr->headersLen, name);
  return;
}

int http_response_replace_content(HttpHandle *message, const unsigned char *content, int contentSize, const char *contentType)
{
  Response *resp;
  if (content == NULL)
  {
    return -1;
  }
  if (message == NULL)
  {
    return -1;
  }
  if (message->conn == NULL)
  {
    return -1;
  }
  resp = message->conn->currentRespPtr;
  if (contentType != NULL)
  {
    setHedaer(&(resp->headers), &(resp->headersLen), "Content-type", contentType);
  }
  if (resp->body.str != NULL)
  {
    free(resp->body.str);
  }
  resp->body.str = (char *)malloc(contentSize + 1);
  if (resp->body.str == NULL)
  {
    return -1;
  }
  memset(resp->body.str, 0, contentSize + 1);
  memcpy(resp->body.str, content, contentSize);
  resp->body.contentLength = contentSize;
  resp->body.currentLength = contentSize;
  //reset all the body flags
  resp->body.flags = 0;
  //stop send original data to client
  resp->modifiedFlag = 1;
  return 0;
}

int http_connection_skip_message(HttpHandle *message, RequestFunctions *request)
{
  if (message == NULL)
  {
    return -1;
  }
  if (message->conn == NULL)
  {
    return -1;
  }

  message->conn->skipMessage = 1;
  return 0;
}

int http_connection_skip_filtering(HttpHandle *message)
{
  if (message == NULL)
  {
    return -1;
  }
  if (message->conn == NULL)
  {
    return -1;
  }

  message->conn->skipFiltering = 1;

  return 0;
}

int http_connection_disconnect(HttpHandle *message)
{
  if (message == NULL)
  {
    return -1;
  }
  if (message->conn == NULL)
  {
    return -1;
  }

  message->conn->disConnect = 1;

  return 0;
}

ResponseFunctions *http_connection_make_response(HttpHandle *message)
{
  if (message == NULL)
  {
    return NULL;
  }
  if (message->conn == NULL)
  {
    return NULL;
  }
  Response *newResponse = NULL;
  newResponse = (Response *)malloc(sizeof(Response));
  if (newResponse == NULL)
  {
    return NULL;
  }
  memset(newResponse, 0, sizeof(Response));
  cleanResponses(newResponse);
  message->conn->currentRespPtr = newResponse;
  //set response default value
  newResponse->startLine.httpType = HTTP_RESP;
  http_response_replace_version(message, "HTTP/1.0");
  http_response_replace_status(message, 200);
  http_response_replace_reason(message, "Ok");
  http_response_delete_all_headers(message);
  http_response_set_header_value(message, "Content-Type", "text/html");
  http_response_set_header_value(message, "connection", "close");
  return &(newResponse->responseFunctions);
}

void http_connection_free_response(HttpHandle *message, ResponseFunctions *responseFunctions)
{
  if (message == NULL)
  {
    return;
  }
  if (message->conn->currentRespPtr != NULL)
  {
    cleanResponses(message->conn->currentRespPtr);
    free(message->conn->currentRespPtr);
  }
  message->conn->currentRespPtr = &(message->conn->currentResp);
}

int http_connection_insert_response(HttpHandle *message, const RequestFunctions *request, ResponseFunctions *response)
{
  Response *resp;
  if (message == NULL)
  {
    return -1;
  }
  if (message->conn == NULL)
  {
    return -1;
  }
  resp = message->conn->currentRespPtr;
  return sendReqResp(message->conn->clientSocket, &(resp->startLine), &(resp->headers), &resp->headersLen, &(resp->body));
}

int http_connection_skip_response(HttpHandle *message, const RequestFunctions *request, ResponseFunctions *response)
{
  if (message == NULL)
  {
    return -1;
  }
  if (message->conn == NULL)
  {
    return -1;
  }

  message->conn->skipMessage = 1;
  return 0;
}

int http_response_replace_status(HttpHandle *message, unsigned int status)
{
  Response *resp;
  char statusBuf[32];
  if (message == NULL)
  {
    return -1;
  }
  if (message->conn == NULL)
  {
    return -1;
  }
  resp = message->conn->currentRespPtr;
  memset(statusBuf, 0, 32);
  sprintf(statusBuf, "%u", status);
  if (resp->startLine.status.str != NULL)
  {
    resp->startLine.status.str = (char *)realloc(resp->startLine.status.str, strlen(statusBuf) + 1);
  }
  else
  {
    resp->startLine.status.str = (char *)malloc(strlen(statusBuf) + 1);
  }
  if (resp->startLine.status.str == NULL)
  {
    return -1;
  }
  memcpy(resp->startLine.status.str, statusBuf, strlen(statusBuf));
  resp->startLine.status.len = strlen(statusBuf);
  resp->startLine.status.str[resp->startLine.status.len] = 0;
  return 0;
}

int http_response_replace_reason(HttpHandle *message, const char *reason)
{
  Response *resp;
  if (reason == NULL)
  {
    return -1;
  }
  if (message == NULL)
  {
    return -1;
  }
  if (message->conn == NULL)
  {
    return -1;
  }
  resp = message->conn->currentRespPtr;
  if (resp->startLine.reason.str != NULL)
  {
    resp->startLine.reason.str = (char *)realloc(resp->startLine.reason.str, strlen(reason) + 1);
  }
  else
  {
    resp->startLine.reason.str = (char *)malloc(strlen(reason) + 1);
  }
  if (resp->startLine.reason.str == NULL)
  {
    return -1;
  }
  memcpy(resp->startLine.reason.str, reason, strlen(reason));
  resp->startLine.reason.len = strlen(reason);
  resp->startLine.reason.str[resp->startLine.reason.len] = 0;
  return 0;
}

int http_response_replace_version(HttpHandle *message, const char *version)
{
  Response *resp;
  if (version == NULL)
  {
    return -1;
  }
  if (message == NULL)
  {
    return -1;
  }
  if (message->conn == NULL)
  {
    return -1;
  }
  resp = message->conn->currentRespPtr;
  if (resp->startLine.version.str != NULL)
  {
    resp->startLine.version.str = (char *)realloc(resp->startLine.version.str, strlen(version) + 1);
  }
  else
  {
    resp->startLine.version.str = (char *)malloc(strlen(version) + 1);
  }
  if (resp->startLine.version.str == NULL)
  {
    return -1;
  }
  memcpy(resp->startLine.version.str, version, strlen(version));
  resp->startLine.version.len = strlen(version);
  resp->startLine.version.str[resp->startLine.version.len] = 0;
  return 0;
}

int http_connection_block_page(HttpHandle *message, const RequestFunctions *request, ResponseFunctions *response,
                               const unsigned char *body, int size)
{
  Response *resp;
  if (body == NULL)
  {
    return -1;
  }
  if (message == NULL)
  {
    return -1;
  }
  if (message->conn == NULL)
  {
    return -1;
  }
  resp = message->conn->currentRespPtr;
  //set response default value
  resp->startLine.httpType = HTTP_RESP;
  http_response_replace_version(message, "HTTP/1.0");
  http_response_replace_status(message, 200);
  http_response_replace_reason(message, "Ok");
  http_response_delete_all_headers(message);
  http_response_set_header_value(message, "Content-Type", "text/html");
  http_response_set_header_value(message, "connection", "close");
  http_response_replace_content(message, body, size, NULL);
  return sendReqResp(message->conn->clientSocket, &(resp->startLine), &(resp->headers), &resp->headersLen, &(resp->body));
}

int http_connection_wait_cloud_status(HttpHandle *message, RequestFunctions *request)
{
  if (message == NULL)
  {
    return -1;
  }
  Connection *conn = message->conn;
  if (cloudScanResult(conn) != 0)
  {
    return -1;
  }
  return 0;
}

int raw_data_replace_data(HttpHandle *message, const void *data, unsigned int dataSize)
{
  if (data == NULL)
  {
    return -1;
  }
  if (message == NULL)
  {
    return -1;
  }
  if (message->conn == NULL)
  {
    return -1;
  }
  message->conn->bufferAddress = (char *)data;
  message->conn->bufferLen = dataSize;

  return 0;
}
