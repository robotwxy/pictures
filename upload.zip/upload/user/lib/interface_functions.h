/**
@file
@brief    interceptor interface functions implementation.
@details  Copyright (c) 2020 Acronis
@author   Bruce Wang (Bruce.Wang@acronis.com)
*/

#ifndef INTERCEPTOR_INTERFACE_FUNCTIONS_H
#define INTERCEPTOR_INTERFACE_FUNCTIONS_H
#include "http_functions.h"

typedef struct _InterfaceSetting
{
  unsigned char interfaceInitFlag;
  unsigned char cloudEnable;
  unsigned char cloudScanForSSLEnable;
  char *cloudServer;
  unsigned int cloudTimeout;
} InterfaceSetting;

int setCallbacks(const HttpCbks *cbks);
void cleanCallbacks();

int setRequestFunctions(RequestFunctions *request);
int setResponseFunctions(ResponseFunctions *response);
int setConnectionFunctions(ConnectionFunctions *connection);
int setRawDataFunctions(RawDataFunctions *rawData);

int waitCallbackCounterIsZero(int newCounter);
void cleanCallbackCounter();

int cbNotifyNewConnection(Connection *conn);
int cbNotifyConnectionDestroyed(Connection *conn);
int cbNotifyConnectionUnfiltered(Connection *conn, UnfilterDetails *details);
int cbNotifyRequestHeaders(Connection *conn);
int cbNotifyRequestCompleteLargeBody(Connection *conn);
int cbNotifyResponseHeaders(Connection *conn);
int cbNotifyMessageLargeBody(Connection *conn);
int cbNotifyRequestComplete(Connection *conn);
int cbNotifyMessage(Connection *conn);
int cbNotifyCloudResponse(Connection *conn);
int cbNotifyPostScan(Connection *conn);
int cbNotifySSLDomain(Connection *conn, char *serverName);
int cbNotifyRawData(Connection *conn, int direction);

unsigned long long http_connection_get_id(HttpHandle *message);
const ConnectionInfo *http_connection_get_info(HttpHandle *message);
unsigned long long http_request_get_id(HttpHandle *message);
unsigned long long http_response_get_id(HttpHandle *message);
void http_request_get_header_values_list(HttpHandle *message, char ***headers, unsigned long *size);
void http_response_get_header_values_list(HttpHandle *message, char ***headers, unsigned long *size);
void http_request_free_headers_list(HttpHandle *message, char **headers, unsigned long size);
void http_response_free_headers_list(HttpHandle *message, char **headers, unsigned long size);
const char *http_request_method(HttpHandle *message);
const char *http_request_url(HttpHandle *message);
const unsigned char *http_request_body(HttpHandle *message);
const unsigned char *http_response_content(HttpHandle *message);
unsigned int http_request_body_size(HttpHandle *message);
void http_request_block(HttpHandle *message);
void http_request_delete_all_headers(HttpHandle *message);
void http_response_delete_all_headers(HttpHandle *message);
unsigned int http_response_content_size(HttpHandle *message);
int http_response_status_code(HttpHandle *message);
const char *http_request_get_http_version(HttpHandle *message);
const char *http_response_get_http_version(HttpHandle *message);
const char *http_response_get_reason(HttpHandle *message);
const char *http_request_get_header_value(HttpHandle *message, const char *name);
const char *http_response_get_header_value(HttpHandle *message, const char *name);
int http_request_set_header_value(HttpHandle *message, const char *name, const char *value);
int http_response_set_header_value(HttpHandle *message, const char *name, const char *value);
void http_request_delete_header(HttpHandle *message, const char *name);
void http_response_delete_header(HttpHandle *message, const char *name);
int http_response_replace_content(HttpHandle *message, const unsigned char *content, int contentSize, const char *contentType);
int http_connection_skip_message(HttpHandle *message, RequestFunctions *request);
int http_connection_skip_filtering(HttpHandle *message);
int http_connection_disconnect(HttpHandle *message);
ResponseFunctions *http_connection_make_response(HttpHandle *message);
void http_connection_free_response(HttpHandle *message, ResponseFunctions *responseFunctions);
int http_connection_insert_response(HttpHandle *message, const RequestFunctions *request, ResponseFunctions *response);
int http_connection_skip_response(HttpHandle *message, const RequestFunctions *request, ResponseFunctions *response);
int http_response_replace_status(HttpHandle *message, unsigned int status);
int http_response_replace_reason(HttpHandle *message, const char *reason);
int http_response_replace_version(HttpHandle *message, const char *version);
int http_connection_block_page(HttpHandle *message, const RequestFunctions *request, ResponseFunctions *response,
                               const unsigned char *body, int size);
int http_connection_wait_cloud_status(HttpHandle *message, RequestFunctions *request);
int raw_data_replace_data(HttpHandle *message, const void *data, unsigned int dataSize);

#endif
