/**
@file
@brief    interceptor user ioctl.
@details  Copyright (c) 2020 Acronis
@author   Bruce Wang (Bruce.Wang@acronis.com)
*/

#include "common.h"
#include "ioctl.h"
#include <pthread.h>
#include <sys/ioctl.h>
#include <fcntl.h>
#include <unistd.h>
#include <errno.h>

#define GET_NAT_ADDR _IOWR('r', 1, struct ioctl_data *)
#define CLEAN_NAT_ADDR _IOWR('r', 2, struct ioctl_data *)
#define REGISTER_USER _IOWR('r', 3, struct ioctl_data_proxy_info *)
#define UNREGISTER_USER _IOWR('r', 4, struct ioctl_data_proxy_info *)
#define KEEP_ALIVE_USER _IOWR('r', 5, struct ioctl_data_proxy_info *)
#define START_REDIRECTION _IOWR('r', 6, struct ioctl_data_proxy_info *)
#define STOP_REDIRECTION _IOWR('r', 7, struct ioctl_data_proxy_info *)
#define SET_PORTS _IOWR('r', 8, struct ioctl_monitor_port_info *)

#define IOCTL_DEVICE "/dev/redirect_ioctl_device"
#define KEEP_ALIVE_TIME 1

static pthread_mutex_t IoctlMutex = PTHREAD_MUTEX_INITIALIZER;
static pthread_t KeepAliveProxyThread = 0;

int ioctlGetNatDest(struct ioctl_data *natDest, struct sockaddr_in *natSource)
{
  //get the nat dest address by ioctl
  int ioctl_fd, ret;
  struct ioctl_data ioctlData;

  pthread_mutex_lock(&IoctlMutex);
  memset(&ioctlData, 0, sizeof(struct ioctl_data));
  ioctlData.sip = natSource->sin_addr.s_addr;
  ioctlData.sport = ntohs(natSource->sin_port);
  ioctl_fd = open(IOCTL_DEVICE, O_RDWR);
  if (ioctl_fd < 0)
  {
    COMMON_ERROR_PRINT("Cannot open redirect_ioctl_device\n");
    ret = -1;
    goto end;
  }
  ret = ioctl(ioctl_fd, GET_NAT_ADDR, (struct ioctl_data *)&ioctlData);
  if (ret != 0)
  {
    COMMON_ERROR_PRINT("ioctl GET_NAT_ADDR\n");
    ret = -1;
    goto close_fd;
  }
  memcpy(natDest, &ioctlData, sizeof(struct ioctl_data));
  ret = 0;
close_fd:
  close(ioctl_fd);
end:
  pthread_mutex_unlock(&IoctlMutex);
  return ret;
}

int ioctlCleanNatAddr(struct sockaddr_in *natSource)
{
  int ioctl_fd, ret;
  struct ioctl_data ioctlData;

  pthread_mutex_lock(&IoctlMutex);
  memset(&ioctlData, 0, sizeof(struct ioctl_data));
  ioctlData.sip = natSource->sin_addr.s_addr;
  ioctlData.sport = ntohs(natSource->sin_port);
  ioctl_fd = open(IOCTL_DEVICE, O_RDWR);
  if (ioctl_fd < 0)
  {
    COMMON_ERROR_PRINT("Cannot open redirect_ioctl_device\n");
    ret = -1;
    goto end;
  }
  ret = ioctl(ioctl_fd, CLEAN_NAT_ADDR, (struct ioctl_data *)&ioctlData);
  if (ret != 0)
  {
    COMMON_ERROR_PRINT("ioctl CLEAN_NAT_ADDR\n");
    ret = -1;
    goto close_fd;
  }
  ret = 0;
close_fd:
  close(ioctl_fd);
end:
  pthread_mutex_unlock(&IoctlMutex);
  return ret;
}

static int ioctlRegisterKernel(int pid, uint32_t ip, unsigned short port, const HttpInitParams *params)
{
  struct ioctl_data_proxy_info proxyInfo;
  struct ioctl_monitor_port_info portInfo;
  int ioctl_fd, ret;

  memset(&proxyInfo, 0, sizeof(struct ioctl_data_proxy_info));
  proxyInfo.pid = pid;
  proxyInfo.ip = ip;
  proxyInfo.port = port;
  if (params->remoteHttpPorts != NULL &&
      params->remoteHttpPortsCount != 0)
  {
    proxyInfo.monitorPortsCount = params->remoteHttpPortsCount;
  }
  if (params->remotePortRanges != NULL &&
      params->remotePortRangesCount != 0)
  {
    proxyInfo.monitorPortRangesCount = params->remotePortRangesCount;
  }

  pthread_mutex_lock(&IoctlMutex);
  ioctl_fd = open(IOCTL_DEVICE, O_RDWR);
  if (ioctl_fd < 0)
  {
    COMMON_ERROR_PRINT("Cannot open redirect_ioctl_device\n");
    ret = -1;
    goto end;
  }
  ret = ioctl(ioctl_fd, REGISTER_USER, (struct ioctl_data *)&proxyInfo);
  if (ret != 0)
  {
    COMMON_ERROR_PRINT("ioctl REGISTER_USER\n");
    ret = -1;
    goto close_fd;
  }

  if (params->remoteHttpPorts != NULL &&
      params->remoteHttpPortsCount != 0)
  {
    int i;
    unsigned char finish = 0;
    memset(&portInfo, 0, sizeof(struct ioctl_monitor_port_info));
    portInfo.type = TYPE_PORT;
    for (i = 0; i < params->remoteHttpPortsCount; i++)
    {
      portInfo.port = params->remoteHttpPorts[i];
      ret = ioctl(ioctl_fd, SET_PORTS, (struct ioctl_monitor_port_info *)&portInfo);
      if (ret < 0)
      {
        COMMON_ERROR_PRINT("ioctl SET_PORTS\n");
        ret = -1;
        goto close_fd;
      }
      if (ret == params->remoteHttpPortsCount)
      {
        finish = 1;
        break;
      }
    }
    if (finish != 1)
    {
      COMMON_ERROR_PRINT("ioctl SET_PORTS error");
      ret = -1;
      goto close_fd;
    }
  }

  if (params->remotePortRanges != NULL &&
      params->remotePortRangesCount != 0)
  {
    int i;
    unsigned char finish = 0;
    memset(&portInfo, 0, sizeof(struct ioctl_monitor_port_info));
    portInfo.type = TYPE_PORT_RANGE;
    for (i = 0; i < params->remotePortRangesCount; i++)
    {
      memcpy(&(portInfo.portRange), &(params->remotePortRanges[i]), sizeof(PortRange));
      //portInfo.portRange = params->remotePortRanges[i];
      ret = ioctl(ioctl_fd, SET_PORTS, (struct ioctl_monitor_port_info *)&portInfo);
      if (ret < 0)
      {
        COMMON_ERROR_PRINT("ioctl SET_PORTS\n");
        ret = -1;
        goto close_fd;
      }
      if (ret == params->remotePortRangesCount)
      {
        finish = 1;
        break;
      }
    }
    if (finish != 1)
    {
      COMMON_ERROR_PRINT("ioctl SET_PORTS error");
      ret = -1;
      goto close_fd;
    }
  }
  ret = 0;
close_fd:
  close(ioctl_fd);
end:
  pthread_mutex_unlock(&IoctlMutex);
  return ret;
}

static int ioctlUnregisterKernel(int pid)
{
  struct ioctl_data_proxy_info proxyInfo;
  int ioctl_fd, ret;

  pthread_mutex_lock(&IoctlMutex);
  memset(&proxyInfo, 0, sizeof(struct ioctl_data_proxy_info));
  proxyInfo.pid = pid;
  ioctl_fd = open(IOCTL_DEVICE, O_RDWR);
  if (ioctl_fd < 0)
  {
    COMMON_ERROR_PRINT("Cannot open redirect_ioctl_device\n");
    ret = -1;
    goto end;
  }
  ret = ioctl(ioctl_fd, UNREGISTER_USER, (struct ioctl_data *)&proxyInfo);
  if (ret != 0)
  {
    COMMON_ERROR_PRINT("ioctl UNREGISTER_USER\n");
    ret = -1;
    goto close_fd;
  }
  ret = 0;
close_fd:
  close(ioctl_fd);
end:
  pthread_mutex_unlock(&IoctlMutex);
  return ret;
}

static int ioctlKeepAliveKernel(pid_t pid)
{
  struct ioctl_data_proxy_info proxyInfo;
  int ioctl_fd, ret;

  int status = pthread_mutex_trylock(&IoctlMutex);
  if (status != 0)
  {
    goto end;
  }
  memset(&proxyInfo, 0, sizeof(struct ioctl_data_proxy_info));
  proxyInfo.pid = (int)pid;
  ioctl_fd = open(IOCTL_DEVICE, O_RDWR);
  if (ioctl_fd < 0)
  {
    COMMON_ERROR_PRINT("Cannot open redirect_ioctl_device\n");
    ret = -1;
    goto end;
  }
  ret = ioctl(ioctl_fd, KEEP_ALIVE_USER, (struct ioctl_data *)&proxyInfo);
  if (ret != 0)
  {
    COMMON_ERROR_PRINT("ioctl KEEP_ALIVE_USER\n");
    ret = -1;
    goto close_fd;
  }
close_fd:
  close(ioctl_fd);
end:
  pthread_mutex_unlock(&IoctlMutex);
  return ret;
}

int ioctlStartKernel(int pid)
{
  struct ioctl_data_proxy_info proxyInfo;
  int ioctl_fd, ret;

  pthread_mutex_lock(&IoctlMutex);
  memset(&proxyInfo, 0, sizeof(struct ioctl_data_proxy_info));
  proxyInfo.pid = pid;
  ioctl_fd = open(IOCTL_DEVICE, O_RDWR);
  if (ioctl_fd < 0)
  {
    COMMON_ERROR_PRINT("Cannot open redirect_ioctl_device\n");
    ret = -1;
    goto end;
  }
  ret = ioctl(ioctl_fd, START_REDIRECTION, (struct ioctl_data *)&proxyInfo);
  if (ret != 0)
  {
    COMMON_ERROR_PRINT("ioctl START_REDIRECTION\n");
    ret = -1;
    goto close_fd;
  }
  ret = 0;
close_fd:
  close(ioctl_fd);
end:
  pthread_mutex_unlock(&IoctlMutex);
  return ret;
}

int ioctlStopKernel(int pid)
{
  struct ioctl_data_proxy_info proxyInfo;
  int ioctl_fd, ret;

  pthread_mutex_lock(&IoctlMutex);
  memset(&proxyInfo, 0, sizeof(struct ioctl_data_proxy_info));
  proxyInfo.pid = pid;
  ioctl_fd = open(IOCTL_DEVICE, O_RDWR);
  if (ioctl_fd < 0)
  {
    COMMON_ERROR_PRINT("Cannot open redirect_ioctl_device\n");
    ret = -1;
    goto end;
  }
  ret = ioctl(ioctl_fd, STOP_REDIRECTION, (struct ioctl_data *)&proxyInfo);
  if (ret != 0)
  {
    COMMON_ERROR_PRINT("ioctl STOP_REDIRECTION\n");
    ret = -1;
    goto close_fd;
  }
close_fd:
  close(ioctl_fd);
end:
  pthread_mutex_unlock(&IoctlMutex);
  return ret;
}

unsigned char keepAliveFlag = 0;

static void *keepAliveKernel(void *arg)
{
  pid_t pid = getpid();
  while (keepAliveFlag == 1)
  {
    pthread_testcancel();
    ioctlKeepAliveKernel(pid);
    sleep(KEEP_ALIVE_TIME);
  }
  return NULL;
}

static int startKeepAliveThread()
{
  keepAliveFlag = 1;
  return pthread_create(&KeepAliveProxyThread, NULL, keepAliveKernel, NULL);
}

int registerKernel(uint32_t ip, unsigned short port, const HttpInitParams *params)
{
  int pid = getpid();
  if (ioctlRegisterKernel(pid, ip, port, params) < 0)
  {
    return -1;
  }
  return startKeepAliveThread();
}

int unregisterKernel()
{
  int pid;
  int ret = 0;
  pthread_mutex_lock(&IoctlMutex);
  keepAliveFlag = 0;
  //ret = pthread_cancel(KeepAliveProxyThread);
  if (ret != 0)
  {
    COMMON_ERROR_PRINT("pthread_cancel failed, errno: %d", errno);
  }
  IOCTL_DEBUG_PRINT("wait for keep alive thread return");
  ret = pthread_join(KeepAliveProxyThread, NULL);
  if (ret != 0)
  {
    COMMON_ERROR_PRINT("pthread_join failed, errno: %d", errno);
  }
  pthread_mutex_unlock(&IoctlMutex);
  pid = getpid();
  ret = ioctlUnregisterKernel(pid);
  return ret;
}
