/**
@file
@brief    interceptor user ioctl.
@details  Copyright (c) 2020 Acronis
@author   Bruce Wang (Bruce.Wang@acronis.com)
*/

#ifndef HTTP_IOCTL_H
#define HTTP_IOCTL_H

#include "interface.h"
#include <arpa/inet.h>

//#define IOCTL_DEBUG
#ifdef IOCTL_DEBUG
#define IOCTL_DEBUG_PRINT log_debug
#else
#define IOCTL_DEBUG_PRINT(...) /*...*/
#endif

struct ioctl_data
{
  //unsigned char type;   //message type
  unsigned short sport; //source port
  uint32_t sip;         //source ip
  unsigned short dport; //dest port
  uint32_t dip;         //dest ip
};

struct ioctl_data_proxy_info
{
  int pid;
  uint32_t ip;
  unsigned short port;
  unsigned short monitorPortsCount;
  unsigned short monitorPortRangesCount;
};

#define TYPE_PORT 1
#define TYPE_PORT_RANGE 2
struct ioctl_monitor_port_info
{
  unsigned char type;
  unsigned short port;
  PortRange portRange;
};

int ioctlGetNatDest(struct ioctl_data *natDest, struct sockaddr_in *natSource);
int ioctlCleanNatAddr(struct sockaddr_in *natSource);
int ioctlStartKernel(int pid);
int ioctlStopKernel(int pid);
int registerKernel(uint32_t ip, unsigned short port, const HttpInitParams *params);
int unregisterKernel();

#endif
