/**
@file
@brief    interceptor path exclusions.
@details  Copyright (c) 2020 Acronis
@author   Bruce Wang (Bruce.Wang@acronis.com)
*/

#include <stdlib.h>
#include <stdio.h>
#include <wchar.h>
#include <string.h>
#include <assert.h>
#include <pthread.h>
#include "path_exclusions.h"

path_exclusion_folder *exclusionsRoot = NULL;

#define WCHAR_ENDING_BLANK_SIZE 4

static pthread_mutex_t pathExclusionMutex = PTHREAD_MUTEX_INITIALIZER;

static path_exclusion_folder *isFolderInSubfolders(path_exclusion_folder *current, wchar_t *folderName)
{
  path_exclusion_folder *subfolder = NULL;
  subfolder = current->subFolders;
  while (subfolder != NULL)
  {
    if (wcscmp(subfolder->name, folderName) == 0)
    {
      // printf("match\n");
      return subfolder;
    }
    subfolder = subfolder->next;
  }
  return NULL;
}

static path_exclusion_folder *addSubfolder(path_exclusion_folder *current, wchar_t *folderName)
{
  path_exclusion_folder *newFolder = NULL;
  path_exclusion_folder *subfolder = NULL;
  wchar_t *newFolderName = (wchar_t *)calloc(wcslen(folderName) + WCHAR_ENDING_BLANK_SIZE, sizeof(wchar_t));
  if (newFolderName == NULL)
  {
    goto failed;
  }
  wcscpy(newFolderName, folderName);
  newFolder = (path_exclusion_folder *)calloc(1, sizeof(path_exclusion_folder));
  if (newFolder == NULL)
  {
    goto failed;
  }
  subfolder = current->subFolders;
  if (subfolder == NULL)
  {
    current->subFolders = newFolder;
  }
  else
  {
    while (subfolder->next != NULL)
    {
      subfolder = subfolder->next;
    }
    subfolder->next = newFolder;
    newFolder->prev = subfolder;
  }
  newFolder->parent = current;
  newFolder->layer = current->layer + 1;
  newFolder->name = newFolderName;
  newFolder->nameLen = wcslen(newFolderName);
  current->subFoldersLen++;
  // printf("add [%ls]\n", newFolderName);
  return newFolder;
failed:
  if (newFolderName != NULL)
  {
    free(newFolderName);
  }
  if (newFolder != NULL)
  {
    free(newFolder);
  }
  return NULL;
}

int addPathToExclusions(const wchar_t *path)
{
  int ret = -1;
  path_exclusion_folder *current = NULL;
  wchar_t *buffer;
  wchar_t *folderName = NULL;
  wchar_t *tmpPath = NULL;
  pthread_mutex_lock(&pathExclusionMutex);
  tmpPath = (wchar_t *)calloc(wcslen(path) + WCHAR_ENDING_BLANK_SIZE, sizeof(wchar_t));
  if (tmpPath == NULL)
  {
    ret = -1;
    goto end;
  }
  wcscpy(tmpPath, path);
  if (exclusionsRoot == NULL)
  {
    ret = -1;
    goto end;
  }
  current = exclusionsRoot;
  folderName = wcstok(tmpPath, L"/", &buffer);
  while (folderName)
  {
    path_exclusion_folder *subFolder = NULL;
    subFolder = isFolderInSubfolders(current, folderName);
    if (subFolder == NULL)
    {
      subFolder = addSubfolder(current, folderName);
      if (subFolder == NULL)
      {
        ret = -1;
        goto end;
      }
    }
    current = subFolder;
    folderName = wcstok(NULL, L"/", &buffer);
  }
  current->isLastFolder = 1;
  ret = 0;
end:
  pthread_mutex_unlock(&pathExclusionMutex);
  if (tmpPath != NULL)
  {
    free(tmpPath);
  }
  return ret;
}

int isPathInExclustions(const wchar_t *path)
{
  int ret = -1;
  path_exclusion_folder *current = NULL;
  wchar_t *buffer;
  wchar_t *folderName = NULL;
  wchar_t *tmpPath = NULL;
  tmpPath = (wchar_t *)calloc(wcslen(path) + WCHAR_ENDING_BLANK_SIZE, sizeof(wchar_t));
  if (tmpPath == NULL)
  {
    ret = -1;
    goto end;
  }
  wcscpy(tmpPath, path);
  if (exclusionsRoot == NULL)
  {
    ret = -1;
    goto end;
  }
  current = exclusionsRoot;
  folderName = wcstok(tmpPath, L"/", &buffer);
  while (folderName)
  {
    path_exclusion_folder *subFolder = NULL;
    subFolder = isFolderInSubfolders(current, folderName);
    if (subFolder != NULL)
    {
      if (subFolder->isLastFolder == 1)
      {
        ret = 0;
        goto end;
      }
    }
    else
    {
      ret = -1;
      goto end;
    }
    current = subFolder;
    folderName = wcstok(NULL, L"/", &buffer);
  }
  ret = -1;
end:
  if (tmpPath != NULL)
  {
    free(tmpPath);
  }
  return ret;
}

static int removeSubfolder(path_exclusion_folder *current)
{
  path_exclusion_folder *parent = current->parent;
  if (parent == NULL)
  {
    return -1;
  }
  if (parent->subFolders == current)
  {
    parent->subFolders = current->next;
    if (current->next != NULL)
    {
      current->next->prev = NULL;
    }
  }
  else
  {
    current->prev->next = current->next;
    if (current->next != NULL)
    {
      current->next->prev = current->prev;
    }
  }
  // printf("free [%ls]\n", current->name);
  if (current->name != NULL)
  {
    free(current->name);
  }
  free(current);
  parent->subFoldersLen--;
  return 0;
}

int removePathFromExclusions(const wchar_t *path)
{
  int ret = -1;
  path_exclusion_folder *current = NULL;
  wchar_t *buffer;
  wchar_t *folderName = NULL;
  wchar_t *tmpPath = NULL;
  pthread_mutex_lock(&pathExclusionMutex);
  tmpPath = (wchar_t *)calloc(wcslen(path) + WCHAR_ENDING_BLANK_SIZE, sizeof(wchar_t));
  if (tmpPath == NULL)
  {
    ret = -1;
    goto end;
  }
  wcscpy(tmpPath, path);
  if (exclusionsRoot == NULL)
  {
    ret = -1;
    goto end;
  }
  current = exclusionsRoot;
  folderName = wcstok(tmpPath, L"/", &buffer);
  while (folderName)
  {
    path_exclusion_folder *subFolder = NULL;
    subFolder = isFolderInSubfolders(current, folderName);
    if (subFolder == NULL)
    {
      ret = -1;
      goto end;
    }
    current = subFolder;
    folderName = wcstok(NULL, L"/", &buffer);
  }
  //found
  if (current->subFolders == NULL)
  {
    path_exclusion_folder *parent = current->parent;
    removeSubfolder(current);
    while (parent != NULL && parent->subFoldersLen == 0 && parent->isLastFolder != 1)
    {
      path_exclusion_folder *tmp = parent->parent;
      removeSubfolder(parent);
      parent = tmp;
    }
  }
  else
  {
    current->isLastFolder = 0;
  }
end:
  pthread_mutex_unlock(&pathExclusionMutex);
  if (tmpPath != NULL)
  {
    free(tmpPath);
  }
  return ret;
}

static int showExclusions(path_exclusion_folder *current)
{
  unsigned int i = 0;
  for (i = 0; i < current->layer; i++)
  {
    printf("#");
  }
  printf("[%ls]", current->name);
  if (current->isLastFolder == 1)
  {
    printf(" *");
  }
  printf("\n");
  path_exclusion_folder *subfolder = current->subFolders;
  while (subfolder != NULL)
  {
    path_exclusion_folder *tmp = subfolder;
    subfolder = subfolder->next;
    showExclusions(tmp);
  }
  return 0;
}

int cleanSubfolders(path_exclusion_folder *current)
{
  path_exclusion_folder *subfolder = current->subFolders;
  while (subfolder != NULL)
  {
    path_exclusion_folder *tmp = subfolder->next;
    cleanSubfolders(subfolder);
    subfolder = tmp;
  }
  current->subFolders = NULL;
  // printf("free [%ls]\n", current->name);
  if (current->name != NULL)
  {
    free(current->name);
  }
  free(current);
  return 0;
}

int initExclusions()
{
  exclusionsRoot = (path_exclusion_folder *)calloc(1, sizeof(path_exclusion_folder));
  if (exclusionsRoot == NULL)
  {
    printf("initExclusions failed\n");
    return -1;
  }
  pthread_mutex_init(&pathExclusionMutex, NULL);
  printf("initExclusions success\n");
  return 0;
}

int uninitExclusions()
{
  if (exclusionsRoot == NULL)
  {
    return -1;
  }
  pthread_mutex_lock(&pathExclusionMutex);
  cleanSubfolders(exclusionsRoot);
  exclusionsRoot = NULL;
  pthread_mutex_unlock(&pathExclusionMutex);
  pthread_mutex_destroy(&pathExclusionMutex);
  return 0;
}

int cleanExclusions()
{
  if (exclusionsRoot == NULL)
  {
    return -1;
  }
  pthread_mutex_lock(&pathExclusionMutex);
  path_exclusion_folder *subfolder = exclusionsRoot->subFolders;
  while (subfolder != NULL)
  {
    path_exclusion_folder *tmp = subfolder->next;
    cleanSubfolders(subfolder);
    subfolder = tmp;
  }
  exclusionsRoot->subFolders = NULL;
  pthread_mutex_unlock(&pathExclusionMutex);
  return 0;
}

int test()
{
  wchar_t input[100] = L"/A/bird/came/down/the/";
  wchar_t input2[100] = L"/B/bird/came/down/the/";
  wchar_t input3[100] = L"/A/dog/came/down/the/下划线/";
  wchar_t input4[100] = L"/B/";

  wchar_t test1[100] = L"/A/bird/came/down/the/road/";
  wchar_t test2[100] = L"/A/dog/came/down/the/下划线/12314/123123";
  wchar_t test3[100] = L"/B/bird/came/down/the/road111/";
  wchar_t test4[100] = L"/B/bird/came/down/the/road111/12312431/123123";
  wchar_t test5[100] = L"/B/dog/came/down/the/road111/";

  initExclusions();
  addPathToExclusions(input);
  showExclusions(exclusionsRoot);
  printf("isPathInExclustions[%ls] %d\n", test1, isPathInExclustions(test1));
  assert(isPathInExclustions(test1) == 0);

  removePathFromExclusions(input);
  addPathToExclusions(input2);
  showExclusions(exclusionsRoot);
  printf("isPathInExclustions[%ls] %d\n", test1, isPathInExclustions(test1));
  assert(isPathInExclustions(test1) == -1);

  addPathToExclusions(input3);
  showExclusions(exclusionsRoot);
  printf("isPathInExclustions[%s] %d\n", "下划线", isPathInExclustions(test2));
  assert(isPathInExclustions(test2) == 0);

  removePathFromExclusions(input3);
  addPathToExclusions(input2);
  addPathToExclusions(input);
  showExclusions(exclusionsRoot);
  printf("isPathInExclustions[%ls] %d\n", test3, isPathInExclustions(test3));
  printf("isPathInExclustions[%ls] %d\n", test4, isPathInExclustions(test4));
  printf("isPathInExclustions[%ls] %d\n", test1, isPathInExclustions(test1));
  printf("isPathInExclustions[%ls] %d\n", test5, isPathInExclustions(test5));
  assert(isPathInExclustions(test3) == 0);
  assert(isPathInExclustions(test4) == 0);
  assert(isPathInExclustions(test1) == 0);
  assert(isPathInExclustions(test5) == -1);

  addPathToExclusions(input4);
  showExclusions(exclusionsRoot);
  printf("isPathInExclustions[%ls] %d\n", test5, isPathInExclustions(test5));
  assert(isPathInExclustions(test5) == 0);

  cleanExclusions();
  showExclusions(exclusionsRoot);
  addPathToExclusions(input);
  showExclusions(exclusionsRoot);
  uninitExclusions();
  return 0;
}

// int main()
// {
//   test();
// }
