/**
@file
@brief    interceptor path exclusions.
@details  Copyright (c) 2020 Acronis
@author   Bruce Wang (Bruce.Wang@acronis.com)
*/

typedef struct _path_exclusion_folder
{
  wchar_t *name;
  unsigned int nameLen;
  struct _path_exclusion_folder *subFolders;
  struct _path_exclusion_folder *parent;
  struct _path_exclusion_folder *next;
  struct _path_exclusion_folder *prev;
  unsigned int subFoldersLen;
  unsigned int layer;
  unsigned char isLastFolder;
} path_exclusion_folder;

int initExclusions();
int uninitExclusions();
int cleanExclusions();
int addPathToExclusions(const wchar_t *path);
int isPathInExclustions(const wchar_t *path);
int removePathFromExclusions(const wchar_t *path);
