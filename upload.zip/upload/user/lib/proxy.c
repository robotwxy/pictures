/**
@file
@brief    interceptor proxy implementation.
@details  Copyright (c) 2020 Acronis
@author   Bruce Wang (Bruce.Wang@acronis.com)
*/

#include "common.h"
#include "interceptor.h"
#include "ioctl.h"
#include "interface.h"
#include "proxy.h"
#include <pthread.h>
#include <errno.h>
#include <unistd.h>
#include <arpa/inet.h>
#include "log.h"

// #define DEFAULT_PROXY_PORT 23333
#define DEFAULT_PROXY_IP "127.0.0.1"
#define MAX_LISTEN_QUEUE 512
#define REDIRECT_SOCK_MARK 20130508 //user kernel must be same
// #define CLOSE_SOCK_MARK 20130509

#define LISTEN_SOCKET_IDLE 0
#define LISTEN_SOCKET_STOP 1

static void *proxyWaitForClient(void *arg);
static int initListenSocket(uint32_t listenIpAddr, unsigned short *port);
static void *handleConnection(void *arg);
static void connectionLoop(struct threadArg *tArg, struct ioctl_data *ioctlNatDest);
static int connectRemote(struct sockaddr_in *natDest, struct sockaddr_in *localBindAddr, struct threadArg *tArg);
static connectionThreadNode *addConnectionThread(connectionThreadContainer *container);
static int removeConnectionThread(connectionThreadContainer *container, connectionThreadNode **node);
static int notifyConnectionThreadsClose(connectionThreadContainer *container);

static unsigned int thread_count;
static int listenSock;
static unsigned char listenSockState = LISTEN_SOCKET_IDLE;
static pthread_t listenThread = 0;
//TODO
static connectionThreadContainer threadContainer;
static pthread_mutex_t connThreadMutex = PTHREAD_MUTEX_INITIALIZER;
static unsigned char proxyInitFlag = 0;
int proxyThreadInitialize(const HttpInitParams *params)
{
  uint32_t listenIpAddr;
  unsigned short listenPort;
  //get proxy listen ip and port
  if (params->listenIpAddr == 0 || params->listenPort == 0)
  {
    listenIpAddr = inet_addr(DEFAULT_PROXY_IP);
    //listenPort = DEFAULT_PROXY_PORT;
  }
  else
  {
    listenIpAddr = params->listenIpAddr;
    // listenPort = params->listenPort;
  }
  //get max connection threads size
  memset(&threadContainer, 0, sizeof(connectionThreadContainer));
  if (params->maxConnectionThreads == 0)
  {
    threadContainer.maxSize = DEFAULT_MAX_CONNECTION_THREADS;
  }
  else
  {
    threadContainer.maxSize = params->maxConnectionThreads;
  }
  pthread_mutex_init(&connThreadMutex, NULL);
  thread_count = 0;
  //get listen socket
  listenSock = initListenSocket(listenIpAddr, &listenPort);
  if (listenSock < 0)
  {
    COMMON_ERROR_PRINT("initListenSocket failed, errno: %d", errno);
    return -1;
  }

  PROXY_DEBUG_PRINT("Server listening..");
  //register proxy info into kernel
  if (registerKernel(listenIpAddr, listenPort, params) != 0)
  {
    COMMON_ERROR_PRINT("register Kernel failed");
    return -1;
  }
  //start listen thread
  struct threadArg *arg = (struct threadArg *)malloc(sizeof(struct threadArg));
  if (arg == NULL)
  {
    COMMON_ERROR_PRINT("malloc failed, errno: %d", errno);
    return -1;
  }
  arg->listenSock = listenSock;
  proxyInitFlag = 1;
  return pthread_create(&listenThread, NULL, proxyWaitForClient, arg);
}

int proxyStart()
{
  return ioctlStartKernel(getpid());
}

int proxyStop()
{
  return ioctlStopKernel(getpid());
}

int proxyUninitialize()
{
  int ret;
  listenSockState = LISTEN_SOCKET_STOP;
  shutdown(listenSock, SHUT_RDWR);
  ret = unregisterKernel();
  // wait for all threads return
  proxyInitFlag = 0;
  notifyConnectionThreadsClose(&threadContainer);

  pthread_mutex_destroy(&connThreadMutex);

  PROXY_DEBUG_PRINT("wait for listenThread return");
  ret = pthread_join(listenThread, NULL);
  listenSockState = LISTEN_SOCKET_IDLE;
  return ret;
}

static int initListenSocket(uint32_t listenIpAddr, unsigned short *port)
{
  int optval = 1;
  struct sockaddr_in listenAddr;
  int listenSocket = socket(AF_INET, SOCK_STREAM, 0);
  if (listenSocket == -1)
  {
    COMMON_ERROR_PRINT("socket creation failed, errno: %d", errno);
    return -1;
  }

  if (setsockopt(listenSocket, SOL_SOCKET, SO_REUSEADDR, &optval, sizeof(optval)) < 0)
  {
    COMMON_ERROR_PRINT("Cannot set listen socket option, errno: %d", errno);
    return -1;
  }

  memset(&listenAddr, 0, sizeof(listenAddr));
  listenAddr.sin_family = AF_INET;
  listenAddr.sin_addr.s_addr = listenIpAddr;
  listenAddr.sin_port = 0;

  if ((bind(listenSocket, (struct sockaddr *)&listenAddr, sizeof(listenAddr))) != 0)
  {
    COMMON_ERROR_PRINT("socket bind failed, errno: %d", errno);
    return -1;
  }

  struct sockaddr_in bindAddr;
  socklen_t addrLen = sizeof(struct sockaddr_in);
  getsockname(listenSocket, (struct sockaddr *)&bindAddr, &addrLen);
  *port = ntohs(bindAddr.sin_port);

  if ((listen(listenSocket, MAX_LISTEN_QUEUE)) != 0)
  {
    COMMON_ERROR_PRINT("Listen failed, errno: %d", errno);
    return -1;
  }
  return listenSocket;
}

static void *proxyWaitForClient(void *data)
{
  int listenSock;
  struct threadArg *arg;
  if (data == NULL)
  {
    return NULL;
  }
  arg = (struct threadArg *)data;
  listenSock = arg->listenSock;
  free(data);
  PROXY_DEBUG_PRINT("wait for client...");
  while (1)
  {
    pthread_t thread;
    struct threadArg *arg = NULL;
    struct sockaddr_in clientAddr;
    socklen_t clientSize = sizeof(clientAddr);
    int client_socket = accept(listenSock, (struct sockaddr *)&clientAddr, &clientSize);
    if (client_socket < 0)
    {
      if ((listenSockState == LISTEN_SOCKET_STOP))
      {
        PROXY_DEBUG_PRINT("proxy stop listen");
        break;
      }
      COMMON_ERROR_PRINT("Cannot accept client connection, errno:%d", errno);
      continue;
    }

    arg = (struct threadArg *)malloc(sizeof(struct threadArg));
    if (arg == NULL)
    {
      COMMON_ERROR_PRINT("malloc failed, errno: %d", errno);
      close(client_socket);
      continue;
    }

    connectionThreadNode *node = addConnectionThread(&threadContainer);
    if (node == NULL)
    {
      COMMON_ERROR_PRINT("connThread==NULL");
      close(client_socket);
      continue;
    }
    arg->clientSock = client_socket;
    arg->ClientAddr = clientAddr;
    arg->connectionThread = node;
    pthread_create(&thread, NULL, handleConnection, (void *)arg);
  }
  close(listenSock);
  pthread_exit(NULL);
  return NULL;
}

static void *handleConnection(void *arg)
{
  struct threadArg tArg;
  // thread_count++;
  //PROXY_DEBUG_PRINT("current threads: %u", thread_count);
  if (arg == NULL)
  {
    COMMON_ERROR_PRINT("thread arg is NULL");
    goto end;
  }
  memcpy(&tArg, arg, sizeof(struct threadArg));
  free(arg);

  tArg.connectionThread->clientSock = tArg.clientSock;
  tArg.connectionThread->thread = pthread_self();

  //get the nat dest address by ioctl
  int ret;
  struct ioctl_data ioctlNatDest;
  ret = ioctlGetNatDest(&ioctlNatDest, &(tArg.ClientAddr));
  if (ret < 0)
  {
    goto end;
  }

  connectionLoop(&tArg, &ioctlNatDest);
end:
  shutdown(tArg.clientSock, SHUT_RDWR);
  close(tArg.clientSock);
  pthread_detach(pthread_self());
  // PROXY_DEBUG_PRINT("thread[%d] detach", tArg.connectionThread->index);
  removeConnectionThread(&threadContainer, &(tArg.connectionThread));
  // thread_count--;
  // PROXY_DEBUG_PRINT("current threads: %u", thread_count);
  pthread_exit(NULL);
}

static void connectionLoop(struct threadArg *tArg, struct ioctl_data *ioctlNatDest)
{
  struct sockaddr_in natDest, localBindAddr;
  int remoteSocket;
  memset(&natDest, 0, sizeof(natDest));
  memset(&localBindAddr, 0, sizeof(localBindAddr));
  natDest.sin_family = AF_INET;
  natDest.sin_addr.s_addr = ioctlNatDest->dip;
  natDest.sin_port = htons(ioctlNatDest->dport);
  remoteSocket = connectRemote(&natDest, &localBindAddr, tArg);
  if (remoteSocket > 0)
  {
    interceptor(tArg->clientSock, remoteSocket, &(tArg->ClientAddr), &natDest, &localBindAddr);
  }
  if (remoteSocket > 0)
  {
    shutdown(remoteSocket, SHUT_RDWR);
    close(remoteSocket);
  }
}

static int connectRemote(struct sockaddr_in *natDest, struct sockaddr_in *localBindAddr, struct threadArg *tArg)
{
  int optval = 1;
  socklen_t bindAddrLen;
  struct sockaddr_in remoteAddr, localAddr;
  int remoteSocket;
  int mark = REDIRECT_SOCK_MARK;
  if ((remoteSocket = socket(AF_INET, SOCK_STREAM, 0)) < 0)
  {
    COMMON_ERROR_PRINT("Cannot create remote socket, errno: %d", errno);
    return -1;
  }

  if (setsockopt(remoteSocket, SOL_SOCKET, SO_REUSEADDR, &optval, sizeof(optval)) < 0)
  {
    COMMON_ERROR_PRINT("Cannot set listen socket option, errno: %d", errno);
    return -1;
  }

  if (setsockopt(remoteSocket, SOL_SOCKET, SO_MARK, &mark, sizeof(mark)) < 0)
  {
    COMMON_ERROR_PRINT("Cannot set listen socket mark option, errno: %d", errno);
    return -1;
  }

  memset(&localAddr, 0, sizeof(struct sockaddr_in));
  localAddr.sin_family = AF_INET;
  localAddr.sin_addr.s_addr = htonl(INADDR_ANY);
  localAddr.sin_port = htons(0);

  if ((bind(remoteSocket, (struct sockaddr *)&localAddr, sizeof(localAddr))) != 0)
  {
    COMMON_ERROR_PRINT("remote socket bind failed, errno: %d", errno);
    return -1;
  }
  bindAddrLen = sizeof(struct sockaddr_in);
  getsockname(remoteSocket, (struct sockaddr *)localBindAddr, &bindAddrLen);

  tArg->connectionThread->serverSock = remoteSocket;

  memcpy(&remoteAddr, natDest, sizeof(struct sockaddr_in));
  remoteAddr.sin_family = AF_INET;
  if (connect(remoteSocket, (struct sockaddr *)&remoteAddr, sizeof(remoteAddr)) < 0)
  {
    COMMON_ERROR_PRINT("Cannot connect to remote host, errno: %d", errno);
    return -1;
  }
  return remoteSocket;
}

static connectionThreadNode *addConnectionThread(connectionThreadContainer *container)
{
  connectionThreadNode *node = NULL;
  if (proxyInitFlag == 0)
  {
    return NULL;
  }
  pthread_mutex_lock(&connThreadMutex);
  node = (connectionThreadNode *)calloc(1, sizeof(connectionThreadNode));
  if (node == NULL)
  {
    goto end;
  }
  node->index = container->len + 1;
  if (container->head != NULL)
  {
    container->head->prev = node;
    node->next = container->head;
  }
  container->head = node;
  container->len++;
  log_info("addConnectionThread %d\n", container->len);
end:
  pthread_mutex_unlock(&connThreadMutex);
  return node;
}

static int removeConnectionThread(connectionThreadContainer *container, connectionThreadNode **node)
{
  int ret = 0;
  connectionThreadNode *tmpNode = *node;
  pthread_mutex_lock(&connThreadMutex);
  if (tmpNode == NULL)
  {
    goto end;
  }
  if (tmpNode->prev == NULL)
  {
    if (container->head != tmpNode)
    {
      COMMON_ERROR_PRINT("removeConnectionThread error");
    }
    container->head = tmpNode->next;
    if (tmpNode->next != NULL)
    {
      tmpNode->next->prev = NULL;
    }
  }
  else
  {
    tmpNode->prev->next = tmpNode->next;
    if (tmpNode->next != NULL)
    {
      tmpNode->next->prev = tmpNode->prev;
    }
  }
  free(tmpNode);
  *node = NULL;
  container->len--;
  log_info("removeConnectionThread %d\n", container->len);
end:
  pthread_mutex_unlock(&connThreadMutex);
  return ret;
}

static int notifyConnectionThreadsClose(connectionThreadContainer *container)
{
  connectionThreadNode *node = NULL;
  node = container->head;
  while (node != NULL)
  {
    // printf("travel node %d %d %d\n", node->index, node->clientSock, node->serverSock);
    connectionThreadNode *next = node->next;
    int serverSock = node->serverSock;
    int clientSock = node->clientSock;
    shutdown(serverSock, SHUT_RDWR);
    shutdown(clientSock, SHUT_RDWR);
    node = next;
  }
  while (container->len != 0)
  {
  }
  sleep(1);
  return 0;
}
