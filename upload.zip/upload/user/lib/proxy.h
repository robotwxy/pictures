/**
@file
@brief    interceptor proxy implementation.
@details  Copyright (c) 2020 Acronis
@author   Bruce Wang (Bruce.Wang@acronis.com)
*/

#ifndef HTTP_PROXY_H
#define HTTP_PROXY_H

#include <arpa/inet.h>
//#define PROXY_DEBUG
#ifdef PROXY_DEBUG
#define PROXY_DEBUG_PRINT log_debug
#else
#define PROXY_DEBUG_PRINT(...) /*...*/
#endif

typedef struct _connectionThreadNode
{
  unsigned short index;
  int clientSock;
  int serverSock;
  pthread_t thread;
  unsigned char threadJoinFlag;
  struct _connectionThreadNode *next;
  struct _connectionThreadNode *prev;
} connectionThreadNode;

typedef struct _connectionThreadContainer
{
  unsigned int maxSize;
  unsigned int len;
  struct _connectionThreadNode *head;
} connectionThreadContainer;

struct threadArg
{
  int clientSock;
  int listenSock;
  struct sockaddr_in ClientAddr;
  connectionThreadNode * connectionThread;
};

int proxyThreadInitialize(const HttpInitParams *params);
int proxyUninitialize();
int proxyStart();
int proxyStop();

#endif
