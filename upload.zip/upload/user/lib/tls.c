/**
@file
@brief    get the SSL domain name from TLS packet.
@details  Copyright (c) 2020 Acronis
@author   Bruce Wang (Bruce.Wang@acronis.com)
*/

#include <stdio.h>
#include <stdlib.h> /* malloc() */
#include <stdint.h>
#include <string.h> /* strncpy() */
#include <sys/socket.h>
#include <sys/types.h>
#include "tls.h"

#define SERVER_NAME_LEN 256
#define TLS_HEADER_LEN 5
#define TLS_HANDSHAKE_CONTENT_TYPE 0x16
#define TLS_HANDSHAKE_TYPE_CLIENT_HELLO 0x01

#ifndef MIN
#define MIN(X, Y) ((X) < (Y) ? (X) : (Y))
#endif

static int tls_parse_extensions(const uint8_t *, size_t, char **);
static int tls_parse_server_name_extension(const uint8_t *, size_t, char **);
/*	Parse a TLS packet and return a malloced hostname 
*		return:
*		>=0: the length of hostname
*		-1: error
*		-2: not found
*/
int parse_tls_header(const uint8_t *packet, size_t data_len, char **hostname)
{
	uint8_t tls_content_type;
	uint8_t tls_version_major;
	uint8_t tls_version_minor;
	size_t pos = TLS_HEADER_LEN;
	size_t len;

	if (hostname == NULL)
	{
		return -1;
	}

	//mininum TLS header
	if (data_len < TLS_HEADER_LEN)
	{
		return -1;
	}

	if (packet[0] & 0x80 && packet[2] == 1)
	{
		return -1;
	}

	tls_content_type = packet[0];
	if (tls_content_type != TLS_HANDSHAKE_CONTENT_TYPE)
	{
		return -1;
	}

	tls_version_major = packet[1];
	tls_version_minor = packet[2];
	if (tls_version_major < 3)
	{
		return -1;
	}

	len = ((size_t)packet[3] << 8) + (size_t)packet[4] + TLS_HEADER_LEN;
	data_len = MIN(data_len, len);

	if (data_len < len)
	{
		return -1;
	}

	if (pos + 1 > data_len)
	{
		return -1;
	}
	if (packet[pos] != TLS_HANDSHAKE_TYPE_CLIENT_HELLO)
	{
		return -1;
	}

	//Skip fixed length records
	pos += 38;

	if (pos + 1 > data_len)
	{
		return -1;
	}
	len = (size_t)packet[pos];
	pos += 1 + len;

	//Cipher Suites
	if (pos + 2 > data_len)
	{
		return -1;
	}
	len = ((size_t)packet[pos] << 8) + (size_t)packet[pos + 1];
	pos += 2 + len;

	//Compression Methods
	if (pos + 1 > data_len)
	{
		return -1;
	}
	len = (size_t)packet[pos];
	pos += 1 + len;

	if (pos == data_len && tls_version_major == 3 && tls_version_minor == 0)
	{
		return -1;
	}

	//Extensions
	if (pos + 2 > data_len)
	{
		return -1;
	}
	len = ((size_t)packet[pos] << 8) + (size_t)packet[pos + 1];
	pos += 2;

	if (pos + len > data_len)
	{
		return -1;
	}
	return tls_parse_extensions(packet + pos, len, hostname);
}

static int tls_parse_extensions(const uint8_t *packet, size_t data_len, char **hostname)
{
	size_t pos = 0;
	size_t len;

	//Parse each 4 bytes for the extension header
	while (pos + 4 <= data_len)
	{
		//Extension Length
		len = ((size_t)packet[pos + 2] << 8) + (size_t)packet[pos + 3];

		//Check if it's a server name
		if (packet[pos] == 0x00 && packet[pos + 1] == 0x00)
		{
			if (pos + 4 + len > data_len)
			{
				return -1;
			}
			return tls_parse_server_name_extension(packet + pos + 4, len, hostname);
		}
		pos += 4 + len; /* Advance to the next extension header */
	}
	/* Check we ended where we expected to */
	if (pos != data_len)
	{
		return -1;
	}

	return -2;
}

static int tls_parse_server_name_extension(const uint8_t *packet, size_t data_len, char **hostname)
{
	//skip server name list length
	size_t pos = 2;
	size_t len;

	while (pos + 3 < data_len)
	{
		len = ((size_t)packet[pos + 1] << 8) + (size_t)packet[pos + 2];

		if (pos + 3 + len > data_len)
		{
			return -1;
		}
		//name type
		switch (packet[pos])
		{
		case 0x00: //host_name
			*hostname = (char *)malloc(len + 1);
			if (*hostname == NULL)
			{
				return -1;
			}
			memcpy(*hostname, packet + pos + 3, len);
			(*hostname)[len] = 0;

			return len;
		default:
			break;
		}
		pos += 3 + len;
	}
	/* Check we ended where we expected to */
	if (pos != data_len)
	{
		return -1;
	}

	return -2;
}
