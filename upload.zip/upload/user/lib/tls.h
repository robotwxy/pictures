/**
@file
@brief    get the SSL domain name from TLS packet.
@details  Copyright (c) 2020 Acronis
@author   Bruce Wang (Bruce.Wang@acronis.com)
*/

#ifndef TLS_H
#define TLS_H

#include <sys/types.h>
#include <stdint.h>

int parse_tls_header(const uint8_t *data, size_t data_len, char **hostname);

#endif
