/**
@file
@brief    extract the content from gzip format.
@details  Copyright (c) 2020 Acronis
@author   Bruce Wang (Bruce.Wang@acronis.com)
*/

#include "common.h"
#include <zlib.h>
int chunkInflate(const char *src, int srcLen, const char *dst, int dstLen, unsigned long *totalOut)
{
  z_stream strm;

  *totalOut = 0;
  strm.zalloc = NULL;
  strm.zfree = NULL;
  strm.opaque = NULL;

  strm.avail_in = srcLen;
  strm.avail_out = dstLen;
  strm.next_in = (Bytef *)src;
  strm.next_out = (Bytef *)dst;

  int err = -1;
  err = inflateInit2(&strm, MAX_WBITS + 16);
  if (err == Z_OK)
  {
    err = inflate(&strm, Z_FINISH);
    if (err == Z_STREAM_END)
    {
    }
    else
    {
      inflateEnd(&strm);
      return err;
    }
  }
  else
  {
    inflateEnd(&strm);
    return err;
  }
  inflateEnd(&strm);
  *totalOut = (unsigned long)strm.total_out;
  return err;
}
