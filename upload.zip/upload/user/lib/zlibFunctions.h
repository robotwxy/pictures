/**
@file
@brief    extract the content from gzip format.
@details  Copyright (c) 2020 Acronis
@author   Bruce Wang (Bruce.Wang@acronis.com)
*/

#ifndef HTTP_ZLIBFUNCTIONS_H
#define HTTP_ZLIBFUNCTIONS_H

int chunkInflate(const char *src, int srcLen, const char *dst, int dstLen, unsigned long *totalOut);

#endif
