#include <pthread.h>
#include <errno.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <stdlib.h>
#include <string.h>
#include <gtest/gtest.h>
#include <curl/curl.h>

#include "log.h"
#include "interface.h"

#define TEST_PORT 23336
#define TEST_BUFFER_SIZE 65535
#define LARGE_BUFFER_SIZE 10 * 1024 * 1024 //10 * 1024 * 1024

typedef struct _tcpBuffer
{
	char buffer[LARGE_BUFFER_SIZE];
	size_t size;
} tcpBuffer;

static int listenSocket;
static int initListenSocket(unsigned short port)
{
	int optval = 1;
	struct sockaddr_in listenAddr;
	listenSocket = socket(AF_INET, SOCK_STREAM, 0);
	if (listenSocket == -1)
	{
		log_debug("socket creation failed, errno: %d", errno);
		return -1;
	}

	if (setsockopt(listenSocket, SOL_SOCKET, SO_REUSEADDR, &optval, sizeof(optval)) < 0)
	{
		log_debug("Cannot set listen socket option, errno: %d", errno);
		return -1;
	}

	memset(&listenAddr, 0, sizeof(listenAddr));
	listenAddr.sin_family = AF_INET;
	listenAddr.sin_addr.s_addr = INADDR_ANY;
	listenAddr.sin_port = htons(port);

	if ((bind(listenSocket, (struct sockaddr *)&listenAddr, sizeof(listenAddr))) != 0)
	{
		log_debug("socket bind failed, errno: %d", errno);
		return -1;
	}

	if ((listen(listenSocket, 10)) != 0)
	{
		log_debug("Listen failed, errno: %d", errno);
		return -1;
	}
	return listenSocket;
}

static char response[LARGE_BUFFER_SIZE] = {0};
static char defaultResponseBody[] = "i am http response";
static char *responseBody = NULL;
static char responseStartline[] = "HTTP/1.0 200 OK\r\n";
static char responseHost[] = "Host: 10.165.12.20\r\n";
static char responseHeader1[] = "header1: value1\r\n";
static char responseHeader2[] = "header2: value2\r\n";
static char responseHeader3[] = "Content-Type: text/html\r\n";
static char ResponseHeader4[] = "Content-Length: ";
static char defaultHeader[] = "defaultHeader: defaultHeader";
static char *customHeader = NULL;
static char serverBuffer[LARGE_BUFFER_SIZE];
static char *requestBody = NULL;
static void (*serverRecv)(ssize_t received, char *recvBuffer) = NULL;
static int client_socket;

static void _listenThreadFunc()
{
	struct sockaddr_in clientAddr;
	socklen_t clientSize = sizeof(clientAddr);
	client_socket = accept(listenSocket, (struct sockaddr *)&clientAddr, &clientSize);
	ASSERT_NE(client_socket, 0);
	memset(serverBuffer, 0, LARGE_BUFFER_SIZE);
	struct timeval tv;
	if (requestBody == NULL || strlen(requestBody) < 4096)
	{
		tv.tv_sec = 0;
		tv.tv_usec = 700000; //0.7s
	}
	else
	{
		tv.tv_sec = 3;
		tv.tv_usec = 0;
	}
	setsockopt(client_socket, SOL_SOCKET, SO_RCVTIMEO, (const char *)&tv, sizeof(tv));
	ssize_t received = 0;
	ssize_t n = 0;
	do
	{
		n = recv(client_socket, serverBuffer + received, sizeof(serverBuffer) - received, 0);
		received += n;
	} while (n > 0);

	if (serverRecv != NULL)
	{
		serverRecv(received, serverBuffer);
	}
	serverRecv = NULL;

	if (responseBody == NULL)
	{
		responseBody = defaultResponseBody;
	}
	if (customHeader == NULL)
	{
		customHeader = defaultHeader;
		sprintf(response, "%s%s%s%lu\r\n%s%s%s%s\r\n\r\n%s\r\n",
						responseStartline, responseHost, ResponseHeader4, strlen(responseBody), responseHeader1, responseHeader2, responseHeader3, customHeader, responseBody);
	}
	else
	{
		sprintf(response, "%s%s%s%s%s%s\r\n\r\n%s\r\n",
						responseStartline, responseHost, responseHeader1, responseHeader2, responseHeader3, customHeader, responseBody);
	}

	send(client_socket, response, strlen(response), 0);
	shutdown(client_socket, SHUT_RDWR);
	close(client_socket);
	responseBody = NULL;
	customHeader = NULL;
}

static void *listenThreadFunc(void *data)
{
	_listenThreadFunc();
	return NULL;
}

static size_t curlCallback(char *buffer, size_t size, size_t nitems, void *userdata)
{
	tcpBuffer *buff = (tcpBuffer *)userdata;
	memcpy(buff->buffer + buff->size, buffer, size * nitems);
	buff->size += size * nitems;
	buff->buffer[buff->size] = 0;
	return nitems * size;
}

static char testRequestHeader[] = "testRequestHeaderKey: testRequestHeaderValue";
static char testRequestHeaderKey[] = "testRequestHeaderKey";
static char testRequestHeaderValue[] = "testRequestHeaderValue";
static char hostHeader[] = "host: example_domain:9999";
static char contentType[] = "content-type: text/html";
static char defaultRequestBody[] = "default body";
static void (*clientRecv)(tcpBuffer *bodyBuffer, tcpBuffer *headerBuffer) = NULL;
static char *curlUrl = NULL;

#define SERVER_URL "http://127.0.0.1:23336"

static void _sendRequestThreadFunc()
{
	CURL *curl;
	struct curl_slist *list = NULL;
	tcpBuffer *headerBuffer = (tcpBuffer *)malloc(sizeof(tcpBuffer));
	tcpBuffer *bodyBuffer = (tcpBuffer *)malloc(sizeof(tcpBuffer));
	ASSERT_NE((long)headerBuffer, NULL);
	ASSERT_NE((long)bodyBuffer, NULL);
	memset(headerBuffer, 0, sizeof(tcpBuffer));
	memset(bodyBuffer, 0, sizeof(tcpBuffer));
	if (requestBody == NULL)
	{
		requestBody = defaultRequestBody;
	}
	curl = curl_easy_init();
	if (curl)
	{
		if (curlUrl == NULL)
		{
			curl_easy_setopt(curl, CURLOPT_URL, SERVER_URL);
		}
		else
		{
			curl_easy_setopt(curl, CURLOPT_URL, curlUrl);
		}
		list = curl_slist_append(list, hostHeader);
		list = curl_slist_append(list, contentType);
		list = curl_slist_append(list, testRequestHeader);
		curl_easy_setopt(curl, CURLOPT_HTTPHEADER, list);
		curl_easy_setopt(curl, CURLOPT_POSTFIELDS, requestBody);
		curl_easy_setopt(curl, CURLOPT_HEADERFUNCTION, curlCallback);
		curl_easy_setopt(curl, CURLOPT_HEADERDATA, headerBuffer);
		curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, curlCallback);
		curl_easy_setopt(curl, CURLOPT_WRITEDATA, bodyBuffer);

		curl_easy_perform(curl);

		if (clientRecv != NULL)
		{
			clientRecv(bodyBuffer, headerBuffer);
		}
		clientRecv = NULL;
		//log_debug("response body[%s]", bodyBuffer.buffer);

		curl_slist_free_all(list);
		curl_easy_cleanup(curl);
	}
	requestBody = NULL;
	curlUrl = NULL;
	free(headerBuffer);
	free(bodyBuffer);
}

static void *sendRequestThreadFunc(void *data)
{
	_sendRequestThreadFunc();
	return NULL;
}

unsigned short ports[] = {23336, 443};
// char cloudServer[] = "http://47.88.173.175:5000/checkurl";
static void initSDK(HttpCbks *cbks)
{
	HttpInitParams params = {0};
	// params.cloudScanServer = cloudServer;
	params.cloudScanEnable = 1;
	params.cloudScanForSSLEnable = 1;
	params.logEnable = 1;
	params.remoteHttpPorts = ports;
	params.remoteHttpPortsCount = sizeof(ports) / sizeof(unsigned short);
	Http_Initialize(&params);
	Http_SetCallbacks(cbks);
	Http_Start();
}

static void uninitSDK()
{
	Http_Stop();
	Http_Uninitialize();
}

static void runThreads()
{
	pthread_t listenThread;
	pthread_t connectThread;
	pthread_create(&listenThread, NULL, listenThreadFunc, NULL);
	pthread_create(&connectThread, NULL, sendRequestThreadFunc, NULL);
	pthread_join(listenThread, NULL);
	pthread_join(connectThread, NULL);
}

static void commonRequestFunctions(HttpHandle *message, const RequestFunctions *request)
{
	//GetId
	ASSERT_TRUE(request->GetId(message) > 0);
	//GetHeader
	ASSERT_TRUE(request->GetHeader(message, testRequestHeaderKey) != NULL);
	ASSERT_STREQ(request->GetHeader(message, testRequestHeaderKey), testRequestHeaderValue);
	ASSERT_TRUE(request->GetHeader(message, "invalid_header") == NULL);
	//SetHeader
	request->SetHeader(message, "new header", "new value");
	ASSERT_STREQ(request->GetHeader(message, "new header"), "new value");
	request->SetHeader(message, testRequestHeaderKey, "new value");
	ASSERT_STREQ(request->GetHeader(message, testRequestHeaderKey), "new value");
	//DeleteHeader
	request->DeleteHeader(message, "new header");
	ASSERT_TRUE(request->GetHeader(message, "new header") == NULL);
	//DeleteAllHeaders
	char contentLength[64] = {0};
	strcpy(contentLength, request->GetHeader(message, "Content-Length"));
	request->DeleteAllHeaders(message);
	request->SetHeader(message, testRequestHeaderKey, "new value");
	request->SetHeader(message, "Content-Length", contentLength);
	//GetHeadersList
	char **headers = NULL;
	unsigned long size = 0;
	request->GetHeadersList(message, &(headers), &size);
	ASSERT_TRUE(size == 2);
	ASSERT_TRUE(headers != NULL);
	ASSERT_STREQ(headers[0], "testRequestHeaderKey: new value");
	request->FreeHeadersList(message, headers, size);
	//Method
	ASSERT_STREQ(request->Method(message), "POST");
	//Url
	ASSERT_STREQ(request->Url(message), "example_domain");
	//GetHttpVersion
	ASSERT_STREQ(request->GetHttpVersion(message), "HTTP/1.1");
}

static void commonResponseFunctions(HttpHandle *message, const ResponseFunctions *response)
{
	//GetId
	ASSERT_TRUE(response->GetId(message) > 0);
	//GetHeader
	//header1: value1
	ASSERT_TRUE(response->GetHeader(message, "header1") != NULL);
	ASSERT_STREQ(response->GetHeader(message, "header1"), "value1");
	ASSERT_TRUE(response->GetHeader(message, "invalid_header") == NULL);
	//SetHeader
	response->SetHeader(message, "new header", "new value");
	ASSERT_STREQ(response->GetHeader(message, "new header"), "new value");
	response->SetHeader(message, "header1", "new value");
	ASSERT_STREQ(response->GetHeader(message, "header1"), "new value");
	//DeleteHeader
	response->DeleteHeader(message, "new header");
	ASSERT_TRUE(response->GetHeader(message, "new header") == NULL);
	//DeleteAllHeaders
	char contentLength[64] = {0};
	strcpy(contentLength, response->GetHeader(message, "Content-Length"));
	response->DeleteAllHeaders(message);
	response->SetHeader(message, "Content-Length", contentLength);
	ASSERT_TRUE(response->GetHeader(message, "Content-Type") == NULL);
	//GetHeadersList
	char **headers = NULL;
	unsigned long size = 0;
	response->GetHeadersList(message, &(headers), &size);
	ASSERT_TRUE(size > 0);
	ASSERT_TRUE(headers != NULL);
	response->FreeHeadersList(message, headers, size);
	//StatusCode
	ASSERT_EQ(response->StatusCode(message), 200);
	//GetHttpVersion
	ASSERT_STREQ(response->GetHttpVersion(message), "HTTP/1.0");
	//ReplaceStatus
	response->ReplaceStatus(message, 999);
	ASSERT_EQ(response->StatusCode(message), 999);
	//GetReason
	ASSERT_STREQ(response->GetReason(message), "OK");
	//ReplaceReason
	response->ReplaceReason(message, "unknown reason");
	ASSERT_STREQ(response->GetReason(message), "unknown reason");
}

static void commonConnectionFunctions(HttpHandle *message, const ConnectionFunctions *connection)
{
	ASSERT_TRUE(connection->GetId(message) > 0);
	ASSERT_EQ(connection->GetInfo(message)->remoteAddress->port, TEST_PORT);
}

static void _RequestHeadersCommonReqFuncs(HttpHandle *message, ConnectionFunctions *connection, RequestFunctions *request, void *connContext)
{
	commonRequestFunctions(message, request);
	commonConnectionFunctions(message, connection);
}
static int RequestHeadersCommonReqFuncs(HttpHandle *message, ConnectionFunctions *connection, RequestFunctions *request, void *connContext)
{
	_RequestHeadersCommonReqFuncs(message, connection, request, connContext);
	return 0;
}
static void serverRecvCommonReqFuncs(ssize_t received, char *recvBuffer)
{
	//check server recv without body
	ASSERT_TRUE(received > 0);
	ASSERT_TRUE(strstr(recvBuffer, "testRequestHeaderKey: new value") != NULL);
	ASSERT_TRUE(strstr(recvBuffer, "content-type: text/html") == NULL);
}
TEST(RequestHeaders, commonRequestFunctions)
{
	HttpCbks cbks = {0};
	cbks.RequestHeaders = RequestHeadersCommonReqFuncs;
	serverRecv = serverRecvCommonReqFuncs;
	initSDK(&cbks);
	runThreads();
	uninitSDK();
}

static void _RequestHeadersBlock(HttpHandle *message, ConnectionFunctions *connection, RequestFunctions *request, void *connContext)
{
	commonRequestFunctions(message, request);
	commonConnectionFunctions(message, connection);
	//Block
	request->Block(message);
	connection->Disconnect(message);
}
static int RequestHeadersBlock(HttpHandle *message, ConnectionFunctions *connection, RequestFunctions *request, void *connContext)
{
	_RequestHeadersBlock(message, connection, request, connContext);
	return 0;
}
static void _RequestCompleteUnreach()
{
	ASSERT_EQ(1, 0);
}
static int RequestCompleteUnreach(HttpHandle *message, ConnectionFunctions *connection, RequestFunctions *request, void *connContext)
{
	_RequestCompleteUnreach();
	return 0;
}
static void checkServerRecvWithBlock(ssize_t received, char *recvBuffer)
{
	//check server recv with block
	ASSERT_EQ(received, 0); //socket shutdown by peer
	ASSERT_EQ(recvBuffer[0], 0);
}
TEST(RequestHeaders, requestFunctionBlock)
{
	HttpCbks cbks = {0};
	cbks.RequestHeaders = RequestHeadersBlock;
	cbks.RequestComplete = RequestCompleteUnreach;
	serverRecv = checkServerRecvWithBlock;
	initSDK(&cbks);
	runThreads();
	uninitSDK();
}

static char normalRequestBody[] = "normal request body";
static void _RequestCompleteCommonReqFuncs(HttpHandle *message, ConnectionFunctions *connection, RequestFunctions *request, void *connContext)
{
	commonRequestFunctions(message, request);
	commonConnectionFunctions(message, connection);
	//Body and BodySize
	ASSERT_STREQ((const char *)request->Body(message), normalRequestBody);
	ASSERT_EQ(request->BodySize(message), strlen(normalRequestBody));
	//log_debug("body[%u][%s]", request->BodySize(message), request->Body(message));
}
static int RequestCompleteCommonReqFuncs(HttpHandle *message, ConnectionFunctions *connection, RequestFunctions *request, void *connContext)
{
	_RequestCompleteCommonReqFuncs(message, connection, request, connContext);
	return 0;
}
static void serverRecvNormalBody(ssize_t received, char *recvBuffer)
{
	//check server recv with NormalBody
	ASSERT_TRUE(received > 0);
	ASSERT_TRUE(strstr(recvBuffer, "testRequestHeaderKey: new value") != NULL);
	ASSERT_STREQ(strstr(recvBuffer, normalRequestBody), normalRequestBody);
	char bodyLength[64];
	memset(bodyLength, 0, 64);
	sprintf(bodyLength, "%lu", strlen(normalRequestBody));
	ASSERT_TRUE(strstr(recvBuffer, bodyLength) != NULL);
}
TEST(RequestComplete, commonRequestFunctions)
{
	HttpCbks cbks = {0};
	cbks.RequestComplete = RequestCompleteCommonReqFuncs;
	serverRecv = serverRecvNormalBody;
	requestBody = normalRequestBody;
	initSDK(&cbks);
	runThreads();
	uninitSDK();
}

#define LARGE_BODY_SIZE 5 * 1024 * 1024
#define SIZE_LESS_MAX_BODY_SIZE 2 * 1024 * 1024
static char largeRequestBody[LARGE_BODY_SIZE + 1024];
static char bodyFrag[SIZE_LESS_MAX_BODY_SIZE + 1];
static void _RequestCompleteLargeBody(HttpHandle *message, ConnectionFunctions *connection, RequestFunctions *request, void *connContext)
{
	commonConnectionFunctions(message, connection);
	//Body and BodySize in large body
	memset(bodyFrag, 0, sizeof(bodyFrag));
	memset(bodyFrag, 'A', SIZE_LESS_MAX_BODY_SIZE);
	ASSERT_TRUE(strstr((const char *)request->Body(message), bodyFrag) != NULL);
	ASSERT_TRUE(request->BodySize(message) < strlen(largeRequestBody));
	ASSERT_TRUE(request->BodySize(message) > SIZE_LESS_MAX_BODY_SIZE);
}
static int RequestCompleteLargeBody(HttpHandle *message, ConnectionFunctions *connection, RequestFunctions *request, void *connContext)
{
	_RequestCompleteLargeBody(message, connection, request, connContext);
	return 0;
}
static void serverRecvLargeBody(ssize_t received, char *recvBuffer)
{
	//check server recv with LargeBody
	//log_debug("received[%ld][%lu]", received, strlen(recvBuffer));
	ASSERT_TRUE((unsigned long)received > strlen(largeRequestBody));
	char bodyLength[64];
	memset(bodyLength, 0, 64);
	sprintf(bodyLength, "%lu", strlen(largeRequestBody));
	//log_debug("errno[%d]", errno);
	ASSERT_TRUE(strstr(recvBuffer, bodyLength) != NULL);
	ASSERT_TRUE(strstr(recvBuffer, largeRequestBody) != NULL);
}
TEST(RequestComplete, requestBodyIsLarge)
{
	HttpCbks cbks = {0};
	cbks.RequestComplete = RequestCompleteLargeBody;
	serverRecv = serverRecvLargeBody;
	requestBody = largeRequestBody;
	memset(largeRequestBody, 0, sizeof(largeRequestBody));
	memset(largeRequestBody, 'A', LARGE_BODY_SIZE);
	initSDK(&cbks);
	runThreads();
	uninitSDK();
}

static void _RequestCompleBlock(HttpHandle *message, ConnectionFunctions *connection, RequestFunctions *request)
{
	commonRequestFunctions(message, request);
	commonConnectionFunctions(message, connection);
	//Block
	request->Block(message);
	connection->Disconnect(message);
}
static int RequestCompleBlock(HttpHandle *message, ConnectionFunctions *connection, RequestFunctions *request, void *connContext)
{
	_RequestCompleBlock(message, connection, request);
	return 0;
}
TEST(RequestComplete, requestFunctionBlock)
{
	HttpCbks cbks = {0};
	cbks.RequestComplete = RequestCompleBlock;
	serverRecv = checkServerRecvWithBlock;
	initSDK(&cbks);
	runThreads();
	uninitSDK();
}

static void _ResponseHeadersCommonFuncs(HttpHandle *message, ConnectionFunctions *connection, const RequestFunctions *request, ResponseFunctions *response, void *connContext)
{
	commonRequestFunctions(message, request);
	commonResponseFunctions(message, response);
	commonConnectionFunctions(message, connection);
}
static int ResponseHeadersCommonFuncs(HttpHandle *message, ConnectionFunctions *connection, const RequestFunctions *request, ResponseFunctions *response, void *connContext)
{
	_ResponseHeadersCommonFuncs(message, connection, request, response, connContext);
	return 0;
}
static void clientRecvDefaultBody(tcpBuffer *bodyBuffer, tcpBuffer *headerBuffer)
{
	//log_debug("header[%u][%s]", headerBuffer->size, headerBuffer->buffer);
	// log_debug("body[%u][%s]", bodyBuffer->size, bodyBuffer->buffer);
	//ReplaceStatus
	ASSERT_TRUE(strstr(headerBuffer->buffer, "999") != NULL);
	//ReplaceReason
	ASSERT_TRUE(strstr(headerBuffer->buffer, "unknown reason") != NULL);
	ASSERT_STREQ(bodyBuffer->buffer, defaultResponseBody);
	ASSERT_EQ(bodyBuffer->size, strlen(defaultResponseBody));
}
TEST(ResponseHeaders, commonRequestFunctions)
{
	HttpCbks cbks = {0};
	cbks.ResponseHeaders = ResponseHeadersCommonFuncs;
	clientRecv = clientRecvDefaultBody;
	initSDK(&cbks);
	runThreads();
	uninitSDK();
}

static char replacedBody[] = "new body";
static void _MessageCommonFuncs(HttpHandle *message, const ConnectionFunctions *connection, const RequestFunctions *request, const ResponseFunctions *response)
{
	commonRequestFunctions(message, request);
	commonResponseFunctions(message, response);
	commonConnectionFunctions(message, connection);
	//log_debug("Content[%d][%s]", response->ContentSize(message), response->Content(message));
	// ContentSize and Content
	ASSERT_EQ(response->ContentSize(message), strlen(defaultResponseBody));
	ASSERT_STREQ((const char *)response->Content(message), defaultResponseBody);
	//replacedBody
	response->ReplaceContent(message, (const unsigned char *)replacedBody, strlen(replacedBody), NULL);
	ASSERT_EQ(response->ContentSize(message), strlen(replacedBody));
	ASSERT_STREQ((const char *)response->Content(message), replacedBody);
}
static int MessageCommonFuncs(HttpHandle *message, const ConnectionFunctions *connection, const RequestFunctions *request, const ResponseFunctions *response, void *connContext)
{
	_MessageCommonFuncs(message, connection, request, response);
	return 0;
}
static void clientRecvReplacedBody(tcpBuffer *bodyBuffer, tcpBuffer *headerBuffer)
{
	//log_debug("body[%u][%s]", bodyBuffer->size, bodyBuffer->buffer);
	ASSERT_STREQ(bodyBuffer->buffer, replacedBody);
	ASSERT_EQ(bodyBuffer->size, strlen(replacedBody));
}
TEST(Message, commonResponeFunctions)
{
	HttpCbks cbks = {0};
	cbks.Message = MessageCommonFuncs;
	clientRecv = clientRecvReplacedBody;
	initSDK(&cbks);
	runThreads();
	uninitSDK();
}

static char largeResponseBody[LARGE_BODY_SIZE + 1024];
static void _MessageLargeBody(HttpHandle *message, const ResponseFunctions *response)
{
	// ContentSize and Content
	ASSERT_TRUE(response->ContentSize(message) > SIZE_LESS_MAX_BODY_SIZE);
	ASSERT_TRUE(response->ContentSize(message) < strlen(largeResponseBody));
	memset(bodyFrag, 0, sizeof(bodyFrag));
	memset(bodyFrag, 'B', SIZE_LESS_MAX_BODY_SIZE);
	ASSERT_TRUE(strstr((const char *)response->Content(message), bodyFrag) != NULL);
}
static int MessageLargeBody(HttpHandle *message, const ConnectionFunctions *connection, const RequestFunctions *request, const ResponseFunctions *response, void *connContext)
{
	_MessageLargeBody(message, response);
	return 0;
}
static void clientRecvLargeBody(tcpBuffer *bodyBuffer, tcpBuffer *headerBuffer)
{
	//log_debug("body[%u][%s]", bodyBuffer->size, bodyBuffer->buffer);
	ASSERT_STREQ(bodyBuffer->buffer, largeResponseBody);
	ASSERT_EQ(bodyBuffer->size, strlen(largeResponseBody));
}
TEST(Message, responseBodyIsLarge)
{
	HttpCbks cbks = {0};
	cbks.Message = MessageLargeBody;
	clientRecv = clientRecvLargeBody;
	responseBody = largeResponseBody;
	memset(largeResponseBody, 0, sizeof(largeResponseBody));
	memset(largeResponseBody, 'B', LARGE_BODY_SIZE);
	initSDK(&cbks);
	runThreads();
	uninitSDK();
}

static char chunkedHeader[] = "Transfer-Encoding: chunked";
static char chunkedResponseBody[] = "6\r\nHello\n\r\n6\r\nNihao\n\r\n8\r\nPriviet\n\r\n0\r\n\r\n";
static void _MessageChunkedBody(HttpHandle *message, const ResponseFunctions *response)
{
	//log_debug("Content[%d][%s]", response->ContentSize(message), response->Content(message));
	ASSERT_EQ(response->ContentSize(message), strlen("Hello\nNihao\nPriviet\n"));
	ASSERT_STREQ((const char *)response->Content(message), "Hello\nNihao\nPriviet\n");
}
static int MessageChunkedBody(HttpHandle *message, const ConnectionFunctions *connection, const RequestFunctions *request, const ResponseFunctions *response, void *connContext)
{
	_MessageChunkedBody(message, response);
	return 0;
}
static void clientRecvChunkedBody(tcpBuffer *bodyBuffer, tcpBuffer *headerBuffer)
{
	// log_debug("header[%u][%s]", headerBuffer->size, headerBuffer->buffer);
	// log_debug("body[%u][%s]", bodyBuffer->size, bodyBuffer->buffer);
	ASSERT_EQ(bodyBuffer->size, strlen("Hello\nNihao\nPriviet\n"));
	ASSERT_STREQ(bodyBuffer->buffer, "Hello\nNihao\nPriviet\n");
	ASSERT_TRUE(strstr(headerBuffer->buffer, "Content-Length") != NULL);
}
TEST(Message, responseBodyIsChunked)
{
	HttpCbks cbks = {0};
	cbks.Message = MessageChunkedBody;
	clientRecv = clientRecvChunkedBody;
	responseBody = chunkedResponseBody;
	customHeader = chunkedHeader;
	initSDK(&cbks);
	runThreads();
	uninitSDK();
}

#define CHUNKED_FRAG_SIZE 1024 * 1024
#define LARGE_CHUNKED_SIZE 8 * CHUNKED_FRAG_SIZE
static char chunkedLargeResponseBodyFrag[CHUNKED_FRAG_SIZE + 1];
static char chunkedLargeResponseBody[LARGE_CHUNKED_SIZE + 1024] = {0};
static void _MessageChunkedLargeBody(HttpHandle *message, const ResponseFunctions *response)
{
	//log_debug("Content[%d]", response->ContentSize(message));
	ASSERT_TRUE(response->ContentSize(message) > 2 * CHUNKED_FRAG_SIZE);
	ASSERT_TRUE(response->ContentSize(message) < strlen(chunkedLargeResponseBody));
	ASSERT_EQ(strlen((const char *)response->Content(message)), response->ContentSize(message));
	ASSERT_TRUE(strstr((const char *)response->Content(message), chunkedLargeResponseBodyFrag) != NULL);
}
static int MessageChunkedLargeBody(HttpHandle *message, const ConnectionFunctions *connection, const RequestFunctions *request, const ResponseFunctions *response, void *connContext)
{
	_MessageChunkedLargeBody(message, response);
	return 0;
}
static void clientRecvChunkedLargeBody(tcpBuffer *bodyBuffer, tcpBuffer *headerBuffer)
{
	//log_debug("header[%u][%s]", headerBuffer->size, headerBuffer->buffer);
	// log_debug("body[%u][%s]", bodyBuffer->size, bodyBuffer->buffer);
	memset(chunkedLargeResponseBody, 0, sizeof(chunkedLargeResponseBody));
	memset(chunkedLargeResponseBody, 'C', LARGE_CHUNKED_SIZE);
	ASSERT_EQ(bodyBuffer->size, strlen(chunkedLargeResponseBody));
	ASSERT_STREQ(bodyBuffer->buffer, chunkedLargeResponseBody);
	ASSERT_TRUE(strstr(headerBuffer->buffer, "Content-Length") == NULL);
}
TEST(Message, responseBodyIsChunkedLarge)
{
	HttpCbks cbks = {0};
	cbks.Message = MessageChunkedLargeBody;
	clientRecv = clientRecvChunkedLargeBody;
	memset(chunkedLargeResponseBody, 0, sizeof(chunkedLargeResponseBody));
	memset(chunkedLargeResponseBodyFrag, 'C', CHUNKED_FRAG_SIZE);
	chunkedLargeResponseBodyFrag[CHUNKED_FRAG_SIZE] = 0;
	unsigned int len = 0;
	while (len < LARGE_CHUNKED_SIZE)
	{
		sprintf(&chunkedLargeResponseBody[strlen(chunkedLargeResponseBody)], "%lx\r\n", strlen(chunkedLargeResponseBodyFrag));
		sprintf(&chunkedLargeResponseBody[strlen(chunkedLargeResponseBody)], "%s\r\n", chunkedLargeResponseBodyFrag);
		len += CHUNKED_FRAG_SIZE;
	}
	sprintf(&chunkedLargeResponseBody[strlen(chunkedLargeResponseBody)], "0\r\n\r\n");
	responseBody = chunkedLargeResponseBody;
	customHeader = chunkedHeader;
	initSDK(&cbks);
	runThreads();
	uninitSDK();
}

static void _RequestHeadersSkipMessage(HttpHandle *message, ConnectionFunctions *connection, RequestFunctions *request)
{
	connection->SkipMessage(message, request);
}
static int RequestHeadersSkipMessage(HttpHandle *message, ConnectionFunctions *connection, RequestFunctions *request, void *connContext)
{
	_RequestHeadersSkipMessage(message, connection, request);
	return 0;
}
static void _skipMessageRequestComplete()
{
	ASSERT_EQ(1, 0);
}
static int skipMessageRequestComplete(HttpHandle *message, ConnectionFunctions *connection, RequestFunctions *request, void *connContext)
{
	_skipMessageRequestComplete();
	return 0;
}
static void _skipMessageResponseHeaders()
{
	ASSERT_EQ(1, 0);
}
static int skipMessageResponseHeaders(HttpHandle *message, ConnectionFunctions *connection, const RequestFunctions *request, ResponseFunctions *response, void *connContext)
{
	_skipMessageResponseHeaders();
	return 0;
}
static void _skipMessageMessage()
{
	ASSERT_EQ(1, 0);
}
static int skipMessageMessage(HttpHandle *message, const ConnectionFunctions *connection, const RequestFunctions *request, const ResponseFunctions *response, void *connContext)
{
	_skipMessageMessage();
	return 0;
}
static void _skipMessagePostScan()
{
	ASSERT_EQ(1, 0);
}
static int skipMessagePostScan(HttpHandle *message, ConnectionFunctions *connection, const RequestFunctions *request, ResponseFunctions *response, void *connContext)
{
	_skipMessagePostScan();
	return 0;
}
static void serverRecvNormalBodyUnmodified(ssize_t received, char *recvBuffer)
{
	ASSERT_TRUE(received > 0);
	ASSERT_TRUE(strstr(recvBuffer, "testRequestHeaderKey: testRequestHeaderValue") != NULL);
	ASSERT_STREQ(strstr(recvBuffer, normalRequestBody), normalRequestBody);
	char bodyLength[64];
	memset(bodyLength, 0, 64);
	sprintf(bodyLength, "%lu", strlen(normalRequestBody));
	ASSERT_TRUE(strstr(recvBuffer, bodyLength) != NULL);
	ASSERT_TRUE(strstr(recvBuffer, normalRequestBody) != NULL);
}
static void clientRecvDefaultBodyUnmodified(tcpBuffer *bodyBuffer, tcpBuffer *headerBuffer)
{
	//log_debug("body[%u][%s]", bodyBuffer->size, bodyBuffer->buffer);
	ASSERT_STREQ(bodyBuffer->buffer, defaultResponseBody);
	ASSERT_EQ(bodyBuffer->size, strlen(defaultResponseBody));
}
TEST(RequestHeaders, SkipMessage)
{
	HttpCbks cbks = {0};
	cbks.RequestHeaders = RequestHeadersSkipMessage;
	cbks.RequestComplete = skipMessageRequestComplete;
	cbks.ResponseHeaders = skipMessageResponseHeaders;
	cbks.Message = skipMessageMessage;
	cbks.PostScan = skipMessagePostScan;
	serverRecv = serverRecvNormalBodyUnmodified;
	requestBody = normalRequestBody;
	clientRecv = clientRecvDefaultBodyUnmodified;
	initSDK(&cbks);
	runThreads();
	uninitSDK();
}

static void _RequestHeadersSkipFiltering(HttpHandle *message, ConnectionFunctions *connection, RequestFunctions *request)
{
	connection->SkipFiltering(message);
}
static int RequestHeadersSkipFiltering(HttpHandle *message, ConnectionFunctions *connection, RequestFunctions *request, void *connContext)
{
	_RequestHeadersSkipFiltering(message, connection, request);
	return 0;
}
static void _skipFilteringRequestComplete()
{
	ASSERT_EQ(1, 0);
}
static int skipFilteringRequestComplete(HttpHandle *message, ConnectionFunctions *connection, RequestFunctions *request, void *connContext)
{
	_skipFilteringRequestComplete();
	return 0;
}
static void _skipFilteringResponseHeaders()
{
	ASSERT_EQ(1, 0);
}
static int skipFilteringResponseHeaders(HttpHandle *message, ConnectionFunctions *connection, const RequestFunctions *request, ResponseFunctions *response, void *connContext)
{
	_skipFilteringResponseHeaders();
	return 0;
}
static void _skipFilteringMessage()
{
	ASSERT_EQ(1, 0);
}
static int skipFilteringMessage(HttpHandle *message, const ConnectionFunctions *connection, const RequestFunctions *request, const ResponseFunctions *response, void *connContext)
{
	_skipFilteringMessage();
	return 0;
}
static void _skipFilteringPostScan()
{
	ASSERT_EQ(1, 0);
}
static int skipFilteringPostScan(HttpHandle *message, ConnectionFunctions *connection, const RequestFunctions *request, ResponseFunctions *response, void *connContext)
{
	_skipFilteringPostScan();
	return 0;
}
static void _connectionDestroyed()
{
	//log_debug("connectionDestroyed");
	ASSERT_EQ(1, 1);
}
static int connectionDestroyed(HttpHandle *message, ConnectionFunctions *connection, void *connContext)
{
	_connectionDestroyed();
	return 0;
}
TEST(RequestHeaders, SkipFiltering)
{
	HttpCbks cbks = {0};
	cbks.RequestHeaders = RequestHeadersSkipFiltering;
	cbks.RequestComplete = skipFilteringRequestComplete;
	cbks.ResponseHeaders = skipFilteringResponseHeaders;
	cbks.Message = skipFilteringMessage;
	cbks.PostScan = skipFilteringPostScan;
	cbks.ConnectionDestroyed = connectionDestroyed;
	serverRecv = serverRecvNormalBodyUnmodified;
	requestBody = normalRequestBody;
	clientRecv = clientRecvDefaultBodyUnmodified;
	initSDK(&cbks);
	runThreads();
	uninitSDK();
}

static void _RequestHeadersSkipResponse(HttpHandle *message, ConnectionFunctions *connection, RequestFunctions *request)
{
	ResponseFunctions *response = connection->MakeResponse(message);
	connection->SkipResponse(message, request, response);
	connection->FreeResponse(message, response);
}
static int RequestHeadersSkipResponse(HttpHandle *message, ConnectionFunctions *connection, RequestFunctions *request, void *connContext)
{
	_RequestHeadersSkipResponse(message, connection, request);
	return 0;
}
static void _skipResponseRequestComplete()
{
	ASSERT_EQ(1, 0);
}
static int skipResponseRequestComplete(HttpHandle *message, ConnectionFunctions *connection, RequestFunctions *request, void *connContext)
{
	_skipResponseRequestComplete();
	return 0;
}
static void _skipResponseResponseHeaders()
{
	ASSERT_EQ(1, 0);
}
static int skipResponseResponseHeaders(HttpHandle *message, ConnectionFunctions *connection, const RequestFunctions *request, ResponseFunctions *response, void *connContext)
{
	_skipResponseResponseHeaders();
	return 0;
}
static void _skipResponseMessage()
{
	ASSERT_EQ(1, 0);
}
static int skipResponseMessage(HttpHandle *message, const ConnectionFunctions *connection, const RequestFunctions *request, const ResponseFunctions *response, void *connContext)
{
	_skipResponseMessage();
	return 0;
}
static void _skipResponsePostScan()
{
	ASSERT_EQ(1, 0);
}
static int skipResponsePostScan(HttpHandle *message, ConnectionFunctions *connection, const RequestFunctions *request, ResponseFunctions *response, void *connContext)
{
	_skipResponsePostScan();
	return 0;
}
TEST(RequestHeaders, SkipResponse)
{
	HttpCbks cbks = {0};
	cbks.RequestHeaders = RequestHeadersSkipResponse;
	cbks.RequestComplete = skipResponseRequestComplete;
	cbks.ResponseHeaders = skipResponseResponseHeaders;
	cbks.Message = skipResponseMessage;
	cbks.PostScan = skipResponsePostScan;
	serverRecv = serverRecvNormalBodyUnmodified;
	requestBody = normalRequestBody;
	clientRecv = clientRecvDefaultBodyUnmodified;
	initSDK(&cbks);
	runThreads();
	uninitSDK();
}

static char blockPageBody[] = "block page";
static void _RequestHeadersBlockPage(HttpHandle *message, ConnectionFunctions *connection, RequestFunctions *request)
{
	ResponseFunctions *response = connection->MakeResponse(message);
	connection->BlockPage(message, request, response, (unsigned char *)blockPageBody, strlen(blockPageBody));
	connection->FreeResponse(message, response);
	connection->Disconnect(message);
}
static int RequestHeadersBlockPage(HttpHandle *message, ConnectionFunctions *connection, RequestFunctions *request, void *connContext)
{
	_RequestHeadersBlockPage(message, connection, request);
	return 0;
}
static void serverRecvBlockPage(ssize_t received, char *recvBuffer)
{
	// log_debug("received[%d]", received);
	ASSERT_EQ(received, 0);
}
static void clientRecvBlockPage(tcpBuffer *bodyBuffer, tcpBuffer *headerBuffer)
{
	// log_debug("header[%u][%s]", headerBuffer->size, headerBuffer->buffer);
	// log_debug("body[%u][%s]", bodyBuffer->size, bodyBuffer->buffer);
	ASSERT_STREQ(bodyBuffer->buffer, (char *)blockPageBody);
	ASSERT_EQ(bodyBuffer->size, strlen(blockPageBody));
}
TEST(RequestHeaders, BlockPage)
{
	HttpCbks cbks = {0};
	cbks.RequestHeaders = RequestHeadersBlockPage;
	requestBody = normalRequestBody;
	serverRecv = serverRecvBlockPage;
	clientRecv = clientRecvBlockPage;
	initSDK(&cbks);
	runThreads();
	uninitSDK();
}

static void _PostScanBlockPage(HttpHandle *message, ConnectionFunctions *connection, const RequestFunctions *request, ResponseFunctions *response)
{
	ResponseFunctions *newResponse = connection->MakeResponse(message);
	connection->BlockPage(message, request, newResponse, (unsigned char *)blockPageBody, strlen(blockPageBody));
	connection->FreeResponse(message, newResponse);
}
static int PostScanBlockPage(HttpHandle *message, ConnectionFunctions *connection, const RequestFunctions *request, ResponseFunctions *response, void *connContext)
{
	_PostScanBlockPage(message, connection, request, response);
	return 0;
}
static void serverRecvBlockPagePostScan(ssize_t received, char *recvBuffer)
{
	// log_debug("received[%d]", received);
	ASSERT_LT(strlen(blockPageBody), received);
}
static void clientRecvBlockPagePostScan(tcpBuffer *bodyBuffer, tcpBuffer *headerBuffer)
{
	// log_debug("header[%u][%s]", headerBuffer->size, headerBuffer->buffer);
	// log_debug("body[%u][%s]", bodyBuffer->size, bodyBuffer->buffer);
	ASSERT_STREQ(bodyBuffer->buffer, (char *)blockPageBody);
	ASSERT_EQ(bodyBuffer->size, strlen(blockPageBody));
}
TEST(PostScan, BlockPage)
{
	HttpCbks cbks = {0};
	cbks.PostScan = PostScanBlockPage;
	requestBody = normalRequestBody;
	serverRecv = serverRecvBlockPagePostScan;
	clientRecv = clientRecvBlockPagePostScan;
	initSDK(&cbks);
	runThreads();
	uninitSDK();
}

static char insertResponseBody[] = "insert response body";
static void _RequestHeadersInsertResponse(HttpHandle *message, ConnectionFunctions *connection, RequestFunctions *request)
{
	ResponseFunctions *response = connection->MakeResponse(message);
	response->ReplaceContent(message, (unsigned char *)insertResponseBody, strlen(insertResponseBody), NULL);
	connection->InsertResponse(message, request, response);
	connection->FreeResponse(message, response);
	connection->Disconnect(message);
}
static int RequestHeadersInsertResponse(HttpHandle *message, ConnectionFunctions *connection, RequestFunctions *request, void *connContext)
{
	_RequestHeadersInsertResponse(message, connection, request);
	return 0;
}
static void serverRecvInsertResponse(ssize_t received, char *recvBuffer)
{
	//log_debug("received[%d]", received);
	ASSERT_EQ(received, 0);
}
static void clientRecvInsertResponse(tcpBuffer *bodyBuffer, tcpBuffer *headerBuffer)
{
	// log_debug("header[%u][%s]", headerBuffer->size, headerBuffer->buffer);
	// log_debug("body[%u][%s]", bodyBuffer->size, bodyBuffer->buffer);
	ASSERT_STREQ(bodyBuffer->buffer, (char *)insertResponseBody);
	ASSERT_EQ(bodyBuffer->size, strlen(insertResponseBody));
}
TEST(RequestHeaders, InsertResponse)
{
	HttpCbks cbks = {0};
	cbks.RequestHeaders = RequestHeadersInsertResponse;
	requestBody = normalRequestBody;
	serverRecv = serverRecvInsertResponse;
	clientRecv = clientRecvInsertResponse;
	initSDK(&cbks);
	runThreads();
	uninitSDK();
}

static void _SSLDomain(HttpHandle *message, ConnectionFunctions *connection, const char *domain)
{
	//log_debug("domain name[%s]", domain);
	//connection->WaitCloudStatus(message, NULL);
	log_debug("domain name[%s]", domain);
	ASSERT_STREQ(domain, "www.google.com");
}
static int SSLDomain(HttpHandle *message, ConnectionFunctions *connection, const char *domain, void *connContext)
{
	_SSLDomain(message, connection, domain);
	return 0;
}
static void _SSLOnCloudResponse(const CloudResponse *cloudResponse, const RequestFunctions *request, const ResponseFunctions *response)
{
	ASSERT_TRUE(cloudResponse->source != NULL);
	ASSERT_TRUE(strstr(cloudResponse->source, "ok") != NULL);
	ASSERT_TRUE(request == NULL);
	ASSERT_TRUE(response == NULL);
	log_debug("cloud result: %s", cloudResponse->source);
}
static int SSLOnCloudResponse(HttpHandle *message, const ConnectionFunctions *connection, const RequestFunctions *request, const ResponseFunctions *response, const CloudResponse *cloudResponse, void *connContext)
{
	_SSLOnCloudResponse(cloudResponse, request, response);
	return 0;
}

TEST(SSLDomain, SSLDomain)
{
	HttpCbks cbks = {0};
	char httpsUrl[] = "https://www.google.com/";
	curlUrl = httpsUrl;
	cbks.SSLDomain = SSLDomain;
	cbks.OnCloudResponse = SSLOnCloudResponse;
	initSDK(&cbks);
	sendRequestThreadFunc(NULL);
	//runThreads();
	uninitSDK();
}

static void _OnCloudResponse(const CloudResponse *cloudResponse)
{
	ASSERT_TRUE(cloudResponse->source != NULL);
	ASSERT_TRUE(strstr(cloudResponse->source, "ok") != NULL);
	log_debug("cloud result: %s", cloudResponse->source);
}
static int OnCloudResponse(HttpHandle *message, const ConnectionFunctions *connection, const RequestFunctions *request, const ResponseFunctions *response, const CloudResponse *cloudResponse, void *connContext)
{
	_OnCloudResponse(cloudResponse);
	return 0;
}

TEST(OnCloudResponse, OnCloudResponse)
{
	HttpCbks cbks = {0};
	cbks.OnCloudResponse = OnCloudResponse;
	initSDK(&cbks);
	runThreads();
	uninitSDK();
}

static int cloudResponseReceived = 0;
static int cloudResponseCount = 0;
static void _OnCloudResponse2(const CloudResponse *cloudResponse)
{
	ASSERT_TRUE(cloudResponse->source != NULL);
	ASSERT_TRUE(strstr(cloudResponse->source, "ok") != NULL);
	ASSERT_TRUE(cloudResponseCount < 1);
	cloudResponseCount++;
	cloudResponseReceived = 1;
	log_debug("cloud result: %s", cloudResponse->source);
}
static int OnCloudResponse2(HttpHandle *message, const ConnectionFunctions *connection, const RequestFunctions *request, const ResponseFunctions *response, const CloudResponse *cloudResponse, void *connContext)
{
	_OnCloudResponse2(cloudResponse);
	return 0;
}

static void _RequestCompletewaitCloudStatus()
{
	ASSERT_EQ(cloudResponseReceived, 1);
}

static int RequestCompletewaitCloudStatus(HttpHandle *message, ConnectionFunctions *connection, RequestFunctions *request, void *connContext)
{

	connection->WaitCloudStatus(message, request);
	_RequestCompletewaitCloudStatus();
	connection->WaitCloudStatus(message, request);
	connection->WaitCloudStatus(message, request);
	return 0;
}

TEST(OnCloudResponse, WaitCloudStatus)
{
	HttpCbks cbks = {0};
	cbks.RequestComplete = RequestCompletewaitCloudStatus;
	cbks.OnCloudResponse = OnCloudResponse2;
	initSDK(&cbks);
	runThreads();
	uninitSDK();
}

int main(int argc, char **argv)
{
	testing::InitGoogleTest(&argc, argv);

	curl_global_init(CURL_GLOBAL_DEFAULT);

	initListenSocket(TEST_PORT);

	int ret = RUN_ALL_TESTS();

	curl_global_cleanup();

	return ret;
}
