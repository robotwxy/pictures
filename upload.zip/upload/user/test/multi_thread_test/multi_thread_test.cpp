#include "interface.h"

#include <string.h>
#include <signal.h>
#include <pthread.h>
#include <stdio.h>
#include <arpa/inet.h>
unsigned long long counter = 0;
static pthread_mutex_t counterMutex = PTHREAD_MUTEX_INITIALIZER;
int RequestHeaders(HttpHandle *message, ConnectionFunctions *connection, RequestFunctions *request, void *connContext)
{
  pthread_mutex_lock(&counterMutex);
  counter++;
  pthread_mutex_unlock(&counterMutex);
  printf("RequestHeaders! %llu, %llu\n", connection->GetId(message), counter);
  return 0;
}

//static char replaceBody[] = "Hello";
static char replaceBody2[4097];
int PostScan(HttpHandle *message, ConnectionFunctions *connection, const RequestFunctions *request, ResponseFunctions *response, void *connContext)
{
  response->ReplaceContent(message, (unsigned char *)replaceBody2, strlen(replaceBody2), (char *)NULL);
  return 0;
}
unsigned short ports[] = {80, 8000, 5000};
int main()
{
  memset(replaceBody2, 'A', 4096);
  replaceBody2[4096] = 0;
  int ret;
  HttpCbks cbks = {0};
  HttpInitParams params = {0};
  params.logEnable = 1;
  params.listenPort = 23337;
  params.listenIpAddr = inet_addr("127.0.0.1");
  params.remoteHttpPorts = ports;
  params.remoteHttpPortsCount = sizeof(ports) / sizeof(unsigned short);
  ret = Http_Initialize(&params);
  printf("Http_Initialize result:%d\n", ret);
  cbks.RequestComplete = RequestHeaders;
  cbks.PostScan = PostScan;
  ret = Http_SetCallbacks(&cbks);
  printf("Http_SetCallbacks result:%d\n", ret);
  ret = Http_Start();
  printf("Http_Start result:%d\n", ret);
  printf("waiting for input to exit\n");
  getchar();
  ret = Http_Stop();
  printf("Http_Stop result:%d\n", ret);
  ret = Http_Uninitialize();
  printf("Http_Uninitialize result:%d\n", ret);
  return 0;
}
