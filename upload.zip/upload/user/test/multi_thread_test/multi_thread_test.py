#!/usr/bin/env python

import threading
import time
import requests

url = "http://47.88.173.175:5000/checkurl"

replaceBody = "A" * 4096


class MyThread(threading.Thread):
    def run(self):
        # print("{} started!".format(self.getName()))
        r = requests.get(url)
        # assert len(r.content.decode("utf-8")) == 4096
        #     assert r.content.decode("utf-8") == 'Hello'

        #assert r.content.decode("utf-8") == 'Hello'
        # assert len(r.content.decode("utf-8")) == 917
        print(self.getName(), r.status_code,
              len(r.content.decode("utf-8")), len(r.headers))
        assert r.content.decode("utf-8") == replaceBody
        # print("{} finished!".format(self.getName()))


def main():
    for x in range(500):
        mythread = MyThread(name="Thread-{}".format(x))
        mythread.start()


if __name__ == '__main__':
    main()
